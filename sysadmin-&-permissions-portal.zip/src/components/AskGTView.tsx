import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  Loader2, 
  AlertTriangle, 
  MessageSquare, 
  Terminal, 
  HelpCircle,
  Copy,
  Check
} from 'lucide-react';
import { ChatMessage } from '../types';

interface AskGTViewProps {
  user: string;
}

const SAMPLE_PROMPTS = [
  { label: 'Log Rotasyonu', query: 'Bana sunucu disk doluluğunu çözmek adına log rotasyonu (logrotate.conf) için şık bir konfigürasyon örneği yaz.' },
  { label: 'Docker Nginx Load Balancer', query: 'Docker compose kullanarak 2 web nodu arkasında duran bir Nginx load balancer şablonu hazırlar mısın?' },
  { label: 'Port Dinleyen Servisler', query: 'Linux sunucuda hangi portların açık olduğunu ve hangi servislerin dinlediğini listeleyen komutlar nelerdir?' },
  { label: 'SSH Güvenlik Kuralları', query: 'Sistem güvenliğini artırmak adına SSH konfigürasyonunda degiştirilmesi gereken en kritik kuralları açıklar mısın?' }
];

const AskGTView: React.FC<AskGTViewProps> = ({ user }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'model',
      content: 'Merhaba! Ben **AskGT**, gelişmiş bir sistem, altyapı ve DevOps mühendisliği asistanıyım.\n\nSana Linux sunucu hatalarını ayıklama, bash script yazma, Docker/Kubernetes mimarileri, Ansible playbookları veya ağ sorunları konularında yardımcı olabilirim. Nasıl yardımcı olabilirim?',
      timestamp: new Date().toISOString()
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorStatus, setErrorStatus] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSend = async (text: string) => {
    if (!text.trim() || loading) return;
    setErrorStatus(null);
    const userPrompt = text.trim();
    setInput('');

    // Append user query locally
    const userMessage: ChatMessage = {
      role: 'user',
      content: userPrompt,
      timestamp: new Date().toISOString()
    };
    setMessages((prev) => [...prev, userMessage]);
    setLoading(true);

    try {
      // Gather contextual history of last 10 messages for continuous chat
      const chatHistory = messages.slice(-10);

      const response = await fetch('/api/ask-gt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          prompt: userPrompt,
          history: chatHistory,
          user: user
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Yapay Zeka servisi ile bağlantı kurulamadı.');
      }

      const responseData = await response.json();
      
      const modelMessage: ChatMessage = {
        role: 'model',
        content: responseData.content,
        timestamp: new Date().toISOString()
      };
      
      setMessages((prev) => [...prev, modelMessage]);

    } catch (err: any) {
      console.error(err);
      setErrorStatus(err.message || 'Bir iletişim kusuru oluştu.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopyText = (text: string, msgIndex: number) => {
    navigator.clipboard.writeText(text);
    setCopiedId(String(msgIndex));
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Helper function to render markdown-like structures (bold, inline code and code block)
  const renderMessageContent = (content: string, msgIndex: number) => {
    const codeBlockRegex = /```(\w+)?\n([\s\S]+?)\n```/g;
    const parts = [];
    let lastIndex = 0;
    let match;

    const keyPrefix = `msg-part-${msgIndex}`;

    while ((match = codeBlockRegex.exec(content)) !== null) {
      // text before code block
      if (match.index > lastIndex) {
        parts.push({
          type: 'text',
          payload: content.substring(lastIndex, match.index)
        });
      }
      
      // code block content
      parts.push({
        type: 'code',
        language: match[1] || 'bash',
        payload: match[2]
      });

      lastIndex = codeBlockRegex.lastIndex;
    }

    if (lastIndex < content.length) {
      parts.push({
        type: 'text',
        payload: content.substring(lastIndex)
      });
    }

    return (
      <div className="space-y-3 whitespace-pre-wrap select-text leading-relaxed">
        {parts.map((p, pIdx) => {
          if (p.type === 'code') {
            return (
              <div key={`${keyPrefix}-${pIdx}`} className="bg-slate-950 border border-slate-900 rounded-lg overflow-hidden my-3">
                <div className="flex items-center justify-between px-4 py-2 bg-slate-900/85 border-b border-slate-850">
                  <span className="text-[10px] font-bold font-mono text-indigo-400 select-none flex items-center gap-1.5 uppercase">
                    <Terminal className="h-3 w-3" />
                    {p.language}
                  </span>
                  <button
                    onClick={() => handleCopyText(p.payload, msgIndex + pIdx)}
                    className="text-[10px] text-slate-400 hover:text-white font-bold inline-flex items-center gap-1 cursor-pointer"
                  >
                    {copiedId === String(msgIndex + pIdx) ? (
                      <>
                        <Check className="h-3 w-3 text-emerald-500" />
                        Kopyalandı!
                      </>
                    ) : (
                      <>
                        <Copy className="h-3 w-3" />
                        Kopyala
                      </>
                    )}
                  </button>
                </div>
                <pre className="p-4 overflow-x-auto text-[11.5px] font-mono text-slate-300 font-light select-all leading-normal">
                  <code>{p.payload}</code>
                </pre>
              </div>
            );
          }

          // text with simple markdown formatting (bold, links, listed items)
          let text = p.payload;
          
          return (
            <p key={`${keyPrefix}-${pIdx}`} className="text-sm text-slate-700 font-normal">
              {text.split('\n').map((line, lineI) => {
                // handle simple list items
                const isList = line.trim().startsWith('*') || line.trim().startsWith('-');
                const cleanLine = isList ? line.trim().replace(/^[-*]\s+/, '') : line;

                // parse inline bold formatting e.g. **text**
                const boldRegex = /\*\*([^*]+)\*\*/g;
                const lineParts = [];
                let boldLastIdx = 0;
                let boldMatch;

                while ((boldMatch = boldRegex.exec(cleanLine)) !== null) {
                  if (boldMatch.index > boldLastIdx) {
                    lineParts.push(<span key={boldMatch.index}>{cleanLine.substring(boldLastIdx, boldMatch.index)}</span>);
                  }
                  lineParts.push(<strong key={boldMatch.index + 'b'} className="font-bold text-slate-900">{boldMatch[1]}</strong>);
                  boldLastIdx = boldRegex.lastIndex;
                }

                if (boldLastIdx < cleanLine.length) {
                  lineParts.push(<span key="end">{cleanLine.substring(boldLastIdx)}</span>);
                }

                // parse inline code quotes e.g. `code`
                // (simulating simplistically)
                
                if (isList) {
                  return (
                    <span key={lineI} className="flex items-start gap-2 pl-2 mt-1">
                      <span className="text-indigo-600 font-bold mt-1.5 shrink-0 select-none">•</span>
                      <span className="text-sm text-slate-705">{lineParts}</span>
                    </span>
                  );
                }

                return (
                  <span key={lineI} className="block min-h-[0.75rem]">
                    {lineParts}
                  </span>
                );
              })}
            </p>
          );
        })}
      </div>
    );
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden h-[600px] flex flex-col">
      {/* Bot Chat Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 bg-slate-50">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 border border-indigo-150 rounded-xl text-indigo-600">
            <Bot className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-bold text-slate-850 text-sm">AskGT — Altyapı Yapay Zeka Danışmanı</h2>
            <p className="text-[11px] text-indigo-600 font-semibold flex items-center gap-1 mt-0.5">
              <Sparkles className="h-3 w-3 animate-pulse" /> Gemini 3.5 Flash Model Aktif
            </p>
          </div>
        </div>
        
        {/* Helper Badge */}
        <span className="text-[10px] bg-slate-100 border border-slate-200 text-slate-500 font-bold uppercase font-mono px-2 py-1 rounded">
          DevOps Destek
        </span>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-slate-50/30">
        {messages.map((msg, index) => (
          <div 
            key={index} 
            className={`flex gap-3 max-w-[85%] ${msg.role === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}
          >
            {/* Avatar */}
            <div className={`h-8 w-8 rounded-lg border flex items-center justify-center shrink-0 shadow-xs select-none
              ${msg.role === 'user' 
                ? 'bg-slate-800 border-slate-900 text-white font-bold' 
                : 'bg-indigo-50 border-indigo-100 text-indigo-600'}`}
            >
              {msg.role === 'user' ? user.substring(0, 1).toUpperCase() : <Bot className="h-4.5 w-4.5" />}
            </div>

            {/* Bubble Content */}
            <div className={`p-4 rounded-xl border shadow-2xs text-left
              ${msg.role === 'user'
                ? 'bg-indigo-600 border-indigo-650 text-white'
                : 'bg-white border-slate-200 text-slate-800'}`}
            >
              {msg.role === 'user' ? (
                <p className="text-sm font-medium whitespace-pre-wrap select-text leading-relaxed">{msg.content}</p>
              ) : (
                renderMessageContent(msg.content, index)
              )}
            </div>
          </div>
        ))}

        {/* Loading typing state indicators */}
        {loading && (
          <div className="flex gap-3 max-w-[80%] mr-auto">
            <div className="h-8 w-8 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center shrink-0">
              <Bot className="h-4.5 w-4.5 text-indigo-600" />
            </div>
            <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-2xs">
              <div className="flex items-center gap-2.5 text-slate-500 text-xs font-semibold">
                <Loader2 className="h-3.5 w-3.5 animate-spin text-indigo-600" />
                AskGT analiz yapıyor ve çözüm hazırlıyor...
              </div>
            </div>
          </div>
        )}

        {/* Response error alerts */}
        {errorStatus && (
          <div className="flex gap-2 p-3 bg-rose-50 border border-rose-100 rounded-xl text-rose-800 max-w-lg mx-auto text-xs font-semibold">
            <AlertTriangle className="h-4 w-4 text-rose-600 shrink-0" />
            <div>
              <span>Sorgu Çözümlenemedi: {errorStatus}</span>
              <button 
                onClick={() => handleSend(messages[messages.length - 1].content)} 
                className="block underline hover:text-rose-950 font-bold mt-1 cursor-pointer"
              >
                Tekrar Dene
              </button>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompt Chips footer */}
      {messages.length === 1 && (
        <div className="px-5 py-3 border-t border-slate-100 bg-slate-50/50 flex flex-col gap-2">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1 font-semibold select-none">
            <HelpCircle className="h-3.5 w-3.5 text-slate-400" /> Hızlı Örnek Sorular:
          </span>
          <div className="flex flex-wrap gap-2">
            {SAMPLE_PROMPTS.map((sample, ix) => (
              <button
                key={ix}
                onClick={() => handleSend(sample.query)}
                className="bg-white border border-slate-205 hover:border-slate-350 hover:bg-slate-50 text-slate-600 text-xs px-3 py-1.5 rounded-lg transition-all cursor-pointer font-medium shadow-2xs"
              >
                {sample.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Message Chat Input Form */}
      <form 
        onSubmit={(e) => { e.preventDefault(); handleSend(input); }}
        className="p-3 border-t border-slate-200 bg-white flex items-center gap-2"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={loading}
          placeholder="Linux hatası, bash script, nginx load balancer ayarlarını buraya yazın..."
          className="flex-1 px-4 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 transition-all font-normal"
        />
        <button
          type="submit"
          disabled={!input.trim() || loading}
          className={`p-2.5 text-white rounded-xl transition-all shadow-xs cursor-pointer
            ${!input.trim() || loading 
              ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200' 
              : 'bg-indigo-600 hover:bg-indigo-700 hover:shadow'}`}
        >
          <Send className="h-4.5 w-4.5 shrink-0" />
        </button>
      </form>
    </div>
  );
};

export default AskGTView;
