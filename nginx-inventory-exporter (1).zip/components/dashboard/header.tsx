'use client'

import { Search, RefreshCw, Download, Calendar } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'

interface HeaderProps {
  title: string
  subtitle?: string
  searchValue: string
  onSearchChange: (value: string) => void
  onRefresh: () => void
  lastUpdated: string
}

export function Header({ 
  title, 
  subtitle, 
  searchValue, 
  onSearchChange, 
  onRefresh,
  lastUpdated 
}: HeaderProps) {
  return (
    <header className="h-16 border-b border-border bg-card px-6 flex items-center justify-between">
      <div>
        <h2 className="text-lg font-semibold text-foreground">{title}</h2>
        {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      
      <div className="flex items-center gap-3">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search..."
            value={searchValue}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-64 pl-9 bg-secondary border-border"
          />
        </div>

        {/* Last updated */}
        <div className="flex items-center gap-2 text-xs text-muted-foreground px-3 py-1.5 bg-secondary rounded-md">
          <Calendar className="h-3.5 w-3.5" />
          <span>{lastUpdated}</span>
        </div>

        {/* Actions */}
        <Button variant="outline" size="sm" onClick={onRefresh} className="gap-2">
          <RefreshCw className="h-4 w-4" />
          Refresh
        </Button>
        <Button variant="outline" size="sm" className="gap-2">
          <Download className="h-4 w-4" />
          Export CSV
        </Button>
      </div>
    </header>
  )
}
