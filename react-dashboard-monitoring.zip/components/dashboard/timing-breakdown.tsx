import { cn } from "@/lib/utils"
import type { TimingBreakdown } from "@/lib/monitoring"

const SEGMENTS: { key: keyof TimingBreakdown; label: string; color: string }[] = [
  { key: "dns", label: "DNS", color: "bg-chart-5" },
  { key: "tcp", label: "TCP", color: "bg-chart-1" },
  { key: "tls", label: "TLS", color: "bg-chart-2" },
  { key: "ttfb", label: "TTFB", color: "bg-chart-3" },
  { key: "transfer", label: "Transfer", color: "bg-chart-4" },
]

export function TimingBreakdownBar({
  timing,
  showLegend = true,
  className,
}: {
  timing: TimingBreakdown
  showLegend?: boolean
  className?: string
}) {
  const total = Math.max(1, timing.total)
  return (
    <div className={cn("space-y-2", className)}>
      <div className="flex h-2.5 w-full overflow-hidden rounded-full bg-muted">
        {SEGMENTS.map((s) => {
          const v = timing[s.key]
          const w = (v / total) * 100
          if (w <= 0) return null
          return (
            <div
              key={s.key}
              className={cn("h-full", s.color)}
              style={{ width: `${w}%` }}
              title={`${s.label}: ${v}ms`}
            />
          )
        })}
      </div>
      {showLegend && (
        <div className="flex flex-wrap gap-x-4 gap-y-1">
          {SEGMENTS.map((s) => (
            <div key={s.key} className="flex items-center gap-1.5 text-xs">
              <span className={cn("size-2 rounded-[2px]", s.color)} />
              <span className="text-muted-foreground">{s.label}</span>
              <span className="font-mono text-foreground">{timing[s.key]}ms</span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
