import { cn } from "@/lib/utils"
import type { UptimeBucket } from "@/lib/monitoring"

export function UptimeBars({
  buckets,
  className,
}: {
  buckets: UptimeBucket[]
  className?: string
}) {
  return (
    <div className={cn("flex items-end gap-[2px]", className)}>
      {buckets.map((b, i) => (
        <div
          key={i}
          title={`${b.label} • ${b.uptime}% • ${b.status}`}
          className={cn(
            "h-7 flex-1 rounded-[1px] transition-opacity hover:opacity-70",
            b.status === "up"
              ? "bg-success/80"
              : b.status === "degraded"
                ? "bg-warning/80"
                : "bg-destructive/80",
          )}
        />
      ))}
    </div>
  )
}
