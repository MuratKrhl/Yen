"use client"

import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"
import { CalendarClock, Target as TargetIcon } from "lucide-react"
import type { Snapshot } from "@/lib/monitoring"
import { cn } from "@/lib/utils"
import { slaClass } from "@/lib/format"
import { UptimeBars } from "./uptime-bars"

function mean(arr: number[], d = 3) {
  const f = Math.pow(10, d)
  return Math.round((arr.reduce((a, b) => a + b, 0) / arr.length) * f) / f
}

export function SlaSection({ snapshot }: { snapshot: Snapshot }) {
  const t = snapshot.targets
  const a24 = mean(t.map((x) => x.uptime24h))
  const a7 = mean(t.map((x) => x.uptime7d))
  const a30 = mean(t.map((x) => x.uptime30d))

  const chartData = [...t]
    .sort((a, b) => a.uptime30d - b.uptime30d)
    .map((x) => ({ name: x.name, uptime: x.uptime30d, met: x.slaActual >= x.slaTarget }))

  const cards = [
    { label: "24h Availability", value: a24, window: "Rolling 24 hours" },
    { label: "7d Availability", value: a7, window: "Rolling 7 days" },
    { label: "30d Availability", value: a30, window: "Rolling 30 days" },
  ]

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        {cards.map((c) => (
          <div key={c.label} className="rounded-lg border border-border bg-card p-5">
            <div className="flex items-center gap-2 text-muted-foreground">
              <CalendarClock className="size-4" />
              <span className="text-xs font-medium uppercase tracking-wide">{c.label}</span>
            </div>
            <div className="mt-3 font-mono text-3xl font-semibold tabular-nums text-success">{c.value}%</div>
            <p className="mt-1 text-xs text-muted-foreground">{c.window}</p>
            <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-muted">
              <div className="h-full rounded-full bg-success" style={{ width: `${c.value}%` }} />
            </div>
          </div>
        ))}
      </div>

      <div className="rounded-lg border border-border bg-card p-4">
        <div className="mb-1 flex items-center justify-between">
          <h2 className="text-sm font-semibold">30-Day Availability by Target</h2>
          <span className="text-xs text-muted-foreground">SLA objective 99.9%</span>
        </div>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 8, bottom: 0, left: -8 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} tickLine={false} axisLine={false} interval={0} angle={-30} textAnchor="end" height={70} />
              <YAxis domain={[95, 100]} tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} tickLine={false} axisLine={false} width={44} unit="%" />
              <Tooltip
                cursor={{ fill: "var(--muted)", opacity: 0.4 }}
                contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 }}
                formatter={(v: number) => [`${v}%`, "Uptime"]}
              />
              <Bar dataKey="uptime" radius={[3, 3, 0, 0]}>
                {chartData.map((d, i) => (
                  <Cell key={i} fill={d.met ? "var(--chart-2)" : "var(--chart-3)"} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card">
        <div className="flex items-center gap-2 border-b border-border px-4 py-3">
          <TargetIcon className="size-4 text-muted-foreground" />
          <h2 className="text-sm font-semibold">SLA Compliance &amp; Availability Heatmap</h2>
        </div>
        <ul className="divide-y divide-border">
          {t.map((x) => {
            const met = x.slaActual >= x.slaTarget
            const errorBudget = Math.round((100 - x.slaTarget) * 30 * 24 * 60) // minutes/month allowed
            const usedRatio = Math.min(1, (x.slaTarget - x.slaActual + (100 - x.slaTarget)) / (100 - x.slaTarget))
            const budgetUsed = Math.max(0, Math.round(usedRatio * 100))
            return (
              <li key={x.id} className="grid grid-cols-1 items-center gap-3 px-4 py-3 lg:grid-cols-12">
                <div className="lg:col-span-3">
                  <p className="text-sm font-medium">{x.name}</p>
                  <p className="font-mono text-xs text-muted-foreground">{x.group}</p>
                </div>
                <div className="grid grid-cols-4 gap-2 lg:col-span-4">
                  <div>
                    <p className="text-[10px] uppercase text-muted-foreground">24h</p>
                    <p className={cn("font-mono text-sm", slaClass(x.uptime24h, 99.9))}>{x.uptime24h}%</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase text-muted-foreground">7d</p>
                    <p className={cn("font-mono text-sm", slaClass(x.uptime7d, 99.9))}>{x.uptime7d}%</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase text-muted-foreground">30d</p>
                    <p className={cn("font-mono text-sm", slaClass(x.uptime30d, 99.9))}>{x.uptime30d}%</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase text-muted-foreground">SLA</p>
                    <p className={cn("font-mono text-sm font-semibold", met ? "text-success" : "text-destructive")}>
                      {met ? "Met" : "Breach"}
                    </p>
                  </div>
                </div>
                <div className="lg:col-span-3">
                  <UptimeBars buckets={x.uptimeBars} />
                </div>
                <div className="lg:col-span-2">
                  <p className="text-[10px] uppercase text-muted-foreground">Error budget used</p>
                  <div className="mt-1 flex items-center gap-2">
                    <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
                      <div
                        className={cn("h-full rounded-full", budgetUsed > 80 ? "bg-destructive" : budgetUsed > 50 ? "bg-warning" : "bg-success")}
                        style={{ width: `${budgetUsed}%` }}
                      />
                    </div>
                    <span className="font-mono text-xs text-muted-foreground">{budgetUsed}%</span>
                  </div>
                  <p className="mt-0.5 font-mono text-[10px] text-muted-foreground">{errorBudget}m/mo budget</p>
                </div>
              </li>
            )
          })}
        </ul>
      </div>
    </div>
  )
}
