// client/src/components/UptimeTab.tsx
// Performance sidebar altındaki Uptime sekmesi.
// Mevcut ViewContext.tsx'e 'uptime' sayfası ekledikten sonra kullanılabilir.

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

// ─── Tipler ──────────────────────────────────────────────────────────────────
interface MonitoredUrl {
  id: number;
  label: string;
  url: string;
  intervalSeconds: number;
  timeoutMs: number;
  isActive: boolean;
}

interface UptimeSummary {
  globalUptime: number;
  avgLatencyMs: number;
  dnsHealth: string;
  totalUrls: number;
  urlsDown: number;
  urlsWarn: number;
}

interface UptimeCheck {
  id: number;
  urlId: number;
  checkedAt: string;
  statusCode: number | null;
  latencyMs: number | null;
  isUp: boolean;
  errorMessage: string | null;
  dnsResolved: boolean;
}

// ─── API istemcisi ────────────────────────────────────────────────────────────
const BASE = '/api/uptime';

const api = {
  getUrls: (): Promise<MonitoredUrl[]> => fetch(`${BASE}/urls`).then(r => r.json()),
  getSummary: (): Promise<UptimeSummary> => fetch(`${BASE}/summary`).then(r => r.json()),
  getChecks: (id: number): Promise<UptimeCheck[]> =>
    fetch(`${BASE}/urls/${id}/checks`).then(r => r.json()),
  addUrl: (data: Omit<MonitoredUrl, 'id' | 'isActive'>): Promise<MonitoredUrl> =>
    fetch(`${BASE}/urls`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }).then(r => r.json()),
  removeUrl: (id: number): Promise<void> =>
    fetch(`${BASE}/urls/${id}`, { method: 'DELETE' }).then(() => undefined),
};

// ─── Ana bileşen ──────────────────────────────────────────────────────────────
type ActiveTab = 'list' | 'preview' | 'add';

export function UptimeTab() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('list');
  const [selectedUrlId, setSelectedUrlId] = useState<number | null>(null);
  const qc = useQueryClient();

  const { data: urls = [] } = useQuery({
    queryKey: ['uptime-urls'],
    queryFn: api.getUrls,
    refetchInterval: 30_000,
  });

  const { data: summary } = useQuery({
    queryKey: ['uptime-summary'],
    queryFn: api.getSummary,
    refetchInterval: 30_000,
  });

  const addMutation = useMutation({
    mutationFn: api.addUrl,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['uptime-urls'] });
      setActiveTab('list');
    },
  });

  const removeMutation = useMutation({
    mutationFn: api.removeUrl,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['uptime-urls'] }),
  });

  return (
    <div className="flex flex-col gap-4">
      {/* Özet metrik kartlar */}
      {summary && <SummaryCards summary={summary} />}

      {/* Sekmeler */}
      <div className="flex border-b border-gray-200 dark:border-gray-700 gap-0">
        {(['list', 'preview', 'add'] as ActiveTab[]).map(t => (
          <button
            key={t}
            onClick={() => setActiveTab(t)}
            className={`px-4 py-2 text-sm border-b-2 transition-colors ${
              activeTab === t
                ? 'border-gray-900 text-gray-900 dark:border-white dark:text-white font-medium'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            {{ list: 'İzlenen URL\'ler', preview: 'Önizleme özeti', add: '+ URL ekle' }[t]}
          </button>
        ))}
      </div>

      {/* İzlenen URL'ler tablosu */}
      {activeTab === 'list' && (
        <UrlTable
          urls={urls}
          onRemove={id => removeMutation.mutate(id)}
          onSelectUrl={id => { setSelectedUrlId(id); setActiveTab('preview'); }}
        />
      )}

      {/* Önizleme özeti */}
      {activeTab === 'preview' && (
        <PreviewSummary urls={urls} selectedId={selectedUrlId} />
      )}

      {/* Yeni URL ekleme formu */}
      {activeTab === 'add' && (
        <AddUrlForm
          onSubmit={data => addMutation.mutate(data)}
          isLoading={addMutation.isPending}
        />
      )}
    </div>
  );
}

// ─── Özet kartlar ─────────────────────────────────────────────────────────────
function SummaryCards({ summary }: { summary: UptimeSummary }) {
  return (
    <div className="grid grid-cols-3 gap-3">
      <MetricCard label="Global uptime" value={`${summary.globalUptime}%`} sub="Son 30 gün" />
      <MetricCard label="Ort. gecikme" value={`${summary.avgLatencyMs}ms`} sub="Tüm URL'ler" />
      <MetricCard label="DNS sağlığı" value={summary.dnsHealth} sub="Timeout yok" />
    </div>
  );
}

function MetricCard({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
      <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">{label}</p>
      <p className="text-2xl font-medium">{value}</p>
      <p className="text-xs text-gray-400 mt-1">{sub}</p>
    </div>
  );
}

// ─── URL tablosu ──────────────────────────────────────────────────────────────
function UrlTable({
  urls,
  onRemove,
  onSelectUrl,
}: {
  urls: MonitoredUrl[];
  onRemove: (id: number) => void;
  onSelectUrl: (id: number) => void;
}) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-gray-200 dark:border-gray-700">
            {['Etiket', 'URL', 'Aralık', 'Timeout', ''].map(h => (
              <th key={h} className="text-left py-2 px-3 text-gray-500 font-normal">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {urls.map(u => (
            <tr key={u.id} className="border-b border-gray-100 dark:border-gray-800">
              <td className="py-2.5 px-3 font-medium">{u.label}</td>
              <td className="py-2.5 px-3 text-gray-500 text-xs">{u.url}</td>
              <td className="py-2.5 px-3">
                <span className="bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 px-2 py-0.5 rounded-full text-xs">
                  {u.intervalSeconds >= 60 ? `${u.intervalSeconds / 60}dk` : `${u.intervalSeconds}sn`}
                </span>
              </td>
              <td className="py-2.5 px-3 text-gray-500">{u.timeoutMs}ms</td>
              <td className="py-2.5 px-3">
                <div className="flex gap-2">
                  <button
                    onClick={() => onSelectUrl(u.id)}
                    className="text-xs text-blue-600 hover:underline"
                  >
                    Detay
                  </button>
                  <button
                    onClick={() => onRemove(u.id)}
                    className="text-xs text-red-500 hover:underline"
                  >
                    Kaldır
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── Önizleme özeti ───────────────────────────────────────────────────────────
function PreviewSummary({ urls, selectedId }: { urls: MonitoredUrl[]; selectedId: number | null }) {
  const filtered = selectedId ? urls.filter(u => u.id === selectedId) : urls;
  return (
    <div className="flex flex-col gap-3">
      {filtered.map(u => (
        <div key={u.id} className="border border-gray-200 dark:border-gray-700 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="font-medium">{u.label}</p>
              <p className="text-xs text-gray-400 mt-0.5">{u.url}</p>
            </div>
            <span className="text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 px-2 py-1 rounded-full">
              {u.intervalSeconds >= 60 ? `${u.intervalSeconds / 60}dk` : `${u.intervalSeconds}sn`} aralık
            </span>
          </div>
          <div className="grid grid-cols-2 gap-3 text-center">
            <div>
              <p className="text-sm font-medium">{u.timeoutMs / 1000}sn</p>
              <p className="text-xs text-gray-400">Timeout</p>
            </div>
            <div>
              <p className="text-sm font-medium">HTTP GET</p>
              <p className="text-xs text-gray-400">Kontrol yöntemi</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Yeni URL ekleme formu ────────────────────────────────────────────────────
function AddUrlForm({
  onSubmit,
  isLoading,
}: {
  onSubmit: (data: Omit<MonitoredUrl, 'id' | 'isActive'>) => void;
  isLoading: boolean;
}) {
  const [form, setForm] = useState({
    label: '',
    url: '',
    intervalSeconds: 60,
    timeoutMs: 5000,
  });

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm(f => ({ ...f, [k]: ['intervalSeconds', 'timeoutMs'].includes(k) ? Number(e.target.value) : e.target.value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.url) return;
    onSubmit(form);
  };

  const inputCls = 'w-full border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 text-sm bg-white dark:bg-gray-900 focus:outline-none focus:ring-1 focus:ring-gray-400';

  return (
    <form onSubmit={handleSubmit} className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4 flex flex-col gap-3">
      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-1">
          <label className="text-xs text-gray-500">Etiket</label>
          <input className={inputCls} placeholder="ör. Intranet Portal" value={form.label} onChange={set('label')} />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs text-gray-500">URL / hostname</label>
          <input className={inputCls} placeholder="https://internal.corp.local" value={form.url} onChange={set('url')} required />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs text-gray-500">Kontrol aralığı</label>
          <select className={inputCls} value={form.intervalSeconds} onChange={set('intervalSeconds')}>
            <option value={30}>30 saniye</option>
            <option value={60}>1 dakika</option>
            <option value={300}>5 dakika</option>
            <option value={600}>10 dakika</option>
            <option value={1800}>30 dakika</option>
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs text-gray-500">Timeout (ms)</label>
          <input type="number" className={inputCls} value={form.timeoutMs} onChange={set('timeoutMs')} min={500} max={30000} step={500} />
        </div>
      </div>
      <button
        type="submit"
        disabled={isLoading}
        className="self-start bg-gray-900 dark:bg-white text-white dark:text-gray-900 text-sm px-5 py-2 rounded-lg disabled:opacity-50"
      >
        {isLoading ? 'Ekleniyor...' : 'URL ekle'}
      </button>
    </form>
  );
}
