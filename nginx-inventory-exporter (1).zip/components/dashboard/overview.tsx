'use client'

import { useMemo } from 'react'
import { 
  Server, Route, Activity, ShieldCheck, 
  TrendingUp, AlertTriangle, CheckCircle, XCircle,
  Globe, Cpu, Network, Clock
} from 'lucide-react'
import { StatCard } from './stat-card'
import { NodeData, RouteData, HealthData, SSLData } from '@/lib/mock-data'
import { cn } from '@/lib/utils'

interface OverviewProps {
  nodes: NodeData[]
  routes: RouteData[]
  health: HealthData[]
  ssl: SSLData[]
}

export function Overview({ nodes, routes, health, ssl }: OverviewProps) {
  const stats = useMemo(() => {
    const totalConnections = nodes.reduce((sum, n) => sum + n.active_connections, 0)
    const avgUptime = Math.round(nodes.reduce((sum, n) => sum + n.uptime_days, 0) / nodes.length)
    const healthUp = health.filter(h => h.status === 'UP').length
    const healthDegraded = health.filter(h => h.status === 'DEGRADED').length
    const healthDown = health.filter(h => h.status === 'DOWN').length
    const sslExpiring = ssl.filter(s => s.days_left <= 30).length
    const sslCritical = ssl.filter(s => s.days_left <= 7).length
    const totalRequests = health.reduce((sum, h) => sum + h.total_requests, 0)
    const avgLatency = Math.round(health.reduce((sum, h) => sum + h.avg_latency_ms, 0) / health.length)
    
    return {
      nodes: nodes.length,
      routes: routes.length,
      totalConnections,
      avgUptime,
      healthUp,
      healthDegraded,
      healthDown,
      healthTotal: health.length,
      sslTotal: ssl.length,
      sslExpiring,
      sslCritical,
      totalRequests,
      avgLatency
    }
  }, [nodes, routes, health, ssl])

  const recentIssues = useMemo(() => {
    const issues: { type: 'health' | 'ssl', severity: 'critical' | 'warning', message: string }[] = []
    
    health.filter(h => h.status === 'DOWN').slice(0, 3).forEach(h => {
      issues.push({
        type: 'health',
        severity: 'critical',
        message: `${h.domain}${h.location} is DOWN (${h.error_5xx_pct}% error rate)`
      })
    })
    
    ssl.filter(s => s.days_left <= 7).forEach(s => {
      issues.push({
        type: 'ssl',
        severity: 'critical',
        message: `Certificate for ${s.subject.replace('CN=', '')} expires in ${s.days_left} days`
      })
    })
    
    health.filter(h => h.status === 'DEGRADED').slice(0, 2).forEach(h => {
      issues.push({
        type: 'health',
        severity: 'warning',
        message: `${h.domain}${h.location} is DEGRADED (${h.error_5xx_pct}% error rate)`
      })
    })

    ssl.filter(s => s.days_left > 7 && s.days_left <= 30).forEach(s => {
      issues.push({
        type: 'ssl',
        severity: 'warning',
        message: `Certificate for ${s.subject.replace('CN=', '')} expires in ${s.days_left} days`
      })
    })

    return issues.slice(0, 6)
  }, [health, ssl])

  return (
    <div className="space-y-6">
      {/* Main Stats */}
      <div className="grid grid-cols-4 gap-4">
        <StatCard
          title="Server Nodes"
          value={stats.nodes}
          subtitle={`${stats.totalConnections.toLocaleString()} active connections`}
          icon={Server}
        />
        <StatCard
          title="Routing Rules"
          value={stats.routes}
          subtitle={`Across ${new Set(routes.map(r => r.domain)).size} domains`}
          icon={Route}
        />
        <StatCard
          title="Endpoint Health"
          value={`${Math.round((stats.healthUp / stats.healthTotal) * 100)}%`}
          subtitle={`${stats.healthUp} up, ${stats.healthDegraded} degraded, ${stats.healthDown} down`}
          icon={Activity}
          variant={stats.healthDown > 0 ? 'error' : stats.healthDegraded > 0 ? 'warning' : 'success'}
        />
        <StatCard
          title="SSL Certificates"
          value={stats.sslTotal}
          subtitle={stats.sslExpiring > 0 ? `${stats.sslExpiring} expiring soon` : 'All certificates valid'}
          icon={ShieldCheck}
          variant={stats.sslCritical > 0 ? 'error' : stats.sslExpiring > 0 ? 'warning' : 'success'}
        />
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center gap-2 text-muted-foreground mb-3">
            <TrendingUp className="h-4 w-4" />
            <span className="text-sm">Total Requests</span>
          </div>
          <p className="text-2xl font-semibold">{(stats.totalRequests / 1000000).toFixed(2)}M</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center gap-2 text-muted-foreground mb-3">
            <Clock className="h-4 w-4" />
            <span className="text-sm">Avg Latency</span>
          </div>
          <p className="text-2xl font-semibold">{stats.avgLatency}ms</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center gap-2 text-muted-foreground mb-3">
            <Cpu className="h-4 w-4" />
            <span className="text-sm">Avg Uptime</span>
          </div>
          <p className="text-2xl font-semibold">{stats.avgUptime} days</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center gap-2 text-muted-foreground mb-3">
            <Network className="h-4 w-4" />
            <span className="text-sm">Active Connections</span>
          </div>
          <p className="text-2xl font-semibold">{stats.totalConnections.toLocaleString()}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* Recent Issues */}
        <div className="bg-card border border-border rounded-lg">
          <div className="px-4 py-3 border-b border-border flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-warning" />
            <h3 className="font-medium text-sm">Recent Issues</h3>
          </div>
          <div className="p-4 space-y-3">
            {recentIssues.length === 0 ? (
              <div className="flex items-center gap-2 text-success py-4 justify-center">
                <CheckCircle className="h-5 w-5" />
                <span>All systems operational</span>
              </div>
            ) : (
              recentIssues.map((issue, i) => (
                <div 
                  key={i}
                  className={cn(
                    "flex items-start gap-3 p-3 rounded-lg",
                    issue.severity === 'critical' ? "bg-destructive/10" : "bg-warning/10"
                  )}
                >
                  {issue.severity === 'critical' ? (
                    <XCircle className="h-4 w-4 text-destructive mt-0.5 shrink-0" />
                  ) : (
                    <AlertTriangle className="h-4 w-4 text-warning mt-0.5 shrink-0" />
                  )}
                  <p className={cn(
                    "text-sm",
                    issue.severity === 'critical' ? "text-destructive" : "text-warning"
                  )}>
                    {issue.message}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Quick Stats by Domain */}
        <div className="bg-card border border-border rounded-lg">
          <div className="px-4 py-3 border-b border-border flex items-center gap-2">
            <Globe className="h-4 w-4 text-primary" />
            <h3 className="font-medium text-sm">Top Domains by Traffic</h3>
          </div>
          <div className="p-4 space-y-3">
            {(() => {
              const domainStats = health.reduce((acc, h) => {
                if (!acc[h.domain]) acc[h.domain] = { requests: 0, errors: 0 }
                acc[h.domain].requests += h.total_requests
                acc[h.domain].errors += h.total_requests * (h.error_5xx_pct / 100)
                return acc
              }, {} as Record<string, { requests: number, errors: number }>)

              return Object.entries(domainStats)
                .sort((a, b) => b[1].requests - a[1].requests)
                .slice(0, 5)
                .map(([domain, data]) => {
                  const errorRate = (data.errors / data.requests) * 100
                  return (
                    <div key={domain} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                      <span className="font-mono text-sm text-primary">{domain}</span>
                      <div className="flex items-center gap-4">
                        <span className="text-sm text-muted-foreground">
                          {(data.requests / 1000).toFixed(1)}K req
                        </span>
                        <span className={cn(
                          "text-xs font-mono",
                          errorRate > 5 ? "text-destructive" : 
                          errorRate > 2 ? "text-warning" : "text-success"
                        )}>
                          {errorRate.toFixed(1)}% err
                        </span>
                      </div>
                    </div>
                  )
                })
            })()}
          </div>
        </div>
      </div>
    </div>
  )
}
