'use client'

import { useState } from 'react'
import { 
  Server, Route, Activity, ShieldCheck, Search, 
  ChevronRight, Globe, Cpu, HardDrive, Clock, 
  Network, Settings, BarChart3, RefreshCw
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface NavItem {
  id: string
  label: string
  icon: React.ReactNode
  badge?: number
}

const navItems: NavItem[] = [
  { id: 'overview', label: 'Overview', icon: <BarChart3 className="h-4 w-4" /> },
  { id: 'nodes', label: 'Nodes', icon: <Server className="h-4 w-4" /> },
  { id: 'routes', label: 'Routes', icon: <Route className="h-4 w-4" /> },
  { id: 'health', label: 'Health', icon: <Activity className="h-4 w-4" /> },
  { id: 'ssl', label: 'SSL Certificates', icon: <ShieldCheck className="h-4 w-4" /> },
]

interface SidebarProps {
  activeTab: string
  onTabChange: (tab: string) => void
  stats: {
    nodes: number
    routes: number
    healthIssues: number
    sslExpiring: number
  }
}

export function Sidebar({ activeTab, onTabChange, stats }: SidebarProps) {
  const getBadge = (id: string) => {
    switch (id) {
      case 'nodes': return stats.nodes
      case 'routes': return stats.routes
      case 'health': return stats.healthIssues > 0 ? stats.healthIssues : undefined
      case 'ssl': return stats.sslExpiring > 0 ? stats.sslExpiring : undefined
      default: return undefined
    }
  }

  const getBadgeVariant = (id: string) => {
    if (id === 'health' && stats.healthIssues > 0) return 'destructive'
    if (id === 'ssl' && stats.sslExpiring > 0) return 'warning'
    return 'default'
  }

  return (
    <aside className="w-64 bg-sidebar border-r border-sidebar-border flex flex-col">
      {/* Logo */}
      <div className="h-16 flex items-center gap-3 px-4 border-b border-sidebar-border">
        <div className="h-8 w-8 rounded-lg bg-primary/20 flex items-center justify-center">
          <Globe className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h1 className="text-sm font-semibold text-sidebar-foreground">Nginx WebUI</h1>
          <p className="text-xs text-muted-foreground">Reverse Proxy Manager</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1">
        {navItems.map((item) => {
          const badge = getBadge(item.id)
          const badgeVariant = getBadgeVariant(item.id)
          
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors",
                activeTab === item.id
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
              )}
            >
              {item.icon}
              <span className="flex-1 text-left">{item.label}</span>
              {badge !== undefined && (
                <span className={cn(
                  "px-2 py-0.5 rounded-full text-xs font-medium",
                  badgeVariant === 'destructive' && "bg-destructive/20 text-destructive",
                  badgeVariant === 'warning' && "bg-warning/20 text-warning",
                  badgeVariant === 'default' && "bg-muted text-muted-foreground"
                )}>
                  {badge}
                </span>
              )}
              {activeTab === item.id && (
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              )}
            </button>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <div className="h-2 w-2 rounded-full bg-success animate-pulse" />
          <span>Connected to cluster</span>
        </div>
      </div>
    </aside>
  )
}
