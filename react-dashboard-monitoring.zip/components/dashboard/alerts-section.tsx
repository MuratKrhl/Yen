"use client"

import { useState } from "react"
import { AlertCircle, BellRing, CheckCircle2, Info, TriangleAlert } from "lucide-react"
import type { Incident, Snapshot } from "@/lib/monitoring"
import { cn } from "@/lib/utils"
import { fmtDuration, fmtTime, timeAgo } from "@/lib/format"

const SEV = {
  critical: { icon: AlertCircle, text: "text-destructive", bg: "bg-destructive/15", border: "border-destructive/30", label: "Critical" },
  warning: { icon: TriangleAlert, text: "text-warning", bg: "bg-warning/15", border: "border-warning/30", label: "Warning" },
  info: { icon: Info, text: "text-primary", bg: "bg-primary/15", border: "border-primary/30", label: "Info" },
} as const

function IncidentRow({ inc }: { inc: Incident }) {
  const sev = SEV[inc.severity]
  const Icon = sev.icon
  return (
    <li className="flex gap-3 px-4 py-3">
      <div className={cn("mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-full", sev.bg)}>
        <Icon className={cn("size-4", sev.text)} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-sm font-medium">{inc.targetName}</span>
          <span className={cn("rounded border px-1.5 py-0.5 text-[10px] font-medium uppercase", sev.bg, sev.border, sev.text)}>
            {inc.type}
          </span>
          {inc.active ? (
            <span className="flex items-center gap-1 text-xs text-destructive">
              <span className="size-1.5 animate-pulse-dot rounded-full bg-destructive" /> Ongoing
            </span>
          ) : (
            <span className="flex items-center gap-1 text-xs text-success">
              <CheckCircle2 className="size-3" /> Resolved
            </span>
          )}
        </div>
        <p className="mt-1 text-sm text-muted-foreground">{inc.message}</p>
        <div className="mt-1 flex flex-wrap gap-x-4 gap-y-0.5 font-mono text-xs text-muted-foreground">
          <span>Started {fmtTime(inc.startedAt)} · {timeAgo(inc.startedAt)}</span>
          <span>Duration {fmtDuration(inc.durationMin)}</span>
          {inc.resolvedAt && <span>Resolved {fmtTime(inc.resolvedAt)}</span>}
        </div>
      </div>
    </li>
  )
}

export function AlertsSection({ snapshot }: { snapshot: Snapshot }) {
  const [filter, setFilter] = useState<"all" | "active" | "critical" | "warning" | "resolved">("all")

  const counts = {
    active: snapshot.incidents.filter((i) => i.active).length,
    critical: snapshot.incidents.filter((i) => i.severity === "critical").length,
    warning: snapshot.incidents.filter((i) => i.severity === "warning").length,
    resolved: snapshot.incidents.filter((i) => !i.active).length,
  }

  const filtered = snapshot.incidents.filter((i) => {
    if (filter === "all") return true
    if (filter === "active") return i.active
    if (filter === "resolved") return !i.active
    return i.severity === filter
  })

  const tabs: { key: typeof filter; label: string; count?: number }[] = [
    { key: "all", label: "All", count: snapshot.incidents.length },
    { key: "active", label: "Active", count: counts.active },
    { key: "critical", label: "Critical", count: counts.critical },
    { key: "warning", label: "Warning", count: counts.warning },
    { key: "resolved", label: "Resolved", count: counts.resolved },
  ]

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div className="rounded-lg border border-border bg-card p-4">
          <div className="flex items-center gap-2 text-muted-foreground">
            <BellRing className="size-4" />
            <span className="text-xs font-medium uppercase tracking-wide">Active</span>
          </div>
          <p className={cn("mt-3 font-mono text-2xl font-semibold", counts.active > 0 ? "text-destructive" : "text-success")}>
            {counts.active}
          </p>
        </div>
        <div className="rounded-lg border border-border bg-card p-4">
          <div className="flex items-center gap-2 text-muted-foreground">
            <AlertCircle className="size-4" />
            <span className="text-xs font-medium uppercase tracking-wide">Critical</span>
          </div>
          <p className="mt-3 font-mono text-2xl font-semibold text-destructive">{counts.critical}</p>
        </div>
        <div className="rounded-lg border border-border bg-card p-4">
          <div className="flex items-center gap-2 text-muted-foreground">
            <TriangleAlert className="size-4" />
            <span className="text-xs font-medium uppercase tracking-wide">Warning</span>
          </div>
          <p className="mt-3 font-mono text-2xl font-semibold text-warning">{counts.warning}</p>
        </div>
        <div className="rounded-lg border border-border bg-card p-4">
          <div className="flex items-center gap-2 text-muted-foreground">
            <CheckCircle2 className="size-4" />
            <span className="text-xs font-medium uppercase tracking-wide">Resolved</span>
          </div>
          <p className="mt-3 font-mono text-2xl font-semibold text-success">{counts.resolved}</p>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card">
        <div className="flex flex-wrap items-center gap-1 border-b border-border px-3 py-2">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key)}
              className={cn(
                "rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                filter === tab.key ? "bg-accent text-foreground" : "text-muted-foreground hover:text-foreground",
              )}
            >
              {tab.label}
              {tab.count !== undefined && <span className="ml-1.5 font-mono text-muted-foreground">{tab.count}</span>}
            </button>
          ))}
        </div>
        {filtered.length ? (
          <ul className="divide-y divide-border">
            {filtered.map((inc) => (
              <IncidentRow key={inc.id} inc={inc} />
            ))}
          </ul>
        ) : (
          <div className="flex flex-col items-center justify-center gap-2 py-12 text-muted-foreground">
            <CheckCircle2 className="size-8 text-success" />
            <p className="text-sm">No incidents match this filter.</p>
          </div>
        )}
      </div>
    </div>
  )
}
