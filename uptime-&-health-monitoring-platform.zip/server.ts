import express from "express";
import path from "path";
import dns from "dns";
import tls from "tls";
import net from "net";
import fs from "fs";
import { exec } from "child_process";
import { createServer as createViteServer } from "vite";
import { Target, CheckResult, Incident, TargetStats, SSLStatus, DNSStatus, HeaderAnalysis } from "./src/types";

const app = express();
const PORT = 3000;

app.use(express.json());

// Path to data file
const DATA_DIR = path.join(process.cwd(), "src", "data");
const DATA_FILE = path.join(DATA_DIR, "db.json");

// Ensure data folder exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initial default targets
const DEFAULT_TARGETS: Target[] = [
  {
    id: "cloudflare-dns",
    name: "Cloudflare Core Gateway",
    url: "https://1.1.1.1",
    type: "HTTPS",
    interval: 15,
    enabled: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: "github-web",
    name: "GitHub Production Portal",
    url: "https://github.com",
    type: "HTTPS",
    interval: 15,
    keyword: "GitHub",
    enabled: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: "google-dns-dns",
    name: "Google Public DNS Name Resolver",
    url: "8.8.8.8",
    type: "DNS",
    interval: 15,
    enabled: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: "opendns-routing",
    name: "OpenDNS Routing Node",
    url: "208.67.222.222",
    type: "PING",
    interval: 15,
    enabled: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: "failing-service",
    name: "Legacy Auth API Endpoint (Simulated Error)",
    url: "https://nonexistent-auth-api-auth0-service.com",
    type: "HTTPS",
    interval: 15,
    enabled: true,
    createdAt: new Date().toISOString(),
  }
];

// In-Memory Database State
let targets: Target[] = [...DEFAULT_TARGETS];
let checkResults: Record<string, CheckResult[]> = {};
let incidents: Incident[] = [
  {
    id: "inc-001",
    targetId: "failing-service",
    targetName: "Legacy Auth API Endpoint (Simulated Error)",
    url: "https://nonexistent-auth-api-auth0-service.com",
    type: "Downtime",
    status: "ACTIVE",
    message: "Name resolution failed: ENOTFOUND. Host is offline.",
    startedAt: new Date(Date.now() - 3600000).toISOString(), // 1 hour ago
  }
];
let ansibleLogs: any[] = [];

// Load state from db.json if exists
const loadData = () => {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
      if (data.targets) targets = data.targets;
      if (data.checkResults) checkResults = data.checkResults;
      if (data.incidents) incidents = data.incidents;
      if (data.ansibleLogs) ansibleLogs = data.ansibleLogs;
      console.log("Database loaded successfully from db.json");
    } else {
      // Seed initial history
      generateMockHistoricalData();
      saveData();
    }
  } catch (e) {
    console.error("Error loading data:", e);
    generateMockHistoricalData();
  }
};

const saveData = () => {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify({ targets, checkResults, incidents, ansibleLogs }, null, 2));
  } catch (e) {
    console.error("Error saving data:", e);
  }
};

// Generates beautiful realistic history on initial start
function generateMockHistoricalData() {
  const now = Date.now();
  const fifteenSec = 15000;
  
  targets.forEach((target) => {
    checkResults[target.id] = [];
    const isFailing = target.id === "failing-service";
    
    // Generate last 30 intervals of historical run
    for (let i = 30; i >= 1; i--) {
      const timestamp = new Date(now - i * fifteenSec).toISOString();
      const status = isFailing ? "DOWN" : "UP";
      
      const dns_base = target.type === "DNS" ? 2 : Math.random() * 15 + 3;
      const tcp_base = target.type === "PING" ? 0 : Math.random() * 20 + 5;
      const tls_base = target.type === "HTTPS" ? Math.random() * 30 + 10 : 0;
      const ttfb_base = target.type === "HTTPS" || target.type === "HTTP" ? Math.random() * 50 + 20 : 0;
      const total_base = isFailing ? 0 : (dns_base + tcp_base + tls_base + ttfb_base + Math.random() * 30 + 10);

      const check: CheckResult = {
        id: `chk-${target.id}-${i}-${now}`,
        targetId: target.id,
        timestamp,
        status,
        statusCode: isFailing ? undefined : (target.type === "HTTPS" || target.type === "HTTP" ? 200 : undefined),
        dns_ms: Math.round(dns_base),
        tcp_ms: Math.round(tcp_base),
        tls_ms: Math.round(tls_base),
        ttfb_ms: Math.round(ttfb_base),
        total_ms: Math.round(total_base),
        latency_avg: Math.round(total_base > 0 ? total_base : (Math.random() * 15 + 10)),
        packet_loss: isFailing ? 100 : (target.type === "PING" ? (Math.random() > 0.95 ? 33 : 0) : 0),
        ssl: target.type === "HTTPS" && !isFailing ? {
          status: "VALID",
          expires: new Date(now + 63 * 24 * 60 * 60 * 1000).toISOString(), // 63 days remaining
          days_remaining: 63,
          issuer: "Let's Encrypt Authority",
        } : undefined,
        dns: {
          status: isFailing ? "ERROR" : "OK",
          ip: isFailing ? undefined : (target.url.includes("1.1.1.1") ? "1.1.1.1" : "140.82.121.4"),
          ttl: 300,
          resolve_ms: Math.round(dns_base),
          records: isFailing ? [] : [
            { type: "A", value: target.type === "DNS" || target.type === "PING" ? target.url : "140.82.121.4" }
          ]
        },
        headers: (target.type === "HTTPS" || target.type === "HTTP") && !isFailing ? {
          server: "Apache/nginx/cloudflare",
          hsts: true,
          csp: Math.random() > 0.3,
          xfo: true
        } : undefined,
        keyword_found: target.keyword ? true : undefined,
        error: isFailing ? "Name resolution failed: ENOTFOUND" : undefined
      };
      
      checkResults[target.id].push(check);
    }
  });
}

// Collector helpers

// 1. SSL Status Retrieval
const getSSLStatus = (hostname: string, port: number = 443): Promise<SSLStatus> => {
  return new Promise((resolve) => {
    try {
      // Strip http:// or https:// if provided in hostname
      let host = hostname.replace(/https?:\/\//i, "").split("/")[0].split(":")[0];
      
      // If it's an IP address, SSL checks might fail or not be relevant
      if (/^[0-9.]+$/.test(host)) {
        return resolve({ status: "NONE", error: "SSL parameters are skipped for plain IP addresses." });
      }

      const socket = tls.connect({
        host,
        port,
        servername: host,
        rejectUnauthorized: false,
        timeout: 4000
      }, () => {
        const cert = socket.getPeerCertificate();
        if (!cert || !cert.valid_to) {
          resolve({ status: "NONE", error: "No peer security certificate present" });
          socket.destroy();
          return;
        }

        const validTo = new Date(cert.valid_to);
        const now = new Date();
        const diffMs = validTo.getTime() - now.getTime();
        const daysRemaining = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));

        let status: "VALID" | "WARNING" | "EXPIRED" = "VALID";
        if (daysRemaining <= 0) {
          status = "EXPIRED";
        } else if (daysRemaining <= 15) {
          status = "WARNING";
        }

        const issuerField = cert.issuer.O || cert.issuer.CN || "Security Provider Authorities";
        const issuerName = Array.isArray(issuerField) ? issuerField[0] : issuerField;

        resolve({
          status,
          expires: validTo.toISOString(),
          days_remaining: daysRemaining,
          issuer: issuerName
        });
        socket.destroy();
      });

      socket.on("error", (err) => {
        resolve({ status: "NONE", error: err.message });
      });

      socket.on("timeout", () => {
        resolve({ status: "NONE", error: "SSL verification timed out (4s)" });
        socket.destroy();
      });
    } catch (e: any) {
      resolve({ status: "NONE", error: e.message });
    }
  });
};

// 2. DNS Status Retrieval
const getDNSStatus = (hostname: string): Promise<DNSStatus> => {
  return new Promise((resolve) => {
    let cleanHost = hostname.replace(/https?:\/\//i, "").split("/")[0].split(":")[0];
    const dnsStart = Date.now();
    
    dns.resolve4(cleanHost, (err, addresses) => {
      const dns_ms = Date.now() - dnsStart;
      if (err || !addresses || addresses.length === 0) {
        resolve({
          status: "ERROR",
          error: err?.message || "Address unresolvable",
          resolve_ms: dns_ms
        });
      } else {
        const records = addresses.map(ip => ({ type: "A", value: ip }));
        resolve({
          status: "OK",
          ip: addresses[0],
          ttl: 299,
          resolve_ms: dns_ms,
          records
        });
      }
    });
  });
};

// 3. Ping Protocol Execution
const getPingLatency = (hostname: string): Promise<{ avg: number; max: number; loss: number }> => {
  return new Promise((resolve) => {
    let host = hostname.replace(/https?:\/\//i, "").split("/")[0].split(":")[0];
    const isWindows = process.platform === "win32";
    const cmd = isWindows ? `ping -n 3 ${host}` : `ping -c 3 -W 2 ${host}`;

    exec(cmd, (error, stdout, stderr) => {
      if (error || stderr) {
        // Fallback: TCP port socket timing
        const socketStart = Date.now();
        const client = net.connect({ host, port: 80, timeout: 2000 }, () => {
          const latency = Date.now() - socketStart;
          client.end();
          resolve({ avg: latency, max: latency + 5, loss: 0 });
        });
        client.on("error", () => {
          resolve({ avg: 0, max: 0, loss: 100 });
        });
        return;
      }

      let avg = 0;
      let max = 0;
      let loss = 0;

      try {
        if (isWindows) {
          const lossMatch = stdout.match(/Lost = (\d+) \((\d+)% loss\)/);
          if (lossMatch) loss = parseInt(lossMatch[2]);
          const avgMatch = stdout.match(/Average = (\d+)ms/);
          if (avgMatch) avg = parseInt(avgMatch[1]);
          const maxMatch = stdout.match(/Maximum = (\d+)ms/);
          if (maxMatch) max = parseInt(maxMatch[1]);
        } else {
          const lossMatch = stdout.match(/(\d+)% packet loss/);
          if (lossMatch) loss = parseInt(lossMatch[1]);
          
          const rttLine = stdout.split("\n").find(l => l.includes("rtt min/avg/max"));
          if (rttLine) {
            const parts = rttLine.split("=")[1].trim().split("/");
            avg = parseFloat(parts[1]);
            max = parseFloat(parts[2]);
          } else {
            // simpler ping output parser
            const matchTime = stdout.match(/time=(\d+(\.\d+)?)\s*ms/);
            if (matchTime) {
              avg = parseFloat(matchTime[1]);
              max = avg;
            }
          }
        }
      } catch (e) {
        // use basic fallbacks
      }
      resolve({
        avg: Math.round(avg) || 10,
        max: Math.round(max) || 15,
        loss
      });
    });
  });
};

// 4. Full Timing Phase HTTP Request Collector
import https from "https";
import http from "http";

const runTargetMonitorCheck = async (target: Target): Promise<CheckResult> => {
  return new Promise(async (resolve) => {
    const isHTTPS = target.url.startsWith("https://") || target.type === "HTTPS";
    // Prepare endpoint hostname & parameters
    let rawUrl = target.url;
    if (!rawUrl.startsWith("http://") && !rawUrl.startsWith("https://")) {
      rawUrl = isHTTPS ? `https://${rawUrl}` : `http://${rawUrl}`;
    }

    let parsedUrl: URL;
    try {
      parsedUrl = new URL(rawUrl);
    } catch (e) {
      // Invalid URL handle
      return resolve({
        id: `chk-${target.id}-${Date.now()}`,
        targetId: target.id,
        timestamp: new Date().toISOString(),
        status: "DOWN",
        dns_ms: 0,
        tcp_ms: 0,
        tls_ms: 0,
        ttfb_ms: 0,
        total_ms: 0,
        latency_avg: 0,
        packet_loss: 0,
        error: "Malformed target web routing address URL"
      });
    }

    const host = parsedUrl.hostname;
    const port = parsedUrl.port ? parseInt(parsedUrl.port) : (isHTTPS ? 443 : 80);

    const sslPromise = isHTTPS ? getSSLStatus(host, port) : Promise.resolve<SSLStatus>({ status: "NONE" });
    const dnsPromise = getDNSStatus(host);
    const pingPromise = getPingLatency(host);

    const [sslResult, dnsResult, pingResult] = await Promise.all([sslPromise, dnsPromise, pingPromise]);

    if (target.type === "DNS") {
      const isOK = dnsResult.status === "OK";
      return resolve({
        id: `chk-${target.id}-${Date.now()}`,
        targetId: target.id,
        timestamp: new Date().toISOString(),
        status: isOK ? "UP" : "DOWN",
        dns_ms: dnsResult.resolve_ms || 10,
        tcp_ms: 0,
        tls_ms: 0,
        ttfb_ms: 0,
        total_ms: dnsResult.resolve_ms || 10,
        latency_avg: dnsResult.resolve_ms || 10,
        packet_loss: isOK ? 0 : 100,
        dns: dnsResult,
        error: isOK ? undefined : dnsResult.error
      });
    }

    if (target.type === "PING") {
      const isUp = pingResult.loss < 100;
      return resolve({
        id: `chk-${target.id}-${Date.now()}`,
        targetId: target.id,
        timestamp: new Date().toISOString(),
        status: isUp ? "UP" : "DOWN",
        dns_ms: dnsResult.resolve_ms || 10,
        tcp_ms: 0,
        tls_ms: 0,
        ttfb_ms: 0,
        total_ms: pingResult.avg,
        latency_avg: pingResult.avg,
        packet_loss: pingResult.loss,
        dns: dnsResult,
        error: isUp ? undefined : "Ping failed: High ICMP Packet Loss rate reached 100%"
      });
    }

    // Now standard HTTP/HTTPS Timings
    const requester = isHTTPS ? https : http;
    const requestOptions = {
      hostname: host,
      port,
      path: parsedUrl.pathname + parsedUrl.search,
      method: "GET",
      headers: {
        "User-Agent": "SentinelUptimeCollector/1.0.0 (Health Check Engine)",
        "Accept": "*/*",
        "Connection": "close"
      },
      agent: false, // force new socket closure to avoid timing cache
      rejectUnauthorized: false // we resolve manually downstream
    };

    const start = Date.now();
    let dnsResolvedTime = 0;
    let tcpConnectedTime = 0;
    let tlsConnectedTime = 0;
    let firstByteTime = 0;

    const timings = {
      dns_ms: 0,
      tcp_ms: 0,
      tls_ms: 0,
      ttfb_ms: 0,
      total_ms: 0
    };

    let responseData = "";
    let status: "UP" | "DOWN" = "DOWN";
    let statusCode: number | undefined;
    let headersAnalysis: HeaderAnalysis = { hsts: false, csp: false, xfo: false };
    let errorMessage: string | undefined;

    const req = requester.request(requestOptions, (res) => {
      statusCode = res.statusCode;
      status = (res.statusCode && res.statusCode >= 200 && res.statusCode < 400) ? "UP" : "DOWN";

      res.once("data", () => {
        firstByteTime = Date.now();
        timings.ttfb_ms = firstByteTime - start;
      });

      res.on("data", (chunk) => {
        responseData += chunk.toString();
        if (responseData.length > 50000) {
          // cap size to save RAM
          responseData = responseData.substring(0, 50000);
        }
      });

      // Analyze Security Headers
      const headers = res.headers;
      headersAnalysis = {
        server: (headers.server as string) || "Unknown",
        hsts: !!headers["strict-transport-security"],
        csp: !!headers["content-security-policy"],
        xfo: !!headers["x-frame-options"]
      };

      res.on("end", () => {
        timings.total_ms = Date.now() - start;
        
        // Calculate incremental phase times
        if (dnsResolvedTime > 0) {
          timings.dns_ms = dnsResolvedTime - start;
        } else {
          timings.dns_ms = dnsResult.resolve_ms || 2;
        }

        if (tcpConnectedTime > 0) {
          timings.tcp_ms = tcpConnectedTime - (dnsResolvedTime || start);
        } else {
          timings.tcp_ms = 10;
        }

        if (isHTTPS && tlsConnectedTime > 0) {
          timings.tls_ms = tlsConnectedTime - tcpConnectedTime;
        }

        if (timings.ttfb_ms === 0) {
          timings.ttfb_ms = Math.round(timings.total_ms * 0.7);
        }

        // Content word validation
        let keyword_found = undefined;
        if (target.keyword) {
          keyword_found = responseData.toLowerCase().includes(target.keyword.toLowerCase());
          if (!keyword_found) {
            status = "DOWN"; // Fail health-check if keyword is absent
            errorMessage = `Content pattern payload verification failed: Keyword '${target.keyword}' not found in landing body.`;
          }
        }

        resolve({
          id: `chk-${target.id}-${Date.now()}`,
          targetId: target.id,
          timestamp: new Date().toISOString(),
          status,
          statusCode,
          dns_ms: Math.round(timings.dns_ms),
          tcp_ms: Math.round(timings.tcp_ms),
          tls_ms: Math.round(timings.tls_ms),
          ttfb_ms: Math.round(timings.ttfb_ms),
          total_ms: Math.round(timings.total_ms),
          latency_avg: Math.round(timings.total_ms),
          packet_loss: pingResult.loss,
          ssl: sslResult,
          dns: dnsResult,
          headers: headersAnalysis,
          keyword_found,
          error: errorMessage
        });
      });
    });

    req.on("socket", (socket) => {
      socket.on("lookup", () => {
        dnsResolvedTime = Date.now();
      });
      socket.on("connect", () => {
        tcpConnectedTime = Date.now();
      });
      socket.on("secureConnect", () => {
        tlsConnectedTime = Date.now();
      });
    });

    req.on("error", (err) => {
      timings.total_ms = Date.now() - start;
      resolve({
        id: `chk-${target.id}-${Date.now()}`,
        targetId: target.id,
        timestamp: new Date().toISOString(),
        status: "DOWN",
        dns_ms: Math.round(dnsResult.resolve_ms || 5),
        tcp_ms: 0,
        tls_ms: 0,
        ttfb_ms: 0,
        total_ms: Math.round(timings.total_ms),
        latency_avg: Math.round(pingResult.avg || timings.total_ms),
        packet_loss: 100,
        ssl: sslResult.status !== "NONE" ? sslResult : undefined,
        dns: dnsResult,
        error: `Endpoint connection failed: ${err.message}`
      });
    });

    req.setTimeout(8000, () => {
      req.destroy();
      resolve({
        id: `chk-${target.id}-${Date.now()}`,
        targetId: target.id,
        timestamp: new Date().toISOString(),
        status: "DOWN",
        dns_ms: 0,
        tcp_ms: 0,
        tls_ms: 0,
        ttfb_ms: 0,
        total_ms: 8000,
        latency_avg: 0,
        packet_loss: 100,
        error: "Collector socket wait timeout reached (8000ms)"
      });
    });

    req.end();
  });
};

// Scheduler background loop
const runGlobalMonitoringCycle = async () => {
  console.log(`[MONITOR] Starting active check loop at ${new Date().toISOString()}`);
  
  for (const target of targets) {
    if (!target.enabled) continue;
    
    // Execute
    const result = await runTargetMonitorCheck(target);
    
    // Manage results array (capacity cap: last 50 entries to keep it fast)
    if (!checkResults[target.id]) {
      checkResults[target.id] = [];
    }
    checkResults[target.id].push(result);
    if (checkResults[target.id].length > 50) {
      checkResults[target.id].shift();
    }

    // Incidents Management
    const last2 = checkResults[target.id].slice(-2);
    const becameDown = last2.length >= 1 && last2[last2.length - 1].status === "DOWN";
    const becameUp = last2.length >= 2 && last2[last2.length - 2].status === "DOWN" && last2[last2.length - 1].status === "UP";
    
    const activeIncident = incidents.find(inc => inc.targetId === target.id && inc.status === "ACTIVE");

    if (becameDown && !activeIncident) {
      // Trigger new alert incident
      const newInc: Incident = {
        id: `inc-${Date.now()}`,
        targetId: target.id,
        targetName: target.name,
        url: target.url,
        type: target.type === "PING" ? "Network" : (target.type === "DNS" ? "DNS" : "Downtime"),
        status: "ACTIVE",
        message: result.error || "Uptime criteria failed: Service responded with non-2xx check status.",
        startedAt: new Date().toISOString()
      };
      incidents.unshift(newInc);
      console.log(`[ALERT] High-priority incident sparked for: ${target.name}`);
    } else if (becameUp && activeIncident) {
      // Resolve incident
      activeIncident.status = "RESOLVED";
      activeIncident.resolvedAt = new Date().toISOString();
      console.log(`[ALERT] Incident resolved automatically for: ${target.name}`);
    }
  }

  saveData();
};

// Load existing data or mock and initialize loop
loadData();
setInterval(runGlobalMonitoringCycle, 20000); // cycle run every 20 seconds

// API routes FIRST

// 1. Get Targets
app.get("/api/targets", (req, res) => {
  res.json(targets);
});

// 2. Add Target
app.post("/api/targets", (req, res) => {
  const { name, url, type, interval, keyword, port } = req.body;
  if (!name || !url || !type) {
    return res.status(400).json({ error: "Required details: Target name, system URL, probe type." });
  }

  const newTarget: Target = {
    id: `tgt-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    name,
    url,
    type,
    interval: interval || 15,
    keyword: keyword || undefined,
    port: port ? parseInt(port) : undefined,
    enabled: true,
    createdAt: new Date().toISOString()
  };

  targets.push(newTarget);
  checkResults[newTarget.id] = [];
  
  // Instantly queue a live check for quick loading
  runTargetMonitorCheck(newTarget).then(r => {
    checkResults[newTarget.id].push(r);
    saveData();
  });

  res.status(201).json(newTarget);
});

// 3. Edit Target Status/Rules
app.put("/api/targets/:id", (req, res) => {
  const { id } = req.params;
  const targetIndex = targets.findIndex(t => t.id === id);
  if (targetIndex === -1) {
    return res.status(404).json({ error: "Target not located in Sentinel system logs" });
  }

  const updated = { ...targets[targetIndex], ...req.body };
  targets[targetIndex] = updated;
  saveData();
  res.json(updated);
});

// 4. Delete Target
app.delete("/api/targets/:id", (req, res) => {
  const { id } = req.params;
  targets = targets.filter(t => t.id !== id);
  delete checkResults[id];
  // Remove related active alerts too
  incidents = incidents.filter(i => !(i.targetId === id && i.status === "ACTIVE"));
  saveData();
  res.json({ success: true, message: "Target deleted successfully from pool" });
});

// 5. Trigger Instant check run
app.post("/api/targets/:id/check", async (req, res) => {
  const { id } = req.params;
  const target = targets.find(t => t.id === id);
  if (!target) return res.status(404).json({ error: "Target not found" });

  const result = await runTargetMonitorCheck(target);
  
  if (!checkResults[target.id]) checkResults[target.id] = [];
  checkResults[target.id].push(result);
  if (checkResults[target.id].length > 50) checkResults[target.id].shift();
  
  saveData();
  res.json(result);
});

// 6. Get Historical check logs
app.get("/api/targets/:id/history", (req, res) => {
  const { id } = req.params;
  const results = checkResults[id] || [];
  res.json(results);
});

// 7. Dashboard overall aggregator cards stats
app.get("/api/dashboard/stats", (req, res) => {
  const total = targets.length;
  const enabledTargets = targets.filter(t => t.enabled);
  
  let up = 0;
  let down = 0;
  let activeIncidentsCount = incidents.filter(i => i.status === "ACTIVE").length;
  let responseTimesSum = 0;
  let responseTimesCount = 0;
  let sslExpiringCount = 0;
  let totalPacketLossSum = 0;
  let packetLossCount = 0;

  targets.forEach(t => {
    const history = checkResults[t.id] || [];
    if (history.length > 0) {
      const last = history[history.length - 1];
      if (last.status === "UP") up++;
      else if (t.enabled) down++;

      // Response times
      if (last.status === "UP" && last.total_ms > 0) {
        responseTimesSum += last.total_ms;
        responseTimesCount++;
      }

      // SSL expiring countdown
      if (last.ssl && last.ssl.days_remaining !== undefined && last.ssl.days_remaining <= 15 && last.ssl.days_remaining > 0) {
        sslExpiringCount++;
      }

      // Packet Loss
      if (last.packet_loss !== undefined) {
        totalPacketLossSum += last.packet_loss;
        packetLossCount++;
      }
    }
  });

  const avgResponse = responseTimesCount > 0 ? Math.round(responseTimesSum / responseTimesCount) : 0;
  const avgPacketLoss = packetLossCount > 0 ? parseFloat((totalPacketLossSum / packetLossCount).toFixed(1)) : 0;

  // Let's compute average SLA (percentage of UP vs total entries) across everything
  let totalLogs = 0;
  let upLogs = 0;
  targets.forEach(t => {
    const history = checkResults[t.id] || [];
    history.forEach(log => {
      totalLogs++;
      if (log.status === "UP") upLogs++;
    });
  });

  const aggregateSLA = totalLogs > 0 ? parseFloat(((upLogs / totalLogs) * 100).toFixed(2)) : 100;

  res.json({
    total,
    up,
    down: total - up,
    avgResponse,
    sslExpiringCount,
    avgPacketLoss,
    aggregateSLA,
    activeIncidentsCount
  });
});

// 8. Incidents lists
app.get("/api/incidents", (req, res) => {
  res.json(incidents);
});

// 9. Ansible execution simulations and telemetry log collector
app.post("/api/tools/ansible", (req, res) => {
  const { targetName, playbookType } = req.body;
  if (!targetName) {
    return res.status(400).json({ error: "Target host needs naming coordinates" });
  }

  const logId = `ansible-${Date.now()}`;
  const timestamp = new Date().toISOString();
  
  const simulatedRunLogs = [
    `[ansible-playbook] Initializing core tasks for playbook: ${playbookType || "deploy-sentinel-collector.yml"}`,
    `[ansible-playbook] SSH Connection established securely on target: ${targetName}`,
    "TASK [Gathering Facts] *********************************************************",
    `ok: [${targetName}] - OS: Linux Ubuntu 22.04 LTS Architecture: x86_64`,
    "TASK [Ensure monitoring pre-requisites are installed via Apt package manager] ******",
    `changed: [${targetName}] => pkgs=[curl, openssl, tcpdump, fping, bind9-dnsutils]`,
    "TASK [Configure local directories for JSON metrics output loop template] ********",
    `changed: [${targetName}] => directory path: /opt/sentinel-collector/bin configured`,
    "TASK [Verify network latency limits and DNS dig status checks] ******************",
    `ok: [${targetName}] => latency=11ms package_loss=0% resolving=OK`,
    "TASK [Deploy health check cron script executable] ******************************",
    `changed: [${targetName}] => file /usr/local/bin/sentinel-probe.sh state=present mode=0755`,
    "TASK [Start and enable automated collector systemd agent service] *************",
    `changed: [${targetName}] => systemd service sentinel-probes.service enabled and active`,
    "PLAY RECAP *********************************************************************",
    `${targetName}              : ok=7    changed=5    unreachable=0    failed=0    skipped=0`
  ];

  const newLog = {
    id: logId,
    targetName,
    startedAt: timestamp,
    status: "SUCCESS",
    logs: simulatedRunLogs
  };

  ansibleLogs.unshift(newLog);
  if (ansibleLogs.length > 20) ansibleLogs.pop();
  
  saveData();
  res.json(newLog);
});

app.get("/api/tools/ansible/logs", (req, res) => {
  res.json(ansibleLogs);
});

// 10. Live Ad-hoc URL verification tool
app.post("/api/tools/validate", async (req, res) => {
  const { url, keyword } = req.body;
  if (!url) return res.status(400).json({ error: "Validation requires a target URL string address." });
  
  const dummyTarget: Target = {
    id: "temp-validation",
    name: "Ad-hoc Validation",
    url,
    type: "HTTPS",
    interval: 15,
    keyword,
    enabled: true,
    createdAt: new Date().toISOString()
  };

  const results = await runTargetMonitorCheck(dummyTarget);
  res.json(results);
});


// Vite middleware for development or Static Server for production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    // SPA catch-all
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[SERVER] Sentinel Monitoring Server running fine on http://0.0.0.0:${PORT}`);
  });
}

startServer();
