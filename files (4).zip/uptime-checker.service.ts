// src/modules/uptime/uptime-checker.service.ts
import { Injectable, Logger, OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { firstValueFrom } from 'rxjs';
import * as dns from 'dns';
import { promisify } from 'util';

const dnsLookup = promisify(dns.lookup);

/**
 * Bu servis:
 * 1. DB'deki aktif URL'leri okur
 * 2. Her URL için kendi setInterval'ını başlatır
 * 3. Her kontrol sonucunu uptime_checks tablosuna yazar
 * 4. WebSocket gateway üzerinden frontend'e gerçek zamanlı push gönderir
 */
@Injectable()
export class UptimeCheckerService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(UptimeCheckerService.name);
  private timers = new Map<number, NodeJS.Timeout>();

  constructor(
    // @InjectRepository(MonitoredUrl) private urlRepo: Repository<MonitoredUrl>,
    // @InjectRepository(UptimeCheck) private checkRepo: Repository<UptimeCheck>,
    private readonly httpService: HttpService,
    // private readonly uptimeGateway: UptimeGateway,
  ) {}

  async onModuleInit() {
    await this.startAllMonitors();
  }

  onModuleDestroy() {
    this.timers.forEach(timer => clearInterval(timer));
    this.timers.clear();
  }

  /** DB'deki tüm aktif URL'ler için izleme başlat */
  async startAllMonitors() {
    // const urls = await this.urlRepo.find({ where: { isActive: true } });
    const urls = getMockUrls(); // DB hazır olunca üstündeki satırla değiştirin
    for (const u of urls) {
      this.startMonitor(u);
    }
    this.logger.log(`${urls.length} URL izlemeye başlandı`);
  }

  startMonitor(url: { id: number; url: string; intervalSeconds: number; timeoutMs: number }) {
    if (this.timers.has(url.id)) {
      clearInterval(this.timers.get(url.id)!);
    }
    // İlk kontrol hemen yapılsın
    this.checkUrl(url);
    const timer = setInterval(() => this.checkUrl(url), url.intervalSeconds * 1000);
    this.timers.set(url.id, timer);
  }

  stopMonitor(urlId: number) {
    if (this.timers.has(urlId)) {
      clearInterval(this.timers.get(urlId)!);
      this.timers.delete(urlId);
    }
  }

  async checkUrl(target: { id: number; url: string; timeoutMs: number }) {
    const start = Date.now();
    let isUp = false;
    let statusCode: number | null = null;
    let latencyMs: number | null = null;
    let errorMessage: string | null = null;
    let dnsResolved = false;

    try {
      // 1. DNS çözümlemesini ayrıca test et
      const hostname = new URL(target.url).hostname;
      await dnsLookup(hostname);
      dnsResolved = true;

      // 2. HTTP isteği at
      const response = await firstValueFrom(
        this.httpService.get(target.url, {
          timeout: target.timeoutMs,
          validateStatus: () => true, // 4xx/5xx'i de yakala
        }),
      );
      statusCode = response.status;
      latencyMs = Date.now() - start;
      isUp = response.status < 400;
    } catch (err: any) {
      latencyMs = Date.now() - start;
      errorMessage = err.message ?? 'Unknown error';
      isUp = false;
    }

    const result = {
      urlId: target.id,
      checkedAt: new Date(),
      statusCode,
      latencyMs,
      isUp,
      errorMessage,
      dnsResolved,
    };

    // DB'ye kaydet
    // await this.checkRepo.save(result);

    // WebSocket ile frontend'e push et
    // this.uptimeGateway.broadcastCheck(result);

    this.logger.debug(
      `[${target.id}] ${target.url} → ${isUp ? 'UP' : 'DOWN'} ${latencyMs}ms`,
    );

    return result;
  }
}

// Geliştirme aşamasında kullanılacak mock veri – DB hazır olunca silin
function getMockUrls() {
  return [
    { id: 1, url: 'https://intranet.corp.local', intervalSeconds: 60, timeoutMs: 5000 },
    { id: 2, url: 'https://dns1.corp.local', intervalSeconds: 30, timeoutMs: 3000 },
  ];
}
