export interface Target {
  id: string;
  name: string;
  url: string; // HTTP/HTTPS url, or general hostname for PING/DNS
  type: 'HTTP' | 'HTTPS' | 'TCP' | 'PING' | 'DNS';
  port?: number;
  interval: number; // in seconds
  keyword?: string; // Content validation
  enabled: boolean;
  createdAt: string;
}

export interface SSLStatus {
  status: 'VALID' | 'WARNING' | 'EXPIRED' | 'NONE';
  expires?: string;
  days_remaining?: number;
  issuer?: string;
  error?: string;
}

export interface DNSStatus {
  status: 'OK' | 'ERROR';
  ip?: string;
  ttl?: number;
  resolve_ms?: number;
  records?: { type: string; value: string }[];
  error?: string;
}

export interface HeaderAnalysis {
  server?: string;
  hsts: boolean;
  csp: boolean;
  xfo: boolean; // X-Frame-Options
}

export interface CheckResult {
  id: string;
  targetId: string;
  timestamp: string;
  status: 'UP' | 'DOWN';
  statusCode?: number;
  dns_ms: number;
  tcp_ms: number;
  tls_ms: number;
  ttfb_ms: number;
  total_ms: number;
  latency_avg: number;
  packet_loss: number;
  ssl?: SSLStatus;
  dns?: DNSStatus;
  headers?: HeaderAnalysis;
  keyword_found?: boolean;
  error?: string;
}

export interface TargetStats {
  targetId: string;
  uptime24h: number; // percentage
  uptime7d: number;
  uptime30d: number;
  avgResponseTime: number; // ms
  p50: number;
  p95: number;
  p99: number;
  lastSuccess?: string;
  lastFailure?: string;
  consecutiveFailures: number;
}

export interface Incident {
  id: string;
  targetId: string;
  targetName: string;
  url: string;
  type: 'Downtime' | 'SSL' | 'Network' | 'DNS' | 'SLA';
  status: 'ACTIVE' | 'RESOLVED';
  message: string;
  startedAt: string;
  resolvedAt?: string;
}

export interface AnsibleSimulationLogs {
  targetName: string;
  startedAt: string;
  status: 'RUNNING' | 'SUCCESS' | 'FAILED';
  logs: string[];
}
