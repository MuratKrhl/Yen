import React, { useState } from 'react';
import { 
  Terminal, 
  Play, 
  Loader2, 
  FileText, 
  ShieldAlert, 
  CheckCircle, 
  BookOpen,
  Lock,
  History
} from 'lucide-react';

interface Playbook {
  id: string;
  name: string;
  description: string;
  command: string;
  logs: string[];
}

const PLAYBOOKS: Playbook[] = [
  {
    id: 'apt_update',
    name: 'Sistem Paketlerini Güncelle & Temizle',
    description: 'Tüm hostlarda apt-get update ve upgrade komutlarını güvenli bir şekilde çalıştırır, artık paketleri temizler.',
    command: 'ansible-playbook -i hosts playbooks/apt_update.yml',
    logs: [
      'PLAY [Apt Paketlerinin Güncellenmesi] *******************************************************',
      'TASK [Gathering Facts] ******************************************************************',
      'ok: [srv-web-01]',
      'ok: [srv-db-01]',
      'ok: [srv-cache-01]',
      'TASK [Apt Cache Paket Kaynağını Güncelle] ***********************************************',
      'changed: [srv-web-01]',
      'changed: [srv-cache-01]',
      'ok: [srv-db-01]',
      'TASK [Güvenlik Güncellemelerini Uygula] *************************************************',
      'changed: [srv-web-01] => (item=kernel-patch-security)',
      'ok: [srv-db-01]',
      'ok: [srv-cache-01]',
      'TASK [Kullanılmayan Paketleri Temizle (Autoremove)] **************************************',
      'changed: [srv-web-01]',
      'ok: [srv-db-01]',
      'changed: [srv-cache-01]',
      'PLAY RECAP ******************************************************************************',
      'srv-web-01                 : ok=4    changed=3    unreachable=0    failed=0    skipped=0',
      'srv-db-01                 : ok=4    changed=0    unreachable=0    failed=0    skipped=0',
      'srv-cache-01               : ok=4    changed=2    unreachable=0    failed=0    skipped=0'
    ]
  },
  {
    id: 'docker_setup',
    name: 'Docker Engine Kurulumu & Yapılandırması',
    description: 'Web ve worker sunucularına Docker CE ve Docker Compose kurulumlarını entegre eder, daemon yetkilerini tanımlar.',
    command: 'ansible-playbook -i hosts playbooks/docker_setup.yml',
    logs: [
      'PLAY [Docker Engine & Custom Daemon Entegrasyonu] **************************************',
      'TASK [Gathering Facts] ******************************************************************',
      'ok: [srv-web-01]',
      'TASK [Gerekli Paket Kurulumlarını Sağla (apt-transport-https)] ***************************',
      'ok: [srv-web-01]',
      'TASK [Docker GPG Anahtarını Çek] ********************************************************',
      'changed: [srv-web-01]',
      'TASK [Docker Resmi Deposunu Ekle (Stable)] ***********************************************',
      'changed: [srv-web-01]',
      'TASK [Docker CE Paketini Yükle] *********************************************************',
      'changed: [srv-web-01]',
      'TASK [Custom daemon.json Yapılandırmasını Enjekte Et] ************************************',
      'changed: [srv-web-01] => {"log-driver": "json-file", "log-opts": {"max-size": "10m"}}',
      'TASK [Docker Servisini Yeniden Başlat] ***************************************************',
      'changed: [srv-web-01]',
      'PLAY RECAP ******************************************************************************',
      'srv-web-01                 : ok=7    changed=6    unreachable=0    failed=0    skipped=0'
    ]
  },
  {
    id: 'ssh_hardening',
    name: 'SSH Güvenlik Sıkılaştırması (Hardening)',
    description: 'SSH varsayılan portunu değiştirir, parola ile girişleri pasifleştirir ve SSH key yetkilendirmesini zorunlu kılar.',
    command: 'ansible-playbook -i hosts playbooks/ssh_hardening.yml',
    logs: [
      'PLAY [İşletim Sistemi SSH Güvenlik Sıkılaştırma Yönergesi] *********************************',
      'TASK [Gathering Facts] ******************************************************************',
      'ok: [srv-web-01]',
      'ok: [srv-db-01]',
      'TASK [Root Girişini SSH üzerinden Yasakla] ***********************************************',
      'changed: [srv-web-01]',
      'changed: [srv-db-01]',
      'TASK [Parola ile Oturum Açmayı Engelle (PasswordAuthentication no)] **********************',
      'changed: [srv-web-01]',
      'changed: [srv-db-01]',
      'TASK [Varsayılan SSH Portunu Düzenle (Port 2222)] ****************************************',
      'changed: [srv-web-01]',
      'changed: [srv-db-01]',
      'TASK [SSH Servisini Yeniden Başlat (sshd restart)] ***************************************',
      'changed: [srv-web-01]',
      'changed: [srv-db-01]',
      'PLAY RECAP ******************************************************************************',
      'srv-web-01                 : ok=5    changed=4    unreachable=0    failed=0    skipped=0',
      'srv-db-01                 : ok=5    changed=4    unreachable=0    failed=0    skipped=0'
    ]
  },
  {
    id: 'full_backup',
    name: 'Tam Sunucu & Veritabanı Yedeklemesi (Backup)',
    description: 'PostgreSQL veritabanı dump dökümünü alır, dosyaları sıkıştırıp AWS S3 yedekleme bucketına şifreleyerek iletir.',
    command: 'ansible-playbook -i hosts playbooks/full_backup.yml',
    logs: [
      'PLAY [Sistem Veritabanı ve Medya Dosyalarının Yedeklenmesi] ******************************',
      'TASK [Gathering Facts] ******************************************************************',
      'ok: [srv-db-01]',
      'TASK [PostgreSQL Veritabanı Dökümü Al (pg_dump)] ****************************************',
      'changed: [srv-db-01] => filename=prod_dump_20260531.sql',
      'TASK [Medya Kütüphanesini Arşivle (gzip)] ************************************************',
      'changed: [srv-db-01] => archive=media_backup_20260531.tar.gz',
      'TASK [Yedek Dosyalarını AWS S3 Bucket\'ına Gönder (s3 sync)] *****************************',
      'changed: [srv-db-01] => bucket=s3://sysadmin-ops-backups/database/',
      'TASK [Lokal Tampon Dosyaları Temizle (cleanup)] ******************************************',
      'changed: [srv-db-01]',
      'PLAY RECAP ******************************************************************************',
      'srv-db-01                 : ok=5    changed=4    unreachable=0    failed=0    skipped=0'
    ]
  }
];

interface AnsibleViewProps {
  canWrite: boolean;
  onTriggerLog: (action: string, details: string, status: 'success' | 'warning' | 'error') => void;
  user: string;
}

const AnsibleView: React.FC<AnsibleViewProps> = ({
  canWrite,
  onTriggerLog,
  user
}) => {
  const [selectedPlaybook, setSelectedPlaybook] = useState<Playbook>(PLAYBOOKS[0]);
  const [running, setRunning] = useState(false);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([]);
  const [percent, setPercent] = useState(0);

  const startAnsiblePlay = () => {
    if (!canWrite || running) return;
    setRunning(true);
    setPercent(0);
    setTerminalLogs([]);

    onTriggerLog('Ansible Otomasyonu', `"${selectedPlaybook.name}" playbook otomasyonu tetiklendi.`, 'warning');

    let idx = 0;
    const playLogs = selectedPlaybook.logs;
    
    // Fast initial header text stream
    const interval = setInterval(() => {
      if (idx < playLogs.length) {
        setTerminalLogs((prev) => [...prev, playLogs[idx]]);
        setPercent((prev) => Math.min(Math.round(((idx + 1) / playLogs.length) * 100), 100));
        idx++;
      } else {
        clearInterval(interval);
        setPercent(100);
        setRunning(false);
        onTriggerLog('Ansible Tamamlandı', `"${selectedPlaybook.name}" playbook başarıyla tamamlandı.`, 'success');
      }
    }, 450); // Fluid stream speed
  };

  return (
    <div className="space-y-6">
      {/* Read-Only Restriction Warning */}
      {!canWrite && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-xl flex items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2.5">
            <Lock className="h-4 w-4 shrink-0 text-amber-600" />
            <span className="text-xs font-semibold">Salt Okunur Mod — Ansible playbook otomasyon süreçlerini tetiklemek için düzenleme (Write) yetkisine ihtiyacınız vardır.</span>
          </div>
          <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded uppercase font-mono">Yetki Sınırı</span>
        </div>
      )}

      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-900">Ansible Playbook Otomasyon Paneli</h1>
        <p className="text-sm text-slate-500 mt-0.5">Merkezi konfigürasyon, sunucu kurulumları ve orkestrasyon otomasyon sihirbazı.</p>
      </div>

      {/* Main Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Playbook Selection (Column 4 of 12) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3 mb-4">
              <BookOpen className="h-5 w-5 text-indigo-600" />
              <h2 className="font-bold text-slate-800 text-sm uppercase tracking-wider">Playbook Şablonları</h2>
            </div>

            <div className="space-y-3">
              {PLAYBOOKS.map((pb) => (
                <button
                  key={pb.id}
                  onClick={() => !running && setSelectedPlaybook(pb)}
                  disabled={running}
                  className={`w-full text-left p-4 rounded-xl border-2 transition-all cursor-pointer flex flex-col gap-1
                    ${selectedPlaybook.id === pb.id
                      ? 'border-indigo-600 bg-indigo-50/20 shadow-xs'
                      : running
                        ? 'border-slate-100 bg-slate-50/50 opacity-60 cursor-not-allowed'
                        : 'border-slate-100 bg-white hover:border-slate-250 hover:bg-slate-50'}`}
                >
                  <span className="text-sm font-bold text-slate-850 block">{pb.name}</span>
                  <span className="text-xs text-slate-500 line-clamp-2 leading-relaxed mt-0.5">{pb.description}</span>
                  <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-500 px-2 py-0.5 rounded self-start mt-2.5 break-all">
                    {pb.command}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Active play controls */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between">
            <div>
              <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider mb-2">Seçili Komut</h3>
              <div className="bg-slate-900 text-slate-300 p-3 rounded-lg font-mono text-xs border border-slate-800 font-normal">
                {selectedPlaybook.command}
              </div>
            </div>

            <button
              id="btn-run-playbook"
              disabled={!canWrite || running}
              onClick={startAnsiblePlay}
              className={`w-full py-3 px-4 font-bold text-sm rounded-xl inline-flex items-center justify-center gap-2 shadow-xs cursor-pointer mt-5 transition-all
                ${!canWrite
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-200'
                  : running
                    ? 'bg-amber-500 text-white font-semibold'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white font-bold hover:shadow'}`}
            >
              {running ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Playbook Çalışıyor (%{percent})...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 shrink-0" />
                  Ansible Otomasyonunu Başlat
                </>
              )}
            </button>
          </div>
        </div>

        {/* Live stdout Console (Column 7 of 12) */}
        <div className="lg:col-span-7">
          <div className="bg-slate-950 border border-slate-900 rounded-2xl shadow-2xl p-5 h-full flex flex-col justify-between min-h-[500px]">
            <div>
              {/* Terminal Header */}
              <div className="flex items-center justify-between border-b border-slate-850 pb-3.5 mb-4">
                <div className="flex items-center gap-2">
                  <Terminal className="h-4 text-pink-500 w-4" />
                  <span className="font-mono text-xs font-bold text-slate-300">ANSIBLE RUNPLAY TERMINAL</span>
                </div>
                {running ? (
                  <span className="bg-amber-900/30 text-amber-400 text-[10px] font-mono font-bold border border-amber-900/50 px-2 py-0.5 rounded animate-pulse">
                    PLAY RUNNING
                  </span>
                ) : (
                  <span className="bg-slate-900 text-slate-500 text-[10px] font-mono font-bold border border-slate-850 px-2 py-0.5 rounded">
                    CON_READY
                  </span>
                )}
              </div>

              {/* STDOUT Logs Output */}
              <div className="space-y-1.5 font-mono text-[11px] overflow-y-auto max-h-[460px] text-slate-300 leading-relaxed font-light select-text">
                {terminalLogs.length === 0 ? (
                  <div className="text-slate-600 italic py-24 text-center font-normal">
                    * Ansible çıktısı almak için soldan playbook seçip "Otomasyonu Başlat" butonuna basın.<br/>
                    Sunucu durum doğrulamaları (Facts) ve durum geçişleri (changed/ok/failed) burada akacaktır.
                  </div>
                ) : (
                  terminalLogs.map((line, ix) => {
                    let colorClass = "text-slate-300";
                    if (line.startsWith('PLAY') || line.startsWith('TASK')) {
                      colorClass = "text-slate-100 font-bold mt-2.5 block";
                    } else if (line.includes('failed=0') && line.includes('unreachable=0')) {
                      colorClass = "text-emerald-400 font-semibold";
                    } else if (line.includes('changed:')) {
                      colorClass = "text-amber-400";
                    } else if (line.includes('ok:')) {
                      colorClass = "text-emerald-500";
                    }

                    return (
                      <div key={ix} className={colorClass}>
                        {line}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Terminal Live Stat Info */}
            {running && (
              <div className="pt-4 border-t border-slate-900 mt-4">
                <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-indigo-500 rounded-full transition-all duration-150"
                    style={{ width: `${percent}%` }}
                  />
                </div>
                <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 mt-1.5 font-normal">
                  <span>Hostlar Sıralanıyor (SSH Port 22/2222)</span>
                  <span>%{percent}</span>
                </div>
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};

export default AnsibleView;
