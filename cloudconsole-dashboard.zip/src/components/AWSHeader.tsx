import React from 'react';
import { 
  Search, 
  Settings, 
  HelpCircle, 
  Bell, 
  LayoutGrid,
  ChevronDown
} from 'lucide-react';

export default function AWSHeader() {
  return (
    <header className="h-12 bg-[#232f3e] text-white flex items-center px-4 justify-between sticky top-0 z-50">
      <div className="flex items-center gap-6 h-full">
        <div className="flex items-center gap-1.5 cursor-pointer">
          <div className="w-8 h-8 bg-aws-orange rounded-sm flex items-center justify-center">
            <Settings size={20} className="text-[#232f3e]" />
          </div>
          <span className="font-bold text-sm tracking-tight">aws</span>
        </div>
        
        <div className="flex items-center bg-white/20 hover:bg-white/30 px-3 py-1.5 rounded-sm gap-2 min-w-[400px] transition-colors cursor-pointer group">
          <Search size={16} className="text-gray-300 group-hover:text-white" />
          <span className="text-sm text-gray-400 group-hover:text-white">Search</span>
          <div className="ml-auto bg-white/20 px-1 rounded text-[10px] text-gray-300 font-bold">[ Alt+S ]</div>
        </div>
      </div>

      <div className="flex items-center gap-4 h-full text-sm font-medium">
        <div className="flex items-center gap-3 h-full px-2 hover:bg-white/10 cursor-pointer">
          <Terminal size={18} />
        </div>
        <div className="flex items-center gap-3 h-full px-2 hover:bg-white/10 cursor-pointer">
          <HelpCircle size={18} />
        </div>
        <div className="flex items-center gap-3 h-full px-2 hover:bg-white/10 cursor-pointer">
          <Bell size={18} />
        </div>
        
        <div className="h-4 w-[1px] bg-white/20 mx-1" />
        
        <div className="flex items-center gap-1.5 h-full px-3 hover:bg-white/10 cursor-pointer">
          <span>Sydney</span>
          <ChevronDown size={14} />
        </div>
        
        <div className="flex items-center gap-1.5 h-full px-3 hover:bg-white/10 cursor-pointer">
          <span className="bg-aws-orange-hover px-1.5 py-0.5 rounded text-[10px] uppercase font-bold text-[#232f3e]">
            murat
          </span>
          <ChevronDown size={14} />
        </div>

        <div className="flex items-center gap-3 h-full px-2 hover:bg-white/10 cursor-pointer">
          <LayoutGrid size={18} />
        </div>
      </div>
    </header>
  );
}

function Terminal({ size }: { size: number }) {
  return (
    <div className="border border-white/40 px-1 rounded-[2px] flex items-center justify-center">
      <span className="text-[10px] font-bold">&gt;_</span>
    </div>
  );
}
