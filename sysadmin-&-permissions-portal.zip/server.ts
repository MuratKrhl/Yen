import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";
import { 
  PermissionsMap, 
  InventoryItem, 
  RosterEntry, 
  QuickLink, 
  AuditLog 
} from "./src/types";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Initialize GoogleGenAI with named apiKey parameter and proper telemetry user-agent
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;

function getAI(): GoogleGenAI {
  if (!aiClient) {
    if (!apiKey) {
      console.warn("WARNING: GEMINI_API_KEY environment variable is not set. AskGT replies will fall back to helpful guide simulations.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey || "MOCK_KEY",
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// Global In-Memory Store for Server Side State
const MANAGED_PAGE_IDS = [
  'Dashboard',
  'Envanter',
  'Self Service',
  'Ansible',
  'Performance',
  'AskGT',
  'Nöbet Listesi',
  'Önemli Linkler'
];

let permissionsState: PermissionsMap = Object.fromEntries(
  MANAGED_PAGE_IDS.map((id) => [
    id, 
    { read: id === 'Dashboard', write: false }
  ])
);

let inventoryState: InventoryItem[] = [
  { id: '1', name: 'srv-web-01', type: 'Web Server', ip: '192.168.1.10', status: 'Online', cpuUsage: 38, memoryUsage: 64, region: 'DE-Frankfurt' },
  { id: '2', name: 'srv-db-01', type: 'Database Server', ip: '192.168.1.20', status: 'Online', cpuUsage: 14, memoryUsage: 82, region: 'DE-Frankfurt' },
  { id: '3', name: 'srv-lb-01', type: 'Load Balancer', ip: '192.168.1.5', status: 'Online', cpuUsage: 4, memoryUsage: 25, region: 'NL-Amsterdam' },
  { id: '4', name: 'srv-cache-01', type: 'Cache Cluster', ip: '192.168.1.15', status: 'Online', cpuUsage: 8, memoryUsage: 48, region: 'DE-Frankfurt' },
  { id: '5', name: 'srv-storage-01', type: 'Storage Server', ip: '192.168.1.40', status: 'Online', cpuUsage: 22, memoryUsage: 30, region: 'FR-Paris' }
];

let rosterState: RosterEntry[] = [
  { id: '1', date: '2026-06-01', name: 'Murat Karahaliloğlu', phone: '+90 555 123 4567', team: 'DevOps' },
  { id: '2', date: '2026-06-02', name: 'Ahmet Yılmaz', phone: '+90 555 987 6543', team: 'Operations' },
  { id: '3', date: '2026-06-03', name: 'Mehmet Demir', phone: '+90 555 456 7890', team: 'Database' },
  { id: '4', date: '2026-06-04', name: 'Can Öztürk', phone: '+90 555 321 0987', team: 'Security' },
  { id: '5', date: '2026-06-05', name: 'Melisa Yıldız', phone: '+90 555 678 1234', team: 'DevOps' }
];

let linksState: QuickLink[] = [
  { id: '1', title: 'Grafana Metrics', url: 'https://grafana.internal.com', category: 'Monitoring' },
  { id: '2', title: 'Kibana Logging', url: 'https://kibana.internal.com', category: 'Logs' },
  { id: '3', title: 'AWS Management Console', url: 'https://aws.amazon.com', category: 'Cloud' },
  { id: '4', title: 'Internal Wiki & Confluence', url: 'https://wiki.internal.com', category: 'Documentation' },
  { id: '5', title: 'GitLab Repository', url: 'https://gitlab.internal.com', category: 'Source Code' },
  { id: '6', title: 'Jira Backlog', url: 'https://jira.internal.com', category: 'Management' }
];

let auditLogsState: AuditLog[] = [
  { id: '1', user: 'System', action: 'Portalı Başlat', details: 'SysAdmin Portal backend servisi başarıyla sürüldü.', timestamp: new Date(Date.now() - 3600000 * 2).toISOString(), status: 'success' },
  { id: '2', user: 'System', action: 'Rol Ayarı', details: 'Varsayılan yetkilendirmeler yüklendi (Dashboard salt okunur).', timestamp: new Date(Date.now() - 3600000).toISOString(), status: 'success' }
];

// Helper to push a new log
function addAuditLog(user: string, action: string, details: string, status: 'success' | 'warning' | 'error' = 'success') {
  const newLog: AuditLog = {
    id: String(Date.now()),
    user,
    action,
    details,
    timestamp: new Date().toISOString(),
    status
  };
  auditLogsState.unshift(newLog);
  // Keep logs at a reasonable limit (e.g. 50)
  if (auditLogsState.length > 50) {
    auditLogsState.pop();
  }
}

// ---------------- SERVER ENDPOINTS ----------------

// 1. Unified State Getter
app.get("/api/state", (req, res) => {
  res.json({
    permissions: permissionsState,
    inventory: inventoryState,
    roster: rosterState,
    links: linksState,
    logs: auditLogsState
  });
});

// 2. Clear State / Reset
app.post("/api/state/reset", (req, res) => {
  permissionsState = Object.fromEntries(
    MANAGED_PAGE_IDS.map((id) => [
      id, 
      { read: id === 'Dashboard', write: false }
    ])
  );
  addAuditLog(req.body.user || 'Admin', 'Sistem Sıfırlama', 'Tüm yetkilendirme şemaları varsayılan ayarlara döndürüldü.', 'warning');
  res.json({ success: true, permissions: permissionsState });
});

// 3. Update Permissions
app.post("/api/permissions", (req, res) => {
  const { permissions, user } = req.body;
  if (!permissions) {
    return res.status(400).json({ error: "Eksik yetki parametresi" });
  }
  permissionsState = permissions;
  addAuditLog(user || 'Admin', 'Yetki Güncelleme', 'Normal kullanıcı yetkilendirme şemasında değişiklikler uygulandı.', 'success');
  res.json({ success: true, permissions: permissionsState });
});

// 4. Inventory CRUD Operations
app.post("/api/inventory", (req, res) => {
  const { item, user, mode } = req.body;
  
  if (mode === 'delete') {
    inventoryState = inventoryState.filter(i => i.id !== item.id);
    addAuditLog(user, 'Sunucu Silme', `${item.name} (${item.ip}) envanterden çıkartıldı.`, 'warning');
    return res.json({ success: true, inventory: inventoryState });
  }

  if (mode === 'edit') {
    inventoryState = inventoryState.map(i => i.id === item.id ? { ...i, ...item } : i);
    addAuditLog(user, 'Sunucu Düzenleme', `${item.name} bilgileri güncellendi.`, 'success');
    return res.json({ success: true, inventory: inventoryState });
  }

  // Add Mode
  const newItem: InventoryItem = {
    ...item,
    id: String(Date.now()),
    cpuUsage: Math.floor(Math.random() * 40) + 5,
    memoryUsage: Math.floor(Math.random() * 50) + 15
  };
  inventoryState.push(newItem);
  addAuditLog(user, 'Sunucu Ekleme', `${newItem.name} (${newItem.ip}) envantere dahil edildi.`, 'success');
  res.json({ success: true, inventory: inventoryState });
});

// 5. Roster Operations
app.post("/api/roster", (req, res) => {
  const { entry, user, mode } = req.body;

  if (mode === 'delete') {
    rosterState = rosterState.filter(r => r.id !== entry.id);
    addAuditLog(user, 'Nöbet Kaldırma', `${entry.date} tarihindeki ${entry.name} nöbeti iptal edildi.`, 'warning');
    return res.json({ success: true, roster: rosterState });
  }

  if (mode === 'edit') {
    rosterState = rosterState.map(r => r.id === entry.id ? { ...r, ...entry } : r);
    addAuditLog(user, 'Nöbet Güncelleme', `${entry.date} tarihindeki nöbet ${entry.name} olarak güncellendi.`, 'success');
    return res.json({ success: true, roster: rosterState });
  }

  // Add Mode
  const newEntry: RosterEntry = {
    ...entry,
    id: String(Date.now())
  };
  rosterState.push(newEntry);
  // Sort roster by date
  rosterState.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  addAuditLog(user, 'Nöbet Ekleme', `${newEntry.date} tarihine ${newEntry.name} nöbetçi olarak eklendi.`, 'success');
  res.json({ success: true, roster: rosterState });
});

// 6. Quick Links Operations
app.post("/api/links", (req, res) => {
  const { link, user, mode } = req.body;

  if (mode === 'delete') {
    linksState = linksState.filter(l => l.id !== link.id);
    addAuditLog(user, 'Link Kaldırma', `"${link.title}" hızlı erişim listesinden kaldırıldı.`, 'warning');
    return res.json({ success: true, links: linksState });
  }

  if (mode === 'edit') {
    linksState = linksState.map(l => l.id === link.id ? { ...l, ...link } : l);
    addAuditLog(user, 'Link Güncelleme', `"${link.title}" adresi ${link.url} olarak düzenlendi.`, 'success');
    return res.json({ success: true, links: linksState });
  }

  // Add Mode
  const newLink: QuickLink = {
    ...link,
    id: String(Date.now())
  };
  linksState.push(newLink);
  addAuditLog(user, 'Link Ekleme2', `"${newLink.title}" hızlı erişim listesine eklendi.`, 'success');
  res.json({ success: true, links: linksState });
});

// 7. General Custom Audit Log trigger
app.post("/api/log", (req, res) => {
  const { user, action, details, status } = req.body;
  addAuditLog(user || 'User', action || 'Aksiyon', details || '', status || 'success');
  res.json({ success: true, logs: auditLogsState });
});

// 8. AskGT Gemini Integration Endpoint (AI Assistant)
app.post("/api/ask-gt", async (req, res) => {
  const { prompt, history, user } = req.body;
  if (!prompt) {
    return res.status(400).json({ error: "Soru boş bırakılamaz." });
  }

  const userActionText = `AskGT yapay zeka asistanına soruldu: "${prompt.slice(0, 40)}${prompt.length > 40 ? '...' : ''}"`;
  addAuditLog(user || 'User', 'AI Sorgusu', userActionText, 'success');

  // Fallback if API key is not present
  if (!process.env.GEMINI_API_KEY) {
    setTimeout(() => {
      res.json({
        content: `**[Kılavuz Modu / API Key Eksik]**\n\nSisteminizde \`GEMINI_API_KEY\` tanımlı olmadığı için bu bir simüle edilmiş akıllı yanıttır. \n\nSorduğunuz soru: \n> "${prompt}"\n\n**Olası Çözüm Önerisi (IT / SysAdmin):**\n1. Bash scriptlerinizi yazarken hata denetimleri ekleyin (\`set -euo pipefail\`).\n2. Nginx ayarlarında upstream sunucuların portlarını kontrol etmeyi unutmayın.\n3. Hızlıca Docker ile Nginx ayağa kaldırmak için:\n\`\`\`bash\ndocker run --name sys-nginx -p 8080:80 -d nginx:alpine\n\`\`\`\n\n*Yapay Zeka özelliğinin tamamen aktifleşmesi için lütfen **Settings > Secrets** panelinden \`GEMINI_API_KEY\` değerini ekleyin.*`
      });
    }, 1000);
    return;
  }

  try {
    const ai = getAI();
    
    // Structure chat contents
    // AskGT is an advanced DevOps & SysAdmin expert bot.
    const systemInstruction = 
      "Sen AskGT adında gelişmiş bir IT sistem yönetimi (SysAdmin) ve DevOps yapay zeka asistanısın. " +
      "Kullanıcılara Linux sistem sorunları, bash scriptleri, Ansible playbook şablonları, Docker ve Kubernetes yapılandırmaları, " +
      "Nginx ayarları ve ağ sorunlarında yardımcı olursun. " +
      "Her zaman teknik olarak çok net, profesyonel cevaplar vermelisin. " +
      "Bash scriptleri ve kod parçacıkları için markdown formatında şık kod blokları kullan. " +
      "Lütfen yanıtlarını Türkçe olarak ver.";

    // Map conversation history safely
    let contents: any[] = [];
    if (history && history.length > 0) {
      contents = history.map((msg: any) => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.content }]
      }));
    }
    // Append the new prompt
    contents.push({
      role: 'user',
      parts: [{ text: prompt }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    const reply = response.text || "Modelden bir cevap üretilemedi. Lütfen tekrar deneyin.";
    res.json({ content: reply });

  } catch (error: any) {
    console.error("Gemini Error:", error);
    addAuditLog('System', 'AI Hatası', `Sorgu işlenirken bir hata oluştu: ${error.message}`, 'error');
    res.status(500).json({ error: `Yapay Zeka servisi hata verdi: ${error.message}` });
  }
});


// ---------------- VITE MIDDLEWARE SETUP ----------------

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server fully operational and running on http://localhost:${PORT}`);
  });
}

startServer();
