import React, { useState } from 'react';
import { 
  Search, 
  RotateCw, 
  ChevronRight, 
  ChevronLeft, 
  Settings2, 
  ChevronDown,
  Info,
  ExternalLink,
  X,
  Copy
} from 'lucide-react';
import { DUMMY_NETWORK_INTERFACES } from '../constants';
import { NetworkInterface } from '../types';

export default function NetworkInterfacesTable() {
  const [selectedId, setSelectedId] = useState<string | null>(DUMMY_NETWORK_INTERFACES[0].id);

  const selectedItem = DUMMY_NETWORK_INTERFACES.find(i => i.id === selectedId);

  return (
    <div className="flex flex-col h-full bg-[#f8f9fa]">
      <div className="flex items-center justify-between p-4 bg-white border-b">
        <h1 className="text-xl font-bold flex items-center gap-2">
          Network interfaces (1/2)
          <Info size={16} className="text-blue-500 cursor-pointer" />
        </h1>
        <div className="flex items-center gap-2 text-sm">
          <button className="p-2 hover:bg-gray-100 rounded-sm border"><RotateCw size={16} /></button>
          <div className="relative inline-block text-left">
            <button className="px-4 py-1.5 border hover:bg-gray-50 font-medium flex items-center gap-2">
              Actions <ChevronDown size={14} />
            </button>
          </div>
          <button className="px-4 py-1.5 bg-aws-orange hover:bg-aws-orange-hover text-white font-bold rounded-sm shadow-sm transition-colors">
            Create network interface
          </button>
        </div>
      </div>

      <div className="p-4 bg-white shadow-sm">
        <div className="flex items-center gap-2 border px-3 py-2 bg-gray-50 rounded-sm">
          <Search size={18} className="text-gray-400" />
          <input 
            type="text" 
            placeholder="Search" 
            className="flex-1 bg-transparent text-sm outline-none"
          />
          <div className="flex items-center gap-4 ml-4">
            <div className="flex items-center gap-1">
              <ChevronLeft size={18} className="text-gray-300 pointer-events-none" />
              <span className="text-xs font-bold text-gray-800">1</span>
              <ChevronRight size={18} className="text-gray-300 pointer-events-none" />
            </div>
            <Settings2 size={18} className="text-gray-600 cursor-pointer" />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto min-h-0 bg-white">
        <table className="w-full text-sm border-collapse">
          <thead className="bg-[#f8f9fa] border-b text-gray-500 sticky top-0 uppercase text-[11px] font-bold tracking-wider">
            <tr>
              <th className="w-10 p-2 text-center border-r">
                <div className="w-4 h-4 border bg-blue-600 flex items-center justify-center rounded-[2px]" />
              </th>
              <th className="p-2 text-left border-r min-w-[150px]">Name <ChevronDown size={12} className="inline ml-1" /></th>
              <th className="p-2 text-left border-r min-w-[200px]">Network interface ID</th>
              <th className="p-2 text-left border-r min-w-[200px]">Subnet ID <ChevronDown size={12} className="inline ml-1" /></th>
              <th className="p-2 text-left border-r min-w-[200px]">VPC ID</th>
              <th className="p-2 text-left border-r min-w-[150px]">Availability Zone <ChevronDown size={12} className="inline ml-1" /></th>
              <th className="p-2 text-left min-w-[150px]">Security group n... <ChevronDown size={12} className="inline ml-1" /></th>
            </tr>
          </thead>
          <tbody>
            {DUMMY_NETWORK_INTERFACES.map((item) => (
              <tr 
                key={item.id} 
                onClick={() => setSelectedId(item.id)}
                className={`border-b hover:bg-gray-50 transition-colors cursor-pointer ${selectedId === item.id ? 'bg-blue-50' : ''}`}
              >
                <td className="p-2 text-center">
                  <div className={`w-4 h-4 border mx-auto flex items-center justify-center rounded-[2px] ${
                    selectedId === item.id ? 'bg-blue-600 border-blue-600' : 'bg-white'
                  }`}>
                    {selectedId === item.id && <div className="text-[10px] text-white font-bold">✓</div>}
                  </div>
                </td>
                <td className="p-2">{item.name}</td>
                <td className="p-2 text-blue-600 hover:underline">{item.id}</td>
                <td className="p-2 text-blue-600 hover:underline flex items-center gap-1">
                  {item.subnetId} <ExternalLink size={14} />
                </td>
                <td className="p-2 text-blue-600 hover:underline flex items-center gap-1">
                  {item.vpcId} <ExternalLink size={14} />
                </td>
                <td className="p-2">{item.az}</td>
                <td className="p-2 text-blue-600 hover:underline">{item.securityGroups.join(', ')}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedItem && (
        <div className="h-2/5 border-t bg-white flex flex-col shadow-2xl z-10">
          <div className="flex items-center justify-between px-4 py-2 border-b bg-white">
            <h2 className="font-bold">Network interface: <span className="font-semibold text-gray-700">{selectedItem.id}</span></h2>
            <div className="flex items-center gap-4">
               <RotateCw size={16} className="text-gray-500 cursor-pointer" />
               <Settings2 size={16} className="text-gray-500 cursor-pointer" />
               <X size={20} className="text-gray-500 cursor-pointer" onClick={() => setSelectedId(null)} />
            </div>
          </div>
          <div className="flex items-center border-b px-2 gap-4 text-sm font-medium text-gray-600">
            <button className="px-4 py-2 border-b-2 border-aws-orange text-aws-orange">Details</button>
            <button className="px-4 py-2 hover:bg-gray-50">Flow logs</button>
            <button className="px-4 py-2 hover:bg-gray-50">Tags</button>
          </div>
          
          <div className="flex-1 overflow-auto p-4 flex flex-col gap-4">
            <div className="bg-blue-50 border border-blue-200 p-3 rounded-sm flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Info size={18} className="text-blue-500" />
                <p className="text-sm">You can now check network connectivity with <span className="text-blue-600 hover:underline font-semibold cursor-pointer">Reachability Analyzer</span>.</p>
              </div>
              <div className="flex items-center gap-2">
                <button className="bg-white border px-4 py-1.5 text-sm font-medium hover:bg-gray-50">Run Reachability Analyzer</button>
                <X size={16} className="text-gray-400 cursor-pointer" />
              </div>
            </div>

            <div className="mt-2">
              <div className="flex items-center gap-2 text-sm font-bold mb-4 cursor-pointer">
                <ChevronDown size={14} />
                Network interface details
              </div>
              <div className="grid grid-cols-3 gap-y-6 text-sm px-6">
                <div>
                  <div className="text-gray-500 mb-1">Network interface ID</div>
                  <div className="flex items-center gap-2">
                    <Copy size={14} className="text-gray-400 cursor-pointer" />
                    <span className="text-gray-900">{selectedItem.id}</span>
                  </div>
                </div>
                <div>
                  <div className="text-gray-500 mb-1">Name</div>
                  <div className="text-gray-900">{selectedItem.name}</div>
                </div>
                <div>
                  <div className="text-gray-500 mb-1">Description</div>
                  <div className="flex items-center gap-2">
                    <Copy size={14} className="text-gray-400 cursor-pointer" />
                    <span className="text-gray-900 font-medium">{selectedItem.description}</span>
                  </div>
                </div>
                <div>
                  <div className="text-gray-500 mb-1">Network interface status</div>
                  <div className="flex items-center gap-1.5 text-green-700 font-medium">
                    <div className="w-4 h-4 rounded-full border border-green-600 flex items-center justify-center text-[10px] bg-green-50">✓</div>
                    {selectedItem.status}
                  </div>
                </div>
                <div>
                  <div className="text-gray-500 mb-1">Interface type</div>
                  <div className="flex items-center gap-2">
                    <Copy size={14} className="text-gray-400 cursor-pointer" />
                    <span className="text-gray-900">{selectedItem.interfaceType}</span>
                  </div>
                </div>
                <div>
                  <div className="text-gray-500 mb-1">Security groups</div>
                  <div className="text-blue-600 hover:underline cursor-pointer">{selectedItem.securityGroups[0]} (default)</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
