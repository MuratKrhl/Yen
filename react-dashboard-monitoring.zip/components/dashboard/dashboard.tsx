"use client"

import { useState } from "react"
import useSWR from "swr"
import {
  Activity,
  AlertTriangle,
  BellRing,
  Gauge,
  LayoutDashboard,
  Lock,
  Radar,
  RefreshCw,
  Target as TargetIcon,
} from "lucide-react"
import type { Snapshot, Target } from "@/lib/monitoring"
import { cn } from "@/lib/utils"
import { OverviewSection } from "./overview-section"
import { UptimeSection } from "./uptime-section"
import { SslDnsSection } from "./ssl-dns-section"
import { SlaSection } from "./sla-section"
import { AlertsSection } from "./alerts-section"
import { TargetDetail } from "./target-detail"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

type SectionKey = "overview" | "uptime" | "ssl" | "sla" | "alerts"

const NAV: { key: SectionKey; label: string; icon: typeof Activity; desc: string }[] = [
  { key: "overview", label: "Health Overview", icon: LayoutDashboard, desc: "Targets, status, availability" },
  { key: "uptime", label: "Uptime & Response", icon: Gauge, desc: "Latency percentiles & timing" },
  { key: "ssl", label: "SSL & DNS", icon: Lock, desc: "Certificates & resolution" },
  { key: "sla", label: "SLA & Historical", icon: TargetIcon, desc: "Availability windows & SLO" },
  { key: "alerts", label: "Alert Center", icon: BellRing, desc: "Incidents & notifications" },
]

export function Dashboard() {
  const { data, isLoading, mutate, isValidating } = useSWR<Snapshot>("/api/snapshot", fetcher, {
    refreshInterval: 5000,
    keepPreviousData: true,
  })
  const [section, setSection] = useState<SectionKey>("overview")
  const [selected, setSelected] = useState<Target | null>(null)

  const summary = data?.summary
  const active = NAV.find((n) => n.key === section)!

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-sidebar-border bg-sidebar md:flex">
        <div className="flex items-center gap-2.5 border-b border-sidebar-border px-5 py-4">
          <div className="flex size-8 items-center justify-center rounded-md bg-primary/15 text-primary">
            <Radar className="size-5" />
          </div>
          <div>
            <p className="text-sm font-semibold leading-tight">Sentinel</p>
            <p className="text-[11px] text-muted-foreground">Uptime &amp; Health</p>
          </div>
        </div>

        <nav className="flex-1 space-y-1 p-3">
          <p className="px-2 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Monitoring</p>
          {NAV.map((item) => {
            const Icon = item.icon
            const isActive = section === item.key
            return (
              <button
                key={item.key}
                onClick={() => setSection(item.key)}
                className={cn(
                  "flex w-full items-start gap-3 rounded-md px-2.5 py-2 text-left transition-colors",
                  isActive ? "bg-sidebar-accent text-foreground" : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-foreground",
                )}
              >
                <Icon className={cn("mt-0.5 size-4 shrink-0", isActive && "text-primary")} />
                <span className="min-w-0">
                  <span className="block text-sm font-medium">{item.label}</span>
                  <span className="block truncate text-[11px] text-muted-foreground">{item.desc}</span>
                </span>
              </button>
            )
          })}
        </nav>

        {summary && (
          <div className="border-t border-sidebar-border p-3">
            <div className="rounded-md border border-border bg-card p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">System status</span>
                <span className={cn("size-2 rounded-full", summary.down > 0 ? "bg-destructive animate-pulse-dot" : summary.degraded > 0 ? "bg-warning" : "bg-success")} />
              </div>
              <p className="mt-1 text-sm font-semibold">
                {summary.down > 0 ? "Partial outage" : summary.degraded > 0 ? "Degraded" : "All systems normal"}
              </p>
              <div className="mt-2 grid grid-cols-3 gap-1 text-center font-mono text-xs">
                <div><p className="text-success">{summary.up}</p><p className="text-[10px] text-muted-foreground">up</p></div>
                <div><p className="text-warning">{summary.degraded}</p><p className="text-[10px] text-muted-foreground">deg</p></div>
                <div><p className="text-destructive">{summary.down}</p><p className="text-[10px] text-muted-foreground">down</p></div>
              </div>
            </div>
          </div>
        )}
      </aside>

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur">
          <div className="flex items-center justify-between gap-3 px-4 py-3 md:px-6">
            <div className="flex items-center gap-2">
              <div className="flex size-7 items-center justify-center rounded-md bg-primary/15 text-primary md:hidden">
                <Radar className="size-4" />
              </div>
              <div>
                <h1 className="text-base font-semibold leading-tight md:text-lg">{active.label}</h1>
                <p className="hidden text-xs text-muted-foreground sm:block">{active.desc}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="hidden items-center gap-1.5 rounded-full border border-border bg-card px-2.5 py-1 text-xs text-muted-foreground sm:flex">
                <span className="size-1.5 animate-pulse-dot rounded-full bg-success" />
                Live · 5s
              </span>
              <button
                onClick={() => mutate()}
                className="flex items-center gap-1.5 rounded-md border border-border bg-card px-2.5 py-1.5 text-xs font-medium text-foreground transition-colors hover:bg-accent"
              >
                <RefreshCw className={cn("size-3.5", isValidating && "animate-spin")} />
                <span className="hidden sm:inline">Refresh</span>
              </button>
            </div>
          </div>

          {/* Mobile section selector */}
          <div className="flex gap-1 overflow-x-auto border-t border-border px-2 py-2 md:hidden">
            {NAV.map((item) => (
              <button
                key={item.key}
                onClick={() => setSection(item.key)}
                className={cn(
                  "shrink-0 rounded-md px-3 py-1.5 text-xs font-medium",
                  section === item.key ? "bg-accent text-foreground" : "text-muted-foreground",
                )}
              >
                {item.label}
              </button>
            ))}
          </div>
        </header>

        <main className="flex-1 p-4 md:p-6">
          {!data && isLoading ? (
            <div className="flex h-[60vh] items-center justify-center text-muted-foreground">
              <RefreshCw className="mr-2 size-4 animate-spin" /> Loading monitoring data…
            </div>
          ) : data ? (
            <>
              {summary && summary.down + summary.degraded > 0 && (
                <div className="mb-5 flex items-center gap-2 rounded-lg border border-warning/30 bg-warning/10 px-4 py-2.5 text-sm">
                  <AlertTriangle className="size-4 text-warning" />
                  <span className="text-foreground">
                    {summary.activeIncidents} active incident{summary.activeIncidents !== 1 ? "s" : ""} —{" "}
                    {summary.down} down, {summary.degraded} degraded across {summary.total} targets.
                  </span>
                  <button onClick={() => setSection("alerts")} className="ml-auto text-xs font-medium text-warning hover:underline">
                    View alerts
                  </button>
                </div>
              )}
              {section === "overview" && <OverviewSection snapshot={data} onSelect={setSelected} />}
              {section === "uptime" && <UptimeSection snapshot={data} />}
              {section === "ssl" && <SslDnsSection snapshot={data} />}
              {section === "sla" && <SlaSection snapshot={data} />}
              {section === "alerts" && <AlertsSection snapshot={data} />}
            </>
          ) : null}
        </main>
      </div>

      <TargetDetail target={selected} onClose={() => setSelected(null)} />
    </div>
  )
}
