// src/modules/uptime/uptime.controller.ts
import {
  Controller, Get, Post, Delete, Body, Param, ParseIntPipe, HttpCode,
} from '@nestjs/common';
import { UptimeService } from './uptime.service';

class CreateUrlDto {
  label: string;
  url: string;
  intervalSeconds: number;
  timeoutMs: number;
}

/**
 * REST endpoint'leri:
 *   GET    /api/uptime/urls          → tüm izlenen URL listesi
 *   POST   /api/uptime/urls          → yeni URL ekle + izlemeyi başlat
 *   DELETE /api/uptime/urls/:id      → URL sil + izlemeyi durdur
 *   GET    /api/uptime/urls/:id/checks?limit=100  → belirli URL'nin kontrol geçmişi
 *   GET    /api/uptime/summary       → dashboard için özet (uptime %, ort. gecikme, dns durumu)
 */
@Controller('api/uptime')
export class UptimeController {
  constructor(private readonly uptimeService: UptimeService) {}

  @Get('urls')
  async getUrls() {
    return this.uptimeService.getAllUrls();
  }

  @Post('urls')
  async addUrl(@Body() dto: CreateUrlDto) {
    return this.uptimeService.addUrl(dto);
  }

  @Delete('urls/:id')
  @HttpCode(204)
  async removeUrl(@Param('id', ParseIntPipe) id: number) {
    return this.uptimeService.removeUrl(id);
  }

  @Get('urls/:id/checks')
  async getChecks(@Param('id', ParseIntPipe) id: number) {
    return this.uptimeService.getChecks(id, 100);
  }

  @Get('summary')
  async getSummary() {
    return this.uptimeService.getSummary();
  }
}
