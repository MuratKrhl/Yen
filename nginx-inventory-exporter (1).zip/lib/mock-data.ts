// Types matching the CSV export structure
export interface NodeData {
  hostname: string
  ip_address: string
  os: string
  nginx_version: string
  cpu_cores: number
  memory_gb: number
  uptime_days: number
  active_connections: number
  worker_processes: number
  export_timestamp: string
}

export interface RouteData {
  id: string
  domain: string
  listen_port: string
  ssl_enabled: boolean
  location: string
  match_type: 'prefix' | 'regex' | 'exact'
  proxy_pass: string
  read_timeout: string
  rate_limit: boolean
  cache_enabled: boolean
  backup_upstream: boolean
  export_timestamp: string
}

export interface HealthData {
  id: string
  domain: string
  location: string
  status: 'UP' | 'DOWN' | 'DEGRADED'
  total_requests: number
  error_5xx_pct: number
  avg_latency_ms: number
  export_timestamp: string
}

export interface SSLData {
  id: string
  cert_path: string
  subject: string
  issuer: string
  expires: string
  days_left: number
  tls_protocols: string
  hsts_enabled: boolean
  export_timestamp: string
}

// Mock data for demonstration - representing 30+ servers and 200+ locations
export const mockNodes: NodeData[] = [
  {
    hostname: 'nginx-prod-01',
    ip_address: '10.0.1.10',
    os: 'Ubuntu 22.04.3 LTS',
    nginx_version: '1.24.0',
    cpu_cores: 8,
    memory_gb: 32,
    uptime_days: 127,
    active_connections: 1247,
    worker_processes: 8,
    export_timestamp: '20240315_143022'
  },
  {
    hostname: 'nginx-prod-02',
    ip_address: '10.0.1.11',
    os: 'Ubuntu 22.04.3 LTS',
    nginx_version: '1.24.0',
    cpu_cores: 8,
    memory_gb: 32,
    uptime_days: 127,
    active_connections: 983,
    worker_processes: 8,
    export_timestamp: '20240315_143022'
  },
  {
    hostname: 'nginx-prod-03',
    ip_address: '10.0.1.12',
    os: 'Debian 12',
    nginx_version: '1.25.3',
    cpu_cores: 16,
    memory_gb: 64,
    uptime_days: 45,
    active_connections: 2156,
    worker_processes: 16,
    export_timestamp: '20240315_143022'
  },
  {
    hostname: 'nginx-staging-01',
    ip_address: '10.0.2.10',
    os: 'Ubuntu 22.04.3 LTS',
    nginx_version: '1.24.0',
    cpu_cores: 4,
    memory_gb: 16,
    uptime_days: 89,
    active_connections: 234,
    worker_processes: 4,
    export_timestamp: '20240315_143022'
  },
  {
    hostname: 'nginx-edge-eu-01',
    ip_address: '10.1.1.10',
    os: 'Alpine Linux 3.19',
    nginx_version: '1.25.4',
    cpu_cores: 4,
    memory_gb: 8,
    uptime_days: 32,
    active_connections: 567,
    worker_processes: 4,
    export_timestamp: '20240315_143022'
  },
  {
    hostname: 'nginx-edge-us-01',
    ip_address: '10.2.1.10',
    os: 'Alpine Linux 3.19',
    nginx_version: '1.25.4',
    cpu_cores: 4,
    memory_gb: 8,
    uptime_days: 32,
    active_connections: 892,
    worker_processes: 4,
    export_timestamp: '20240315_143022'
  },
]

// Generate routes for multiple domains
const domains = [
  'api.example.com', 'app.example.com', 'admin.example.com', 'cdn.example.com',
  'auth.example.com', 'payments.example.com', 'notifications.example.com',
  'analytics.example.com', 'search.example.com', 'media.example.com',
  'staging.example.com', 'dev.example.com', 'test.example.com'
]

const locations = [
  '/', '/api', '/api/v1', '/api/v2', '/health', '/metrics', '/graphql',
  '/auth', '/login', '/logout', '/register', '/oauth', '/callback',
  '/users', '/orders', '/products', '/payments', '/webhooks', '/events',
  '/static', '/assets', '/images', '/uploads', '/downloads', '/files',
  '/admin', '/dashboard', '/settings', '/profile', '/notifications'
]

const upstreams = [
  'http://backend-cluster:8080', 'http://api-service:3000', 'http://auth-service:4000',
  'http://payment-gateway:5000', 'http://notification-service:6000', 'http://search-cluster:9200',
  'http://media-service:7000', 'http://analytics-pipeline:8000', 'http://cache-layer:6379'
]

export const mockRoutes: RouteData[] = domains.flatMap((domain, di) =>
  locations.slice(0, Math.floor(Math.random() * 15) + 10).map((location, li) => ({
    id: `route-${di}-${li}`,
    domain,
    listen_port: domain.includes('cdn') ? '80' : '443',
    ssl_enabled: !domain.includes('cdn'),
    location,
    match_type: (location.includes('api') ? 'prefix' : location === '/' ? 'exact' : 'prefix') as RouteData['match_type'],
    proxy_pass: upstreams[Math.floor(Math.random() * upstreams.length)],
    read_timeout: ['30s', '60s', '120s'][Math.floor(Math.random() * 3)],
    rate_limit: Math.random() > 0.6,
    cache_enabled: location.includes('static') || location.includes('assets'),
    backup_upstream: Math.random() > 0.7,
    export_timestamp: '20240315_143022'
  }))
)

export const mockHealth: HealthData[] = mockRoutes.slice(0, 80).map((route, i) => {
  const errorRate = Math.random() * 10
  return {
    id: `health-${i}`,
    domain: route.domain,
    location: route.location,
    status: errorRate > 8 ? 'DOWN' : errorRate > 3 ? 'DEGRADED' : 'UP',
    total_requests: Math.floor(Math.random() * 100000) + 1000,
    error_5xx_pct: Number(errorRate.toFixed(1)),
    avg_latency_ms: Math.floor(Math.random() * 500) + 10,
    export_timestamp: '20240315_143022'
  }
})

export const mockSSL: SSLData[] = [
  {
    id: 'ssl-1',
    cert_path: '/etc/nginx/ssl/api.example.com.crt',
    subject: 'CN=api.example.com',
    issuer: "CN=Let's Encrypt Authority X3",
    expires: 'Mar 15 23:59:59 2024 GMT',
    days_left: 5,
    tls_protocols: 'TLSv1.2 TLSv1.3',
    hsts_enabled: true,
    export_timestamp: '20240315_143022'
  },
  {
    id: 'ssl-2',
    cert_path: '/etc/nginx/ssl/app.example.com.crt',
    subject: 'CN=app.example.com',
    issuer: "CN=Let's Encrypt Authority X3",
    expires: 'Jun 20 23:59:59 2024 GMT',
    days_left: 97,
    tls_protocols: 'TLSv1.2 TLSv1.3',
    hsts_enabled: true,
    export_timestamp: '20240315_143022'
  },
  {
    id: 'ssl-3',
    cert_path: '/etc/nginx/ssl/admin.example.com.crt',
    subject: 'CN=admin.example.com',
    issuer: 'CN=DigiCert SHA2 Extended Validation Server CA',
    expires: 'Dec 31 23:59:59 2024 GMT',
    days_left: 291,
    tls_protocols: 'TLSv1.3',
    hsts_enabled: true,
    export_timestamp: '20240315_143022'
  },
  {
    id: 'ssl-4',
    cert_path: '/etc/nginx/ssl/payments.example.com.crt',
    subject: 'CN=payments.example.com',
    issuer: 'CN=DigiCert SHA2 Extended Validation Server CA',
    expires: 'Aug 15 23:59:59 2024 GMT',
    days_left: 153,
    tls_protocols: 'TLSv1.3',
    hsts_enabled: true,
    export_timestamp: '20240315_143022'
  },
  {
    id: 'ssl-5',
    cert_path: '/etc/nginx/ssl/auth.example.com.crt',
    subject: 'CN=auth.example.com',
    issuer: "CN=Let's Encrypt Authority X3",
    expires: 'Mar 25 23:59:59 2024 GMT',
    days_left: 15,
    tls_protocols: 'TLSv1.2 TLSv1.3',
    hsts_enabled: true,
    export_timestamp: '20240315_143022'
  },
  {
    id: 'ssl-6',
    cert_path: '/etc/nginx/ssl/wildcard.example.com.crt',
    subject: 'CN=*.example.com',
    issuer: 'CN=Sectigo RSA Domain Validation Secure Server CA',
    expires: 'Nov 10 23:59:59 2024 GMT',
    days_left: 240,
    tls_protocols: 'TLSv1.2 TLSv1.3',
    hsts_enabled: false,
    export_timestamp: '20240315_143022'
  },
  {
    id: 'ssl-7',
    cert_path: '/etc/nginx/ssl/staging.example.com.crt',
    subject: 'CN=staging.example.com',
    issuer: "CN=Let's Encrypt Authority X3",
    expires: 'Apr 01 23:59:59 2024 GMT',
    days_left: 22,
    tls_protocols: 'TLSv1.2 TLSv1.3',
    hsts_enabled: false,
    export_timestamp: '20240315_143022'
  },
]
