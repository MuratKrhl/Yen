"use client"

import { Area, AreaChart, ResponsiveContainer, YAxis } from "recharts"
import type { HistoryPoint } from "@/lib/monitoring"

export function Sparkline({
  data,
  color = "var(--chart-1)",
  height = 40,
}: {
  data: HistoryPoint[]
  color?: string
  height?: number
}) {
  const id = `spark-${Math.random().toString(36).slice(2)}`
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 2, right: 0, bottom: 0, left: 0 }}>
        <defs>
          <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.35} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <YAxis hide domain={[0, "dataMax"]} />
        <Area
          type="monotone"
          dataKey="responseMs"
          stroke={color}
          strokeWidth={1.5}
          fill={`url(#${id})`}
          isAnimationActive={false}
          dot={false}
        />
      </AreaChart>
    </ResponsiveContainer>
  )
}
