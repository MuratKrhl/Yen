/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import AWSHeader from './components/AWSHeader';
import InstancesTable from './components/InstancesTable';
import NetworkInterfacesTable from './components/NetworkInterfacesTable';

export default function App() {
  const [currentView, setCurrentView] = useState('instances');

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <AWSHeader />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar currentView={currentView} setCurrentView={setCurrentView} />
        <main className="flex-1 bg-white overflow-hidden">
          {currentView === 'instances' && <InstancesTable />}
          {currentView === 'network-interfaces' && <NetworkInterfacesTable />}
          {currentView !== 'instances' && currentView !== 'network-interfaces' && (
            <div className="flex flex-col items-center justify-center h-full text-gray-500 gap-4">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                <span className="text-2xl font-bold">...</span>
              </div>
              <h2 className="text-xl font-medium">Coming Soon</h2>
              <p className="text-sm">The {currentView} view is under development.</p>
              <button 
                onClick={() => setCurrentView('instances')}
                className="text-aws-blue hover:underline font-medium"
              >
                Go back to Instances
              </button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

