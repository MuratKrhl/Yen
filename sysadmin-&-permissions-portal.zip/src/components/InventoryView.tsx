import React, { useState } from 'react';
import { 
  Server, 
  Search, 
  Plus, 
  Trash2, 
  Edit, 
  Activity, 
  Globe, 
  TrendingUp, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  Lock
} from 'lucide-react';
import { InventoryItem } from '../types';

interface InventoryViewProps {
  inventory: InventoryItem[];
  canWrite: boolean;
  onUpdateInventory: (item: InventoryItem, mode: 'add' | 'edit' | 'delete') => void;
}

const InventoryView: React.FC<InventoryViewProps> = ({
  inventory,
  canWrite,
  onUpdateInventory
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('ALL');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [formMode, setFormMode] = useState<'add' | 'edit'>('add');
  
  // Form fields
  const [targetId, setTargetId] = useState('');
  const [name, setName] = useState('');
  const [type, setType] = useState<InventoryItem['type']>('Web Server');
  const [ip, setIp] = useState('');
  const [status, setStatus] = useState<InventoryItem['status']>('Online');
  const [region, setRegion] = useState('DE-Frankfurt');

  const filteredItems = inventory.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          item.ip.includes(searchTerm) || 
                          item.region.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'ALL' || item.type === filterType;
    return matchesSearch && matchesType;
  });

  const handleOpenAddForm = () => {
    setFormMode('add');
    setTargetId('');
    setName('');
    setType('Web Server');
    setIp('192.168.1.');
    setStatus('Online');
    setRegion('DE-Frankfurt');
    setIsFormOpen(true);
  };

  const handleOpenEditForm = (item: InventoryItem) => {
    setFormMode('edit');
    setTargetId(item.id);
    setName(item.name);
    setType(item.type);
    setIp(item.ip);
    setStatus(item.status);
    setRegion(item.region);
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !ip || !region) return;

    const itemPayload: any = {
      name,
      type,
      ip,
      status,
      region
    };

    if (formMode === 'edit') {
      itemPayload.id = targetId;
    }

    onUpdateInventory(itemPayload as InventoryItem, formMode);
    setIsFormOpen(false);
  };

  const handleDelete = (item: InventoryItem) => {
    if (confirm(`"${item.name}" sunucusunu envanterden silmek istediğinize emin misiniz?`)) {
      onUpdateInventory(item, 'delete');
    }
  };

  return (
    <div className="space-y-6">
      {/* Read-Only Banner Warning if no write privileges */}
      {!canWrite && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-xl flex items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2.5">
            <Lock className="h-4 w-4 shrink-0 text-amber-600" />
            <span className="text-xs font-semibold">Salt Okunur Mod — Envanter verileri uyarınca ekleme, çıkarma veya düzenleme yetkiniz bulunmamaktadır.</span>
          </div>
          <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded uppercase">Kilitli</span>
        </div>
      )}

      {/* Header and Add Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Altyapı Sunucu Envanteri</h1>
          <p className="text-sm text-slate-500 mt-0.5">Sistem odası, fiziksel ve sanal host sunucularının listesi.</p>
        </div>
        
        {canWrite && (
          <button
            id="btn-add-server"
            onClick={handleOpenAddForm}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm rounded-lg flex items-center gap-2 cursor-pointer transition-all shadow-xs"
          >
            <Plus className="h-4 w-4" />
            Sunucu Ekle
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col md:flex-row gap-4 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Sunucu adı, IP adresi ya da bölge ara..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-normal"
          />
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          {['ALL', 'Web Server', 'Database Server', 'Load Balancer', 'Cache Cluster', 'Storage Server'].map((typeOption) => (
            <button
              key={typeOption}
              onClick={() => setFilterType(typeOption)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap cursor-pointer transition-all
                ${filterType === typeOption 
                  ? 'bg-indigo-600 text-white shadow-xs' 
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
              {typeOption === 'ALL' ? 'Tümü' : typeOption}
            </button>
          ))}
        </div>
      </div>

      {/* Editor Modal/Form */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md shadow-2xl p-6 overflow-hidden">
            <h2 className="text-base font-bold text-slate-900 mb-4 border-b border-slate-100 pb-3">
              {formMode === 'add' ? 'Yeni Sunucu Tanımla' : 'Sunucu Kaydını Düzenle'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Sunucu Adı *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="srv-prod-01"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-normal"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Sunucu Rolü</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-normal"
                  >
                    <option value="Web Server">Web Server</option>
                    <option value="Database Server">Database Server</option>
                    <option value="Load Balancer">Load Balancer</option>
                    <option value="Cache Cluster">Cache Cluster</option>
                    <option value="Storage Server">Storage Server</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">IP Adresi *</label>
                  <input
                    type="text"
                    required
                    value={ip}
                    onChange={(e) => setIp(e.target.value)}
                    placeholder="192.168.1.10"
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-normal"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Durum</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-normal"
                  >
                    <option value="Online">Online</option>
                    <option value="Offline">Offline</option>
                    <option value="Maintenance">Maintenance</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Bölge *</label>
                  <input
                    type="text"
                    required
                    value={region}
                    onChange={(e) => setRegion(e.target.value)}
                    placeholder="DE-Frankfurt"
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-normal"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-600 text-sm font-semibold rounded-lg cursor-pointer"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-lg cursor-pointer"
                >
                  Kaydet
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Grid: Infrastructure Items */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredItems.map((item) => (
          <div 
            key={item.id} 
            className="bg-white border border-slate-200 hover:border-slate-300 rounded-xl overflow-hidden shadow-xs flex flex-col justify-between transition-all"
          >
            {/* Header Area */}
            <div className="p-5 border-b border-slate-100">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div className="p-2 b-indigo-50 bg-indigo-50 rounded-lg text-indigo-600 border border-indigo-100">
                    <Server className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-base">{item.name}</h3>
                    <p className="text-xs text-slate-400 font-mono mt-0.5">{item.ip}</p>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  {item.status === 'Online' && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full">
                      <CheckCircle className="h-3 w-3" /> Online
                    </span>
                  )}
                  {item.status === 'Maintenance' && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-amber-50 text-amber-700 px-2 py-0.5 rounded-full">
                      <AlertTriangle className="h-3 w-3" /> Bakım
                    </span>
                  )}
                  {item.status === 'Offline' && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-rose-50 text-rose-700 px-2 py-0.5 rounded-full">
                      <XCircle className="h-3 w-3" /> Offline
                    </span>
                  )}
                </div>
              </div>

              {/* Server Category and Region */}
              <div className="flex items-center gap-3 mt-4 text-xs font-semibold text-slate-500">
                <span className="bg-slate-100 px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider font-mono">{item.type}</span>
                <span className="flex items-center gap-1 text-slate-400 font-normal">
                  <Globe className="h-3.5 w-3.5" />
                  {item.region}
                </span>
              </div>
            </div>

            {/* Metrics Sliders Area */}
            <div className="p-5 bg-slate-50/50 space-y-3.5">
              {/* CPU load */}
              <div>
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5 font-semibold">
                  <span className="flex items-center gap-1.5">
                    <Activity className="h-3.5 w-3.5 text-slate-400" />
                    CPU Kullanımı
                  </span>
                  <span className="font-mono text-slate-700">{item.cpuUsage}%</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-300 ${item.cpuUsage > 75 ? 'bg-rose-500' : item.cpuUsage > 45 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                    style={{ width: `${item.cpuUsage}%` }}
                  />
                </div>
              </div>

              {/* Memory Usage */}
              <div>
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5 font-semibold">
                  <span className="flex items-center gap-1.5">
                    <TrendingUp className="h-3.5 w-3.5 text-slate-400" />
                    Bellek Kullanımı
                  </span>
                  <span className="font-mono text-slate-700">{item.memoryUsage}%</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-300 ${item.memoryUsage > 80 ? 'bg-rose-500' : item.memoryUsage > 55 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                    style={{ width: `${item.memoryUsage}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Actions Footer - conditional write */}
            {canWrite && (
              <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  id={`btn-edit-server-${item.id}`}
                  onClick={() => handleOpenEditForm(item)}
                  className="p-1.5 text-slate-500 hover:text-indigo-650 hover:bg-white border border-transparent hover:border-slate-200 rounded-lg transition-all cursor-pointer"
                  title="Düzenle"
                >
                  <Edit className="h-4 w-4" />
                </button>
                <button
                  id={`btn-delete-server-${item.id}`}
                  onClick={() => handleDelete(item)}
                  className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-white border border-transparent hover:border-slate-200 rounded-lg transition-all cursor-pointer"
                  title="Sil"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>
        ))}

        {filteredItems.length === 0 && (
          <div className="col-span-full bg-slate-50/50 rounded-2xl py-12 px-4 text-center border-2 border-dashed border-slate-200">
            <Server className="h-10 w-10 text-slate-300 mx-auto mb-3" />
            <h3 className="text-sm font-bold text-slate-600">Arama Kriterini Karşılayan Sunucu Bulunamadı</h3>
            <p className="text-xs text-slate-400 mt-1">Lütfen farklı filtre seçeneklerini ya da anahtar kelimeleri seçerek tekrar deneyin.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default InventoryView;
