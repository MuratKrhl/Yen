"use client"

import { useEffect } from "react"
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { X } from "lucide-react"
import type { Target } from "@/lib/monitoring"
import { StatusBadge } from "./status-badge"
import { TimingBreakdownBar } from "./timing-breakdown"
import { UptimeBars } from "./uptime-bars"
import { cn } from "@/lib/utils"
import { fmtDate, slaClass, timeAgo } from "@/lib/format"

function Metric({ label, value, className }: { label: string; value: string; className?: string }) {
  return (
    <div className="rounded-md border border-border bg-background/40 p-2.5">
      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className={cn("mt-0.5 font-mono text-sm", className)}>{value}</p>
    </div>
  )
}

export function TargetDetail({ target, onClose }: { target: Target | null; onClose: () => void }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose()
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [onClose])

  if (!target) return null
  const t = target

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} aria-hidden />
      <aside className="relative flex h-full w-full max-w-xl flex-col overflow-y-auto border-l border-border bg-card shadow-2xl">
        <div className="sticky top-0 z-10 flex items-start justify-between gap-3 border-b border-border bg-card/95 px-5 py-4 backdrop-blur">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="truncate text-base font-semibold">{t.name}</h2>
              <StatusBadge status={t.status} />
            </div>
            <p className="truncate font-mono text-xs text-muted-foreground">{t.url}</p>
          </div>
          <button onClick={onClose} className="rounded-md p-1.5 text-muted-foreground hover:bg-accent hover:text-foreground" aria-label="Close">
            <X className="size-4" />
          </button>
        </div>

        <div className="space-y-5 p-5">
          <div className="grid grid-cols-3 gap-2">
            <Metric label="Status code" value={String(t.statusCode)} className={t.status === "down" ? "text-destructive" : "text-foreground"} />
            <Metric label="Response" value={t.status === "down" ? "—" : `${t.timing.total}ms`} />
            <Metric label="Region" value={t.region} />
            <Metric label="24h uptime" value={`${t.uptime24h}%`} className={slaClass(t.uptime24h, 99.9)} />
            <Metric label="7d uptime" value={`${t.uptime7d}%`} className={slaClass(t.uptime7d, 99.9)} />
            <Metric label="30d uptime" value={`${t.uptime30d}%`} className={slaClass(t.uptime30d, 99.9)} />
          </div>

          <section>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Response time (12h)</h3>
            <div className="h-40 w-full rounded-lg border border-border bg-background/40 p-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={t.history} margin={{ top: 6, right: 6, bottom: 0, left: 0 }}>
                  <defs>
                    <linearGradient id="detailGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="label" tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} tickLine={false} axisLine={false} interval={11} />
                  <YAxis tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} tickLine={false} axisLine={false} width={48} tickFormatter={(v) => `${v}ms`} />
                  <Tooltip
                    contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 }}
                    formatter={(v: number) => [`${v}ms`, "Response"]}
                  />
                  <Area type="monotone" dataKey="responseMs" stroke="var(--chart-1)" strokeWidth={2} fill="url(#detailGrad)" isAnimationActive={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </section>

          {t.status !== "down" && (
            <section>
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Connection timing</h3>
              <div className="rounded-lg border border-border bg-background/40 p-3">
                <TimingBreakdownBar timing={t.timing} />
              </div>
            </section>
          )}

          <section>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Uptime history (last 60 checks)</h3>
            <div className="rounded-lg border border-border bg-background/40 p-3">
              <UptimeBars buckets={t.uptimeBars} />
              <div className="mt-2 flex justify-between font-mono text-[10px] text-muted-foreground">
                <span>{t.uptimeBars[0]?.label}</span>
                <span>now</span>
              </div>
            </div>
          </section>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <section className="rounded-lg border border-border bg-background/40 p-3">
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">SSL Certificate</h3>
              <dl className="space-y-1 text-xs">
                <div className="flex justify-between"><dt className="text-muted-foreground">Issuer</dt><dd className="font-mono">{t.ssl.issuer}</dd></div>
                <div className="flex justify-between"><dt className="text-muted-foreground">Expires</dt><dd className="font-mono">{fmtDate(t.ssl.expiresAt)}</dd></div>
                <div className="flex justify-between"><dt className="text-muted-foreground">Days left</dt><dd className={cn("font-mono", t.ssl.daysRemaining <= 14 ? "text-warning" : "text-success")}>{t.ssl.daysRemaining}</dd></div>
                <div className="flex justify-between"><dt className="text-muted-foreground">Algorithm</dt><dd className="font-mono">{t.ssl.algorithm}</dd></div>
              </dl>
            </section>
            <section className="rounded-lg border border-border bg-background/40 p-3">
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">DNS &amp; Network</h3>
              <dl className="space-y-1 text-xs">
                <div className="flex justify-between"><dt className="text-muted-foreground">IP ({t.dns.recordType})</dt><dd className="font-mono">{t.dns.ip}</dd></div>
                <div className="flex justify-between"><dt className="text-muted-foreground">TTL</dt><dd className="font-mono">{t.dns.ttl}s</dd></div>
                <div className="flex justify-between"><dt className="text-muted-foreground">Latency</dt><dd className="font-mono">{t.network.latencyAvg}ms</dd></div>
                <div className="flex justify-between"><dt className="text-muted-foreground">Packet loss</dt><dd className={cn("font-mono", t.network.packetLoss > 1 ? "text-warning" : "text-success")}>{t.network.packetLoss}%</dd></div>
                <div className="flex justify-between"><dt className="text-muted-foreground">Jitter</dt><dd className="font-mono">{t.network.jitter}ms</dd></div>
              </dl>
            </section>
          </div>

          <section className="rounded-lg border border-border bg-background/40 p-3">
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Checks &amp; content</h3>
            <dl className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
              <div className="flex justify-between"><dt className="text-muted-foreground">Interval</dt><dd className="font-mono">{t.checkInterval}s</dd></div>
              <div className="flex justify-between"><dt className="text-muted-foreground">Last success</dt><dd className="font-mono">{timeAgo(t.lastSuccess)}</dd></div>
              <div className="flex justify-between"><dt className="text-muted-foreground">Last failure</dt><dd className="font-mono">{timeAgo(t.lastFailure)}</dd></div>
              <div className="flex justify-between"><dt className="text-muted-foreground">Consec. fails</dt><dd className="font-mono">{t.consecutiveFailures}</dd></div>
              <div className="flex justify-between"><dt className="text-muted-foreground">Keyword</dt><dd className={cn("font-mono", t.keywordOk ? "text-success" : "text-destructive")}>{t.keywordOk ? "found" : "missing"}</dd></div>
              <div className="flex justify-between"><dt className="text-muted-foreground">HSTS/CSP/XFO</dt><dd className="font-mono">{[t.securityHeaders.hsts && "HSTS", t.securityHeaders.csp && "CSP", t.securityHeaders.xfo && "XFO"].filter(Boolean).join(" ") || "none"}</dd></div>
            </dl>
          </section>
        </div>
      </aside>
    </div>
  )
}
