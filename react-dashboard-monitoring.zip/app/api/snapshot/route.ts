import { NextResponse } from "next/server"
import { getSnapshot } from "@/lib/monitoring"

export const dynamic = "force-dynamic"

export async function GET() {
  return NextResponse.json(getSnapshot())
}
