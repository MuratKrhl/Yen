"use client"

import { useMemo } from "react"
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { Clock, Gauge, Timer, TrendingUp } from "lucide-react"
import type { Snapshot } from "@/lib/monitoring"
import { StatCard } from "./stat-card"
import { TimingBreakdownBar } from "./timing-breakdown"
import { StatusBadge } from "./status-badge"
import { cn } from "@/lib/utils"

export function UptimeSection({ snapshot }: { snapshot: Snapshot }) {
  const live = snapshot.targets.filter((t) => t.status !== "down")

  const agg = (sel: (n: number[]) => number, key: "p50" | "p95" | "p99") =>
    live.length ? Math.round(sel(live.map((t) => t[key]))) : 0

  const avg = (arr: number[]) => arr.reduce((a, b) => a + b, 0) / arr.length

  const trend = useMemo(() => {
    const len = snapshot.targets[0]?.history.length ?? 0
    const out: { label: string; responseMs: number }[] = []
    for (let i = 0; i < len; i++) {
      const vals = snapshot.targets.map((t) => t.history[i]).filter((p) => p && p.up)
      const v = vals.length ? Math.round(vals.reduce((a, p) => a + p.responseMs, 0) / vals.length) : 0
      out.push({ label: snapshot.targets[0].history[i].label, responseMs: v })
    }
    return out
  }, [snapshot])

  const sorted = [...snapshot.targets].sort((a, b) => b.p95 - a.p95)

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard icon={Gauge} label="p50 Latency" value={agg(avg, "p50")} unit="ms" tone="primary" hint="Median response" />
        <StatCard icon={Timer} label="p95 Latency" value={agg(avg, "p95")} unit="ms" tone="warning" hint="95th percentile" />
        <StatCard icon={TrendingUp} label="p99 Latency" value={agg(avg, "p99")} unit="ms" tone="destructive" hint="99th percentile" />
        <StatCard icon={Clock} label="Avg Response" value={snapshot.summary.avgResponse} unit="ms" hint="Live targets" />
      </div>

      <div className="rounded-lg border border-border bg-card p-4">
        <div className="mb-1 flex items-center justify-between">
          <h2 className="text-sm font-semibold">Aggregate Response Time</h2>
          <span className="text-xs text-muted-foreground">Last 12 hours · mean across targets</span>
        </div>
        <div className="h-56 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trend} margin={{ top: 10, right: 8, bottom: 0, left: 0 }}>
              <defs>
                <linearGradient id="respGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} tickLine={false} axisLine={false} interval={9} />
              <YAxis tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} tickLine={false} axisLine={false} width={52} tickFormatter={(v) => `${v}ms`} />
              <Tooltip
                contentStyle={{
                  background: "var(--popover)",
                  border: "1px solid var(--border)",
                  borderRadius: 8,
                  fontSize: 12,
                }}
                labelStyle={{ color: "var(--muted-foreground)" }}
                formatter={(v: number) => [`${v}ms`, "Response"]}
              />
              <Area type="monotone" dataKey="responseMs" stroke="var(--chart-1)" strokeWidth={2} fill="url(#respGrad)" isAnimationActive={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card">
        <div className="border-b border-border px-4 py-3">
          <h2 className="text-sm font-semibold">Timing Breakdown by Target</h2>
          <p className="text-xs text-muted-foreground">DNS · TCP · TLS · TTFB · Transfer — sorted by p95</p>
        </div>
        <ul className="divide-y divide-border">
          {sorted.map((t) => (
            <li key={t.id} className="px-4 py-3">
              <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{t.name}</span>
                  <StatusBadge status={t.status} />
                </div>
                <div className="flex items-center gap-4 font-mono text-xs">
                  <span className="text-muted-foreground">p50 <span className="text-foreground">{t.p50}ms</span></span>
                  <span className="text-muted-foreground">p95 <span className="text-warning">{t.p95}ms</span></span>
                  <span className="text-muted-foreground">p99 <span className="text-destructive">{t.p99}ms</span></span>
                  <span className={cn("font-semibold", t.status === "down" ? "text-destructive" : "text-foreground")}>
                    {t.status === "down" ? "no data" : `${t.timing.total}ms`}
                  </span>
                </div>
              </div>
              {t.status !== "down" ? (
                <TimingBreakdownBar timing={t.timing} />
              ) : (
                <div className="h-2.5 w-full rounded-full bg-destructive/20" />
              )}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
