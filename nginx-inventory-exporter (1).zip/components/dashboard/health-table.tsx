'use client'

import { useState, useMemo } from 'react'
import { Activity, CheckCircle, AlertTriangle, XCircle, ChevronDown, ChevronUp } from 'lucide-react'
import { 
  Table, 
  TableHeader, 
  TableBody, 
  TableHead, 
  TableRow, 
  TableCell 
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Progress } from '@/components/ui/progress'
import { HealthData } from '@/lib/mock-data'
import { cn } from '@/lib/utils'

interface HealthTableProps {
  health: HealthData[]
  searchQuery: string
}

type SortField = 'domain' | 'location' | 'status' | 'total_requests' | 'error_5xx_pct' | 'avg_latency_ms'
type SortDirection = 'asc' | 'desc'

const statusIcons = {
  UP: <CheckCircle className="h-4 w-4 text-success" />,
  DEGRADED: <AlertTriangle className="h-4 w-4 text-warning" />,
  DOWN: <XCircle className="h-4 w-4 text-destructive" />,
}

const statusColors = {
  UP: 'bg-success/10 text-success border-success/30',
  DEGRADED: 'bg-warning/10 text-warning border-warning/30',
  DOWN: 'bg-destructive/10 text-destructive border-destructive/30',
}

export function HealthTable({ health, searchQuery }: HealthTableProps) {
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [sortField, setSortField] = useState<SortField>('error_5xx_pct')
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc')
  const [page, setPage] = useState(0)
  const pageSize = 20

  const filteredAndSortedHealth = useMemo(() => {
    let result = health.filter(h => {
      const matchesSearch = 
        h.domain.toLowerCase().includes(searchQuery.toLowerCase()) ||
        h.location.toLowerCase().includes(searchQuery.toLowerCase())
      
      const matchesStatus = statusFilter === 'all' || h.status === statusFilter
      
      return matchesSearch && matchesStatus
    })

    result.sort((a, b) => {
      const aVal = a[sortField]
      const bVal = b[sortField]
      
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortDirection === 'asc' ? aVal - bVal : bVal - aVal
      }
      
      const comparison = String(aVal).localeCompare(String(bVal))
      return sortDirection === 'asc' ? comparison : -comparison
    })

    return result
  }, [health, searchQuery, statusFilter, sortField, sortDirection])

  const paginatedHealth = filteredAndSortedHealth.slice(page * pageSize, (page + 1) * pageSize)
  const totalPages = Math.ceil(filteredAndSortedHealth.length / pageSize)

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDirection(field === 'error_5xx_pct' || field === 'avg_latency_ms' ? 'desc' : 'asc')
    }
  }

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return null
    return sortDirection === 'asc' ? 
      <ChevronUp className="h-3.5 w-3.5" /> : 
      <ChevronDown className="h-3.5 w-3.5" />
  }

  // Stats summary
  const stats = useMemo(() => {
    const up = health.filter(h => h.status === 'UP').length
    const degraded = health.filter(h => h.status === 'DEGRADED').length
    const down = health.filter(h => h.status === 'DOWN').length
    return { up, degraded, down, total: health.length }
  }, [health])

  return (
    <div className="space-y-4">
      {/* Status Summary */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-card border border-border rounded-lg p-4 flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
            <Activity className="h-5 w-5 text-muted-foreground" />
          </div>
          <div>
            <p className="text-2xl font-semibold">{stats.total}</p>
            <p className="text-xs text-muted-foreground">Total Endpoints</p>
          </div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-success/10 flex items-center justify-center">
            <CheckCircle className="h-5 w-5 text-success" />
          </div>
          <div>
            <p className="text-2xl font-semibold text-success">{stats.up}</p>
            <p className="text-xs text-muted-foreground">Healthy</p>
          </div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-warning/10 flex items-center justify-center">
            <AlertTriangle className="h-5 w-5 text-warning" />
          </div>
          <div>
            <p className="text-2xl font-semibold text-warning">{stats.degraded}</p>
            <p className="text-xs text-muted-foreground">Degraded</p>
          </div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-destructive/10 flex items-center justify-center">
            <XCircle className="h-5 w-5 text-destructive" />
          </div>
          <div>
            <p className="text-2xl font-semibold text-destructive">{stats.down}</p>
            <p className="text-xs text-muted-foreground">Down</p>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-border flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Activity className="h-4 w-4 text-primary" />
            <h3 className="font-medium text-sm">Endpoint Health</h3>
          </div>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px] h-8 text-xs">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="UP">UP</SelectItem>
              <SelectItem value="DEGRADED">DEGRADED</SelectItem>
              <SelectItem value="DOWN">DOWN</SelectItem>
            </SelectContent>
          </Select>

          <Badge variant="secondary" className="ml-auto">
            {filteredAndSortedHealth.length} endpoints
          </Badge>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead 
                  className="w-[180px] cursor-pointer select-none"
                  onClick={() => handleSort('domain')}
                >
                  <div className="flex items-center gap-1">
                    Domain <SortIcon field="domain" />
                  </div>
                </TableHead>
                <TableHead 
                  className="cursor-pointer select-none"
                  onClick={() => handleSort('location')}
                >
                  <div className="flex items-center gap-1">
                    Location <SortIcon field="location" />
                  </div>
                </TableHead>
                <TableHead 
                  className="cursor-pointer select-none"
                  onClick={() => handleSort('status')}
                >
                  <div className="flex items-center gap-1">
                    Status <SortIcon field="status" />
                  </div>
                </TableHead>
                <TableHead 
                  className="text-right cursor-pointer select-none"
                  onClick={() => handleSort('total_requests')}
                >
                  <div className="flex items-center justify-end gap-1">
                    Requests <SortIcon field="total_requests" />
                  </div>
                </TableHead>
                <TableHead 
                  className="cursor-pointer select-none"
                  onClick={() => handleSort('error_5xx_pct')}
                >
                  <div className="flex items-center gap-1">
                    5xx Error Rate <SortIcon field="error_5xx_pct" />
                  </div>
                </TableHead>
                <TableHead 
                  className="text-right cursor-pointer select-none"
                  onClick={() => handleSort('avg_latency_ms')}
                >
                  <div className="flex items-center justify-end gap-1">
                    Avg Latency <SortIcon field="avg_latency_ms" />
                  </div>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedHealth.map((item) => (
                <TableRow key={item.id} className="group">
                  <TableCell className="font-mono text-sm text-primary">
                    {item.domain}
                  </TableCell>
                  <TableCell className="font-mono text-sm text-muted-foreground">
                    {item.location}
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="outline" 
                      className={cn("gap-1.5", statusColors[item.status])}
                    >
                      {statusIcons[item.status]}
                      {item.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right font-mono">
                    {item.total_requests.toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2 min-w-[120px]">
                      <Progress 
                        value={Math.min(item.error_5xx_pct * 10, 100)} 
                        className={cn(
                          "h-1.5 flex-1",
                          item.error_5xx_pct > 5 ? "[&>div]:bg-destructive" : 
                          item.error_5xx_pct > 2 ? "[&>div]:bg-warning" : 
                          "[&>div]:bg-success"
                        )}
                      />
                      <span className={cn(
                        "font-mono text-xs min-w-[40px] text-right",
                        item.error_5xx_pct > 5 ? "text-destructive" : 
                        item.error_5xx_pct > 2 ? "text-warning" : 
                        "text-muted-foreground"
                      )}>
                        {item.error_5xx_pct}%
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <span className={cn(
                      "font-mono text-sm",
                      item.avg_latency_ms > 300 ? "text-warning" : "text-muted-foreground"
                    )}>
                      {item.avg_latency_ms}ms
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        <div className="px-4 py-3 border-t border-border flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            Showing {page * pageSize + 1}-{Math.min((page + 1) * pageSize, filteredAndSortedHealth.length)} of {filteredAndSortedHealth.length}
          </p>
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setPage(p => Math.max(0, p - 1))}
              disabled={page === 0}
            >
              Previous
            </Button>
            <span className="text-xs text-muted-foreground px-2">
              Page {page + 1} of {totalPages}
            </span>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
              disabled={page >= totalPages - 1}
            >
              Next
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
