"use client"

import {
  Activity,
  ArrowUpRight,
  CheckCircle2,
  Gauge,
  ShieldAlert,
  Signal,
  TriangleAlert,
  XCircle,
} from "lucide-react"
import type { Snapshot, Target } from "@/lib/monitoring"
import { StatCard } from "./stat-card"
import { StatusBadge } from "./status-badge"
import { UptimeBars } from "./uptime-bars"
import { Sparkline } from "./sparkline"
import { statusColorClass, timeAgo } from "@/lib/format"
import { cn } from "@/lib/utils"

export function OverviewSection({
  snapshot,
  onSelect,
}: {
  snapshot: Snapshot
  onSelect: (t: Target) => void
}) {
  const s = snapshot.summary
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard icon={Activity} label="Total Targets" value={s.total} hint={`${snapshot.targets.length} monitored endpoints`} />
        <StatCard icon={CheckCircle2} label="Operational" value={s.up} tone="success" hint="Responding normally" />
        <StatCard icon={TriangleAlert} label="Degraded" value={s.degraded} tone="warning" hint="Elevated latency" />
        <StatCard icon={XCircle} label="Down" value={s.down} tone="destructive" hint="Failing checks" />
        <StatCard icon={Gauge} label="Avg Response" value={s.avgResponse} unit="ms" tone="primary" hint="Across live targets" />
        <StatCard icon={ShieldAlert} label="SSL Expiring" value={s.sslExpiringSoon} tone={s.sslExpiringSoon > 0 ? "warning" : "default"} hint="≤ 14 days" />
      </div>

      <div className="rounded-lg border border-border bg-card">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div className="flex items-center gap-2">
            <Signal className="size-4 text-muted-foreground" />
            <h2 className="text-sm font-semibold">Monitored Targets</h2>
          </div>
          <span className="text-xs text-muted-foreground">
            Overall availability{" "}
            <span className="font-mono text-success">{s.avgUptime30d}%</span> · SLA{" "}
            <span className="font-mono text-foreground">{s.overallSla}%</span>
          </span>
        </div>

        <div className="hidden grid-cols-12 gap-3 border-b border-border px-4 py-2 text-xs uppercase tracking-wide text-muted-foreground lg:grid">
          <div className="col-span-3">Target</div>
          <div className="col-span-1">Status</div>
          <div className="col-span-1 text-right">Code</div>
          <div className="col-span-1 text-right">Resp</div>
          <div className="col-span-1 text-right">24h</div>
          <div className="col-span-3">Uptime (last 60 checks)</div>
          <div className="col-span-2 text-right">Last check</div>
        </div>

        <ul className="divide-y divide-border">
          {snapshot.targets.map((t) => (
            <li key={t.id}>
              <button
                onClick={() => onSelect(t)}
                className="grid w-full grid-cols-2 items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-accent/40 lg:grid-cols-12"
              >
                <div className="col-span-2 min-w-0 lg:col-span-3">
                  <div className="flex items-center gap-2">
                    <span className="truncate text-sm font-medium">{t.name}</span>
                    <ArrowUpRight className="size-3.5 shrink-0 text-muted-foreground" />
                  </div>
                  <p className="truncate font-mono text-xs text-muted-foreground">{t.host}</p>
                </div>
                <div className="lg:col-span-1">
                  <StatusBadge status={t.status} />
                </div>
                <div className="hidden text-right font-mono text-sm lg:col-span-1 lg:block">
                  <span className={cn(t.status === "down" ? "text-destructive" : "text-muted-foreground")}>
                    {t.statusCode}
                  </span>
                </div>
                <div className="hidden text-right font-mono text-sm lg:col-span-1 lg:block">
                  {t.status === "down" ? <span className="text-destructive">—</span> : `${t.timing.total}ms`}
                </div>
                <div className="hidden text-right font-mono text-sm lg:col-span-1 lg:block">
                  <span className={statusColorClass(t.status)}>{t.uptime24h}%</span>
                </div>
                <div className="col-span-2 lg:col-span-3">
                  <UptimeBars buckets={t.uptimeBars.slice(-32)} />
                </div>
                <div className="hidden items-center justify-end gap-3 lg:col-span-2 lg:flex">
                  <div className="h-9 w-20">
                    <Sparkline
                      data={t.history.slice(-24)}
                      color={t.status === "down" ? "var(--destructive)" : t.status === "degraded" ? "var(--warning)" : "var(--chart-2)"}
                      height={36}
                    />
                  </div>
                  <span className="w-14 text-right text-xs text-muted-foreground">{timeAgo(t.lastSuccess)}</span>
                </div>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
