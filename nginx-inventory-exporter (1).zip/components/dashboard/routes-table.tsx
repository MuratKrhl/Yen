'use client'

import { useState, useMemo } from 'react'
import { Route, Lock, Unlock, Zap, Database, ChevronDown, ChevronUp } from 'lucide-react'
import { 
  Table, 
  TableHeader, 
  TableBody, 
  TableHead, 
  TableRow, 
  TableCell 
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { RouteData } from '@/lib/mock-data'
import { cn } from '@/lib/utils'

interface RoutesTableProps {
  routes: RouteData[]
  searchQuery: string
}

type SortField = 'domain' | 'location' | 'proxy_pass'
type SortDirection = 'asc' | 'desc'

export function RoutesTable({ routes, searchQuery }: RoutesTableProps) {
  const [domainFilter, setDomainFilter] = useState<string>('all')
  const [sortField, setSortField] = useState<SortField>('domain')
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc')
  const [page, setPage] = useState(0)
  const pageSize = 20

  const domains = useMemo(() => {
    const uniqueDomains = [...new Set(routes.map(r => r.domain))]
    return uniqueDomains.sort()
  }, [routes])

  const filteredAndSortedRoutes = useMemo(() => {
    let result = routes.filter(route => {
      const matchesSearch = 
        route.domain.toLowerCase().includes(searchQuery.toLowerCase()) ||
        route.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        route.proxy_pass.toLowerCase().includes(searchQuery.toLowerCase())
      
      const matchesDomain = domainFilter === 'all' || route.domain === domainFilter
      
      return matchesSearch && matchesDomain
    })

    result.sort((a, b) => {
      const aVal = a[sortField]
      const bVal = b[sortField]
      const comparison = aVal.localeCompare(bVal)
      return sortDirection === 'asc' ? comparison : -comparison
    })

    return result
  }, [routes, searchQuery, domainFilter, sortField, sortDirection])

  const paginatedRoutes = filteredAndSortedRoutes.slice(page * pageSize, (page + 1) * pageSize)
  const totalPages = Math.ceil(filteredAndSortedRoutes.length / pageSize)

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDirection('asc')
    }
  }

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return null
    return sortDirection === 'asc' ? 
      <ChevronUp className="h-3.5 w-3.5" /> : 
      <ChevronDown className="h-3.5 w-3.5" />
  }

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden">
      <div className="px-4 py-3 border-b border-border flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Route className="h-4 w-4 text-primary" />
          <h3 className="font-medium text-sm">Routing Rules</h3>
        </div>
        
        <Select value={domainFilter} onValueChange={setDomainFilter}>
          <SelectTrigger className="w-[200px] h-8 text-xs">
            <SelectValue placeholder="Filter by domain" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Domains</SelectItem>
            {domains.map(domain => (
              <SelectItem key={domain} value={domain}>{domain}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Badge variant="secondary" className="ml-auto">
          {filteredAndSortedRoutes.length} routes
        </Badge>
      </div>
      
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead 
                className="w-[180px] cursor-pointer select-none"
                onClick={() => handleSort('domain')}
              >
                <div className="flex items-center gap-1">
                  Domain <SortIcon field="domain" />
                </div>
              </TableHead>
              <TableHead>Port</TableHead>
              <TableHead>SSL</TableHead>
              <TableHead 
                className="cursor-pointer select-none"
                onClick={() => handleSort('location')}
              >
                <div className="flex items-center gap-1">
                  Location <SortIcon field="location" />
                </div>
              </TableHead>
              <TableHead>Type</TableHead>
              <TableHead 
                className="cursor-pointer select-none"
                onClick={() => handleSort('proxy_pass')}
              >
                <div className="flex items-center gap-1">
                  Backend <SortIcon field="proxy_pass" />
                </div>
              </TableHead>
              <TableHead>Timeout</TableHead>
              <TableHead className="text-center">Rate Limit</TableHead>
              <TableHead className="text-center">Cache</TableHead>
              <TableHead className="text-center">Backup</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedRoutes.map((route) => (
              <TableRow key={route.id} className="group">
                <TableCell className="font-mono text-sm text-primary">
                  {route.domain}
                </TableCell>
                <TableCell className="font-mono text-muted-foreground">
                  :{route.listen_port}
                </TableCell>
                <TableCell>
                  {route.ssl_enabled ? (
                    <Lock className="h-4 w-4 text-success" />
                  ) : (
                    <Unlock className="h-4 w-4 text-muted-foreground" />
                  )}
                </TableCell>
                <TableCell className="font-mono text-sm">
                  {route.location}
                </TableCell>
                <TableCell>
                  <Badge 
                    variant="outline" 
                    className={cn(
                      "text-xs",
                      route.match_type === 'exact' && "border-primary/50 text-primary",
                      route.match_type === 'regex' && "border-warning/50 text-warning",
                      route.match_type === 'prefix' && "border-muted-foreground/50"
                    )}
                  >
                    {route.match_type}
                  </Badge>
                </TableCell>
                <TableCell className="font-mono text-xs text-muted-foreground max-w-[200px] truncate">
                  {route.proxy_pass}
                </TableCell>
                <TableCell className="font-mono text-xs text-muted-foreground">
                  {route.read_timeout}
                </TableCell>
                <TableCell className="text-center">
                  {route.rate_limit && <Zap className="h-4 w-4 text-warning mx-auto" />}
                </TableCell>
                <TableCell className="text-center">
                  {route.cache_enabled && <Database className="h-4 w-4 text-primary mx-auto" />}
                </TableCell>
                <TableCell className="text-center">
                  {route.backup_upstream && (
                    <Badge variant="outline" className="text-xs">HA</Badge>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      <div className="px-4 py-3 border-t border-border flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          Showing {page * pageSize + 1}-{Math.min((page + 1) * pageSize, filteredAndSortedRoutes.length)} of {filteredAndSortedRoutes.length}
        </p>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setPage(p => Math.max(0, p - 1))}
            disabled={page === 0}
          >
            Previous
          </Button>
          <span className="text-xs text-muted-foreground px-2">
            Page {page + 1} of {totalPages}
          </span>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
            disabled={page >= totalPages - 1}
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  )
}
