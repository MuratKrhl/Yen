'use client'

import { useState, useMemo } from 'react'
import { Sidebar } from '@/components/dashboard/sidebar'
import { Header } from '@/components/dashboard/header'
import { Overview } from '@/components/dashboard/overview'
import { NodesTable } from '@/components/dashboard/nodes-table'
import { RoutesTable } from '@/components/dashboard/routes-table'
import { HealthTable } from '@/components/dashboard/health-table'
import { SSLTable } from '@/components/dashboard/ssl-table'
import { mockNodes, mockRoutes, mockHealth, mockSSL } from '@/lib/mock-data'

const tabTitles: Record<string, { title: string, subtitle: string }> = {
  overview: { title: 'Overview', subtitle: 'System-wide metrics and status' },
  nodes: { title: 'Server Nodes', subtitle: 'Nginx server instances and resources' },
  routes: { title: 'Routing Rules', subtitle: 'Domain routing and proxy configuration' },
  health: { title: 'Health Monitoring', subtitle: 'Endpoint status and error rates' },
  ssl: { title: 'SSL Certificates', subtitle: 'Certificate inventory and expiration tracking' },
}

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState('overview')
  const [searchQuery, setSearchQuery] = useState('')
  const [lastUpdated] = useState(() => {
    const now = new Date()
    return now.toLocaleString('tr-TR', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  })

  const stats = useMemo(() => ({
    nodes: mockNodes.length,
    routes: mockRoutes.length,
    healthIssues: mockHealth.filter(h => h.status !== 'UP').length,
    sslExpiring: mockSSL.filter(s => s.days_left <= 30).length,
  }), [])

  const handleRefresh = () => {
    // In a real app, this would refetch data
    window.location.reload()
  }

  const tabInfo = tabTitles[activeTab]

  return (
    <div className="min-h-screen flex bg-background">
      <Sidebar 
        activeTab={activeTab} 
        onTabChange={setActiveTab}
        stats={stats}
      />
      
      <div className="flex-1 flex flex-col">
        <Header
          title={tabInfo.title}
          subtitle={tabInfo.subtitle}
          searchValue={searchQuery}
          onSearchChange={setSearchQuery}
          onRefresh={handleRefresh}
          lastUpdated={lastUpdated}
        />
        
        <main className="flex-1 p-6 overflow-auto">
          {activeTab === 'overview' && (
            <Overview
              nodes={mockNodes}
              routes={mockRoutes}
              health={mockHealth}
              ssl={mockSSL}
            />
          )}
          
          {activeTab === 'nodes' && (
            <NodesTable nodes={mockNodes} searchQuery={searchQuery} />
          )}
          
          {activeTab === 'routes' && (
            <RoutesTable routes={mockRoutes} searchQuery={searchQuery} />
          )}
          
          {activeTab === 'health' && (
            <HealthTable health={mockHealth} searchQuery={searchQuery} />
          )}
          
          {activeTab === 'ssl' && (
            <SSLTable ssl={mockSSL} searchQuery={searchQuery} />
          )}
        </main>
      </div>
    </div>
  )
}
