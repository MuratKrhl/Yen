# Uptime Monitor — Entegrasyon Rehberi

## Genel Mimari

```
[NestJS Scheduler]
     ↓  setInterval (her URL için ayrı)
[UptimeCheckerService]  → DNS lookup + HTTP GET
     ↓
[SQL Server]  uptime_checks tablosu
     ↓
[UptimeController]  GET /api/uptime/summary  ←  React Query (30sn aralık)
                    GET /api/uptime/urls/:id/checks
```

## Dosya Yapısı

```
backend-nestjs/
  data/
    001_uptime_tables.sql         ← DB migration
  src/
    modules/
      uptime/
        uptime.entity.ts          ← TypeScript arayüzleri
        uptime-checker.service.ts ← setInterval + HTTP kontrolü
        uptime.service.ts         ← DB CRUD + özet sorgusu
        uptime.controller.ts      ← REST endpoint'ler
        uptime.module.ts          ← NestJS modülü (service.ts içinde yorum satırı)

client/
  src/
    components/
      UptimeTab.tsx               ← React bileşeni (URL ekle, liste, önizleme)
```

## Entegrasyon Adımları

### 1. SQL Server tabloları oluşturun
```sql
-- backend-nestjs/data/001_uptime_tables.sql dosyasını çalıştırın
```

### 2. NestJS bağımlılıkları ekleyin
```bash
cd server
npm install @nestjs/axios axios
```

### 3. UptimeModule'ü app.module.ts'e ekleyin
```typescript
// src/app.module.ts
import { UptimeModule } from './modules/uptime/uptime.module';

@Module({
  imports: [
    // ... mevcut modüller
    UptimeModule,
  ],
})
export class AppModule {}
```

### 4. uptime.module.ts'i uncomment edin
`uptime.service.ts` dosyasının altındaki yorum satırı haline getirilmiş
`UptimeModule` kodunu ayrı bir `uptime.module.ts` dosyasına taşıyın.

### 5. TypeORM entity'lerini oluşturun
`uptime.entity.ts` içindeki interface'leri TypeORM `@Entity()` decorator'larıyla
gerçek entity'lere dönüştürün ve `sqlserver.module.ts`'e ekleyin.

### 6. UptimeTab'ı mevcut Performance sidebar'a ekleyin
```tsx
// client/src/components/Performance.tsx (veya ilgili bileşen)
import { UptimeTab } from './UptimeTab';

// Sidebar tab listesine 'Uptime' sekmesini ekleyin
// <UptimeTab /> bileşenini render edin
```

## Kurum İçi DNS'lere Erişim

Backend sunucunuzun kurum içi DNS'lere erişimi olmalı:
- `dns.lookup()` işletim sisteminin DNS ayarlarını kullanır
- Eğer özel DNS sunucusu kullanıyorsanız, Node.js'e `--dns-result-order=ipv4first` flag'ini ekleyin
- İzolasyonlu ağda çalışıyorsanız `NODE_EXTRA_CA_CERTS` ile iç CA sertifikasını tanımlayın

## Gerçek Zamanlı Güncellemeler (İsteğe Bağlı)

Mevcut `websocket/` modülünüzü kullanarak push bildirimleri ekleyebilirsiniz:
```typescript
// UptimeCheckerService'e UptimeGateway'i inject edin
// Her checkUrl() sonucunda this.uptimeGateway.broadcastCheck(result) çağırın
// Frontend'de useEffect + WebSocket ile dinleyin
```

## API Endpoint'leri

| Metot  | URL                          | Açıklama                    |
|--------|------------------------------|-----------------------------|
| GET    | /api/uptime/urls             | Tüm izlenen URL'ler         |
| POST   | /api/uptime/urls             | Yeni URL ekle               |
| DELETE | /api/uptime/urls/:id         | URL sil + izlemeyi durdur   |
| GET    | /api/uptime/urls/:id/checks  | Kontrol geçmişi (son 100)   |
| GET    | /api/uptime/summary          | Dashboard özet metrikleri   |
