import { Instance, NetworkInterface } from './types';

export const DUMMY_INSTANCES: Instance[] = [
  { id: 'i-01c1db9e5e15989e2', name: 'aaur.trulab.com', state: 'Running', type: 't2.medium', statusCheck: '2/2 checks passed', alarmState: 'None', az: 'ap-south-1a' },
  { id: 'i-0636a01ad8b8db002', name: 'acgn.trulab.com', state: 'Stopped', type: 't2.medium', statusCheck: '-', alarmState: 'None', az: 'ap-south-1a' },
  { id: 'i-0d364f7d0b1513b03', name: 'acgn.trulab.com', state: 'Running', type: 't3.small', statusCheck: '3/3 checks passed', alarmState: 'None', az: 'ap-south-1a' },
  { id: 'i-0de28802a7b6eb1b1', name: 'alpine.trulab.com', state: 'Running', type: 't3.medium', statusCheck: '3/3 checks passed', alarmState: 'None', az: 'ap-south-1a' },
  { id: 'i-044b428496b4fafda', name: 'asr.trulab.com', state: 'Running', type: 't3.small', statusCheck: '3/3 checks passed', alarmState: 'None', az: 'ap-south-1a' },
  { id: 'i-0bc8a479113cf15b5', name: 'atlas.trulab.com', state: 'Running', type: 't3.medium', statusCheck: '3/3 checks passed', alarmState: 'None', az: 'ap-south-1a' },
  { id: 'i-0b6a46f34cf501991', name: 'avidity.trulab.com', state: 'Running', type: 't3.medium', statusCheck: '3/3 checks passed', alarmState: 'None', az: 'ap-south-1a' },
  { id: 'i-0eb1a810614531bff', name: 'beam.trulab.com', state: 'Running', type: 't3.medium', statusCheck: '3/3 checks passed', alarmState: 'None', az: 'ap-south-1a' },
  { id: 'i-09c2c25839a98f270', name: 'biocryst-sandbox.trulab.com', state: 'Running', type: 't3.small', statusCheck: '3/3 checks passed', alarmState: 'None', az: 'ap-south-1a' },
];

export const DUMMY_NETWORK_INTERFACES: NetworkInterface[] = [
  {
    id: 'eni-05a83d3c8f08bb680',
    name: '-',
    subnetId: 'subnet-0792151f4862cf3bd',
    vpcId: 'vpc-0affb225195163a7f',
    az: 'ap-south-1a',
    securityGroups: ['default'],
    status: 'In-use',
    interfaceType: 'Elastic network interface',
    description: 'Network Interface 2'
  },
  {
    id: 'eni-09d15020b31945e53',
    name: '-',
    subnetId: 'subnet-0792151f4862cf3bd',
    vpcId: 'vpc-0affb225195163a7f',
    az: 'ap-south-1a',
    securityGroups: ['launch-wizard-2'],
    status: 'In-use',
    interfaceType: 'Elastic network interface',
    description: 'Network Interface 1'
  }
];
