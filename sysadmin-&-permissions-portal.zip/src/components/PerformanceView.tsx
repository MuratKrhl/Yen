import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Cpu, 
  HardDrive, 
  TrendingUp, 
  ArrowUp, 
  ArrowDown, 
  RefreshCw,
  Clock
} from 'lucide-react';

interface PerformancePoint {
  cpu: number;
  ram: number;
  time: string;
}

const PerformanceView: React.FC = () => {
  const [points, setPoints] = useState<PerformancePoint[]>([
    { cpu: 15, ram: 45, time: '11:40' },
    { cpu: 22, ram: 44, time: '11:41' },
    { cpu: 32, ram: 46, time: '11:42' },
    { cpu: 28, ram: 45, time: '11:43' },
    { cpu: 18, ram: 47, time: '11:44' },
    { cpu: 24, ram: 48, time: '11:45' },
    { cpu: 35, ram: 50, time: '11:46' },
  ]);

  const [activeNetworkTX, setActiveNetworkTX] = useState(42.5);
  const [activeNetworkRX, setActiveNetworkRX] = useState(124.8);
  const [iops, setIops] = useState(380);

  // Hook to simulate rolling metrics
  useEffect(() => {
    const timer = setInterval(() => {
      setPoints((prev) => {
        const nextTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const lastRAM = prev[prev.length - 1].ram;
        const newCPU = Math.floor(Math.random() * 45) + 10; // CPU ranges 10% - 55%
        const newRAM = Math.min(Math.max(lastRAM + Math.floor(Math.random() * 5) - 2, 40), 85); // minor drift
        
        const updated = [...prev.slice(1), { cpu: newCPU, ram: newRAM, time: nextTime }];
        return updated;
      });

      setActiveNetworkTX((prev) => parseFloat((prev + (Math.random() * 10 - 5)).toFixed(1)));
      setActiveNetworkRX((prev) => parseFloat((prev + (Math.random() * 20 - 10)).toFixed(1)));
      setIops((prev) => Math.max(Math.floor(prev + (Math.random() * 50 - 25)), 120));
    }, 3000);

    return () => clearInterval(timer);
  }, []);

  // SVG Chart path calculators
  const generateSvgPath = (key: 'cpu' | 'ram', width: number, height: number) => {
    if (points.length === 0) return '';
    const length = points.length;
    const step = width / (length - 1);
    
    return points.reduce((path, p, index) => {
      const x = index * step;
      // invert Y coordinate because SVG y=0 is top
      const y = height - (p[key] / 100) * height; 
      return path + `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
    }, '');
  };

  const svgWidth = 500;
  const svgHeight = 200;
  const cpuPath = generateSvgPath('cpu', svgWidth, svgHeight);
  const ramPath = generateSvgPath('ram', svgWidth, svgHeight);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Sistem & Altyapı Performansı</h1>
          <p className="text-sm text-slate-500 mt-0.5">Merkezi CPU, bellek kapasiteleri ve anlık ağ I/O yükü grafikleri.</p>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
          <Clock className="h-4 w-4 text-slate-350" />
          Her 3 saniyede taze veri akmaktadır
        </div>
      </div>

      {/* Primary Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Metric Card 1: Load averages */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Yük Ortalaması (Load AVG)</span>
            <Cpu className="h-4 w-4 text-indigo-500" />
          </div>
          <div className="flex items-baseline gap-3 mt-4">
            <span className="text-3xl font-extrabold text-slate-800">0.82</span>
            <span className="text-sm text-slate-400 font-medium">1 dk</span>
            <span className="text-sm text-indigo-600 font-semibold bg-indigo-50 px-1.5 py-0.5 rounded font-mono">Normal</span>
          </div>
          <p className="text-xs text-slate-400 mt-3.5 italic font-normal">Son 5 dk: 1.15 / Son 15 dk: 1.02 (16 Core İşlemci)</p>
        </div>

        {/* Metric Card 2: Network Throughput */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Anlık Ağ I/O Değeri</span>
            <Activity className="h-4 w-4 text-purple-500" />
          </div>
          <div className="grid grid-cols-2 gap-4 mt-3">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-indigo-50 rounded-lg text-indigo-600">
                <ArrowDown className="h-4 w-4" />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wider">GELEN (RX)</span>
                <span className="text-sm font-extrabold font-mono text-slate-800">{activeNetworkRX} Mbps</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-amber-50 rounded-lg text-amber-600">
                <ArrowUp className="h-4 w-4" />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wider">GİDEN (TX)</span>
                <span className="text-sm font-extrabold font-mono text-slate-800">{activeNetworkTX} Mbps</span>
              </div>
            </div>
          </div>
          <p className="text-xs text-slate-400 mt-2 italic font-normal">Ağ Arayüzü: eth0 (Dual-10Gbps Bandwidth)</p>
        </div>

        {/* Metric Card 3: Storage IOPS */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Disk I/O Hızı (IOPS)</span>
            <HardDrive className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="flex items-baseline gap-2 mt-4">
            <span className="text-3xl font-extrabold text-slate-850 font-mono">{iops}</span>
            <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">iops</span>
          </div>
          <p className="text-xs text-slate-400 mt-3.5 italic font-normal">Ortalama Yazma Gecikmesi (Read Latency): 0.12 ms</p>
        </div>

      </div>

      {/* Main Dynamic Vector Chart */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4 mb-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-indigo-600" />
            <h2 className="font-bold text-slate-800 text-sm uppercase tracking-wider">Canlı Altyapı Metrik Grafiği</h2>
          </div>
          {/* Chart Legend */}
          <div className="flex items-center gap-4 text-xs font-semibold">
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-1.5 bg-indigo-500 rounded-sm" />
              <span className="text-slate-600">CPU Yükü</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-1.5 bg-purple-500 rounded-sm" />
              <span className="text-slate-600">RAM Doluluğu</span>
            </div>
          </div>
        </div>

        {/* Vector Area Container */}
        <div className="relative w-full h-[240px]">
          {/* Y Axis Guides */}
          <div className="absolute inset-0 flex flex-col justify-between text-[11px] font-mono text-slate-500 select-none pb-8">
            <div className="border-b border-slate-100 w-full pt-1">%100</div>
            <div className="border-b border-slate-100 w-full pt-1">%75</div>
            <div className="border-b border-slate-100 w-full pt-1">%50</div>
            <div className="border-b border-slate-100 w-full pt-1">%25</div>
            <div className="w-full pt-1">%0</div>
          </div>

          {/* SVG Vector Draw - Fluid Layout */}
          <div className="absolute inset-x-12 top-2 bottom-8">
            <svg 
              viewBox={`0 0 ${svgWidth} ${svgHeight}`} 
              className="w-full h-full overflow-visible"
              preserveAspectRatio="none"
            >
              {/* CPU Line Graph */}
              <path
                d={cpuPath}
                fill="none"
                stroke="#6366f1"
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="transition-all duration-300"
              />
              {/* CPU Glow */}
              <path
                d={`${cpuPath} L ${svgWidth} ${svgHeight} L 0 ${svgHeight} Z`}
                fill="url(#cpuGrad)"
                className="transition-all duration-300 opacity-15"
              />

              {/* RAM Line Graph */}
              <path
                d={ramPath}
                fill="none"
                stroke="#a855f7"
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="transition-all duration-300"
              />
              {/* RAM Glow */}
              <path
                d={`${ramPath} L ${svgWidth} ${svgHeight} L 0 ${svgHeight} Z`}
                fill="url(#ramGrad)"
                className="transition-all duration-300 opacity-15"
              />

              {/* Gradients definitions */}
              <defs>
                <linearGradient id="cpuGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366f1" />
                  <stop offset="100%" stopColor="#6366f1" stopOpacity="0" />
                </linearGradient>
                <linearGradient id="ramGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#a855f7" />
                  <stop offset="100%" stopColor="#a855f7" stopOpacity="0" />
                </linearGradient>
              </defs>
            </svg>
          </div>

          {/* X Axis Time Labels */}
          <div className="absolute bottom-1 inset-x-12 flex justify-between text-[11px] font-mono text-slate-500 font-normal">
            {points.map((p, ix) => (
              <span key={ix}>{p.time}</span>
            ))}
          </div>
        </div>

        {/* Dashboard Footnote */}
        <p className="text-[11px] text-slate-400 mt-2 text-center font-normal">
          * Dynamic Vector Graph, SVG stroke-interpolation ile canlandırılmıştır. Gerçek metrik akışı backend telemetry daemonuna bağlıdır.
        </p>
      </div>
    </div>
  );
};

export default PerformanceView;
