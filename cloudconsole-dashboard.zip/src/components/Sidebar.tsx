import React from 'react';
import { 
  LayoutDashboard, 
  Settings, 
  Terminal, 
  Database, 
  Network, 
  ShieldCheck, 
  HardDrive,
  Cloud,
  ChevronDown
} from 'lucide-react';

interface SidebarProps {
  currentView: string;
  setCurrentView: (view: string) => void;
}

export default function Sidebar({ currentView, setCurrentView }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'EC2 Dashboard', icon: LayoutDashboard },
    { id: 'instances', label: 'Instances', icon: Terminal },
    { id: 'instance-types', label: 'Instance Types', icon: Settings },
    { id: 'images', label: 'Images', icon: Cloud },
    { id: 'ebs', label: 'Elastic Block Store', icon: HardDrive },
    { id: 'network', label: 'Network & Security', icon: Network, subItems: [
      { id: 'security-groups', label: 'Security Groups' },
      { id: 'network-interfaces', label: 'Network Interfaces' }
    ]},
    { id: 'load-balancing', label: 'Load Balancing', icon: Settings }
  ];

  return (
    <div className="w-64 bg-white border-r h-screen overflow-y-auto flex-shrink-0 flex flex-col">
      <div className="p-4 border-b flex items-center justify-between">
        <span className="font-bold text-lg">EC2</span>
        <ChevronDown size={16} className="text-gray-400" />
      </div>
      
      <div className="flex-1 py-4">
        {menuItems.map((item) => (
          <div key={item.id}>
            <button
              onClick={() => !item.subItems && setCurrentView(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-2 text-sm transition-colors ${
                currentView === item.id 
                  ? 'bg-orange-50 text-aws-orange border-l-4 border-aws-orange' 
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <item.icon size={18} />
              <span className="flex-1 text-left font-medium">{item.label}</span>
            </button>
            
            {item.subItems && (
              <div className="ml-6 border-l pl-2 mt-1 mb-2">
                {item.subItems.map((sub) => (
                  <button
                    key={sub.id}
                    onClick={() => setCurrentView(sub.id)}
                    className={`w-full text-left px-4 py-1.5 text-xs transition-colors rounded-sm ${
                      currentView === sub.id 
                        ? 'text-aws-orange font-semibold bg-orange-50' 
                        : 'text-gray-500 hover:text-gray-800'
                    }`}
                  >
                    {sub.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
