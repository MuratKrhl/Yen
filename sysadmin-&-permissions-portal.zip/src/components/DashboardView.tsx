import React from 'react';
import { 
  Server, 
  CalendarRange, 
  ShieldAlert, 
  Activity, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Terminal, 
  ArrowRight,
  RefreshCw
} from 'lucide-react';
import { InventoryItem, RosterEntry, AuditLog } from '../types';

interface DashboardViewProps {
  inventory: InventoryItem[];
  roster: RosterEntry[];
  logs: AuditLog[];
  onNavigate: (page: string) => void;
  canWrite: boolean;
  onQuickRestart: () => void;
}

const DashboardView: React.FC<DashboardViewProps> = ({
  inventory,
  roster,
  logs,
  onNavigate,
  canWrite,
  onQuickRestart
}) => {
  // Stats calculations
  const onlineServers = inventory.filter(s => s.status === 'Online').length;
  const maintenanceServers = inventory.filter(s => s.status === 'Maintenance').length;
  const totalServers = inventory.length;

  const activeRoster = roster.find(r => r.date === '2026-06-01' || r.date === new Date().toISOString().split('T')[0]) || roster[0];

  const averageCpu = Math.round(inventory.reduce((acc, curr) => acc + curr.cpuUsage, 0) / (totalServers || 1));
  const averageMem = Math.round(inventory.reduce((acc, curr) => acc + curr.memoryUsage, 0) / (totalServers || 1));

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-2xl p-6 shadow-sm border border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">SysAdmin Portal & Operasyon Merkezi</h1>
            <p className="text-slate-300 mt-1.5 text-sm max-w-2xl">
              Altyapı durumunu takip edin, otomatik Ansible playbook'ları koşturun ve kullanıcı erişim izinlerini dinamik olarak yönetin.
            </p>
          </div>
          <div className="flex gap-2.5">
            <button
              id="btn-navigate-ansible"
              onClick={() => onNavigate('Ansible')}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm rounded-lg flex items-center gap-2 transition-all cursor-pointer shadow-sm"
            >
              <Terminal className="h-4 w-4" />
              Ansible Koştur
            </button>
            <button
              id="btn-navigate-selfservice"
              onClick={() => onNavigate('Self Service')}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-sm rounded-lg flex items-center gap-2 transition-all cursor-pointer"
            >
              Self Service
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Grid: 4 Info Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Servers */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-100">
            <Server className="h-6 w-6 text-emerald-600" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-medium uppercase tracking-wider block">Sunucu Durumu</span>
            <span className="text-2xl font-bold text-slate-800">{onlineServers}/{totalServers} Aktif</span>
            <span className="text-xs text-slate-400 block mt-0.5">{maintenanceServers} Bakımda</span>
          </div>
        </div>

        {/* Card 2: Average CPU */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="p-3 bg-indigo-50 rounded-lg border border-indigo-100">
            <Activity className="h-6 w-6 text-indigo-600" />
          </div>
          <div className="flex-1">
            <span className="text-xs text-slate-500 font-medium uppercase tracking-wider block">Ortalama İşlemci</span>
            <span className="text-2xl font-bold text-slate-800">{averageCpu}% CPU</span>
            <div className="w-full bg-slate-100 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div 
                className={`h-full rounded-full transition-all duration-500 ${averageCpu > 50 ? 'bg-amber-500' : 'bg-indigo-600'}`}
                style={{ width: `${averageCpu}%` }}
              />
            </div>
          </div>
        </div>

        {/* Card 3: Memory Loading */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="p-3 bg-purple-50 rounded-lg border border-purple-100">
            <Activity className="h-6 w-6 text-purple-600" />
          </div>
          <div className="flex-1">
            <span className="text-xs text-slate-500 font-medium uppercase tracking-wider block">Bellek Doluluğu</span>
            <span className="text-2xl font-bold text-slate-800">{averageMem}% RAM</span>
            <div className="w-full bg-slate-100 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div 
                className={`h-full rounded-full transition-all duration-500 ${averageMem > 70 ? 'bg-amber-500' : 'bg-purple-600'}`}
                style={{ width: `${averageMem}%` }}
              />
            </div>
          </div>
        </div>

        {/* Card 4: Active Duty */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="p-3 bg-amber-50 rounded-lg border border-amber-100">
            <CalendarRange className="h-6 w-6 text-amber-600" />
          </div>
          <div className="overflow-hidden">
            <span className="text-xs text-slate-500 font-medium uppercase tracking-wider block">Nöbetçi Personel</span>
            <span className="text-base font-bold text-slate-800 truncate block">{activeRoster?.name || 'Belirlenmedi'}</span>
            <span className="text-xs text-amber-600 font-medium mt-0.5 block">{activeRoster?.phone || 'İletişim yok'}</span>
          </div>
        </div>
      </div>

      {/* Main Content Split Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Audit Logs Log Area (2 Columns) */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden lg:col-span-2">
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 bg-slate-50">
            <div className="flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-indigo-600" />
              <h2 className="font-bold text-slate-800">Sistem ve Güvenlik Günlüğü (Audit Log)</h2>
            </div>
            <span className="text-xs bg-slate-200 hover:bg-slate-300 text-slate-600 px-2 py-1 rounded-md font-medium flex items-center gap-1 cursor-pointer">
              <Clock className="h-3 w-3" /> Son 50 İşlem
            </span>
          </div>

          <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
            {logs.length === 0 ? (
              <div className="p-8 text-center text-slate-400">
                Layıksıyla günlüğe kaydedilmiş bir aksiyon bulunmamaktadır.
              </div>
            ) : (
              logs.map((log) => (
                <div key={log.id} className="p-4 hover:bg-slate-50/50 transition-colors flex items-start gap-3.5">
                  <div className="mt-0.5">
                    {log.status === 'success' && (
                      <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0" />
                    )}
                    {log.status === 'warning' && (
                      <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0" />
                    )}
                    {log.status === 'error' && (
                      <ShieldAlert className="h-5 w-5 text-rose-500 shrink-0" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-semibold text-slate-850 truncate">{log.action}</span>
                      <span className="text-xs font-mono text-slate-400 shrink-0">
                        {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5 break-words font-normal leading-relaxed">{log.details}</p>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono">Yapıcı:</span>
                      <span className="text-[10px] bg-slate-100 text-slate-600 font-semibold px-1.5 py-0.5 rounded font-mono">{log.user}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Sidebar Status Widgets (1 Column) */}
        <div className="space-y-6">
          {/* Quick Stats Panel */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs p-5">
            <h3 className="font-bold text-slate-800 border-b border-slate-100 pb-3 mb-3">Hızlı İşlemler</h3>
            
            <div className="space-y-2.5">
              <button
                id="btn-quick-nginx-restart"
                disabled={!canWrite}
                onClick={onQuickRestart}
                className={`w-full text-left p-3 rounded-lg border text-xs font-semibold flex items-center justify-between transition-all group
                  ${canWrite 
                    ? 'border-indigo-100 hover:border-indigo-300 hover:bg-indigo-50/30 text-indigo-700 bg-white cursor-pointer' 
                    : 'border-slate-100 bg-slate-50 text-slate-400 cursor-not-allowed'}`}
              >
                <div className="flex items-center gap-2">
                  <RefreshCw className={`h-4 w-4 ${canWrite ? 'text-indigo-600 group-hover:rotate-180 duration-500 transition-transform' : 'text-slate-300'}`} />
                  <div>
                    <span className="block font-bold">Nginx Sunucularını Yeniden Başlat</span>
                    <span className="block text-[10px] text-slate-400 font-normal mt-0.5">Tüm load balancer ve web nodeları tetikler</span>
                  </div>
                </div>
                {canWrite ? (
                  <span className="bg-indigo-100 text-indigo-800 text-[9px] px-1.5 py-0.5 rounded font-bold uppercase">Yaz Yetkisi</span>
                ) : (
                  <span className="bg-slate-200 text-slate-400 text-[9px] px-1.5 py-0.5 rounded font-bold uppercase">Engelli</span>
                )}
              </button>

              <button
                id="btn-navigate-links"
                onClick={() => onNavigate('Önemli Linkler')}
                className="w-full text-left p-3 rounded-lg border border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold flex items-center justify-between transition-all cursor-pointer"
              >
                <div>
                  <span className="block font-bold text-slate-700">Dış Servis Bağlantıları</span>
                  <span className="block text-[10px] text-slate-400 font-normal mt-0.5">Grafana, AWS ve Kibana referansları</span>
                </div>
                <ArrowRight className="h-4 w-4 text-slate-400" />
              </button>
            </div>
          </div>

          {/* Infrastructure Health Card */}
          <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white p-5 rounded-xl shadow-xs border border-indigo-950">
            <h4 className="font-bold text-sm text-indigo-200 border-b border-indigo-800 pb-2.5 mb-3">Portal Detayları</h4>
            
            <div className="space-y-3 font-mono text-xs text-indigo-100">
              <div className="flex justify-between">
                <span className="text-indigo-300">Ortam (Env):</span>
                <span>Production-Sim</span>
              </div>
              <div className="flex justify-between">
                <span className="text-indigo-300">Server Port:</span>
                <span>3000</span>
              </div>
              <div className="flex justify-between">
                <span className="text-indigo-300">Region:</span>
                <span>europe-west-2</span>
              </div>
              <div className="flex justify-between">
                <span className="text-indigo-300">Client Frame:</span>
                <span>Active</span>
              </div>
              <div className="pt-2 border-t border-indigo-800 text-center text-[10px] text-indigo-400">
                Dinamik Yetkilendirme Engine v1.2.0
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default DashboardView;
