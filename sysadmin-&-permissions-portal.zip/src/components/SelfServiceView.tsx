import React, { useState } from 'react';
import { 
  Wrench, 
  RefreshCw, 
  HardDriveUpload, 
  Trash2, 
  ShieldCheck, 
  Network, 
  Terminal, 
  Play, 
  AlertTriangle,
  Loader2,
  Lock
} from 'lucide-react';

interface Task {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
  stages: string[];
}

const SELF_SERVICE_TASKS: Task[] = [
  {
    id: 'nginx',
    name: 'Nginx Servisini Yeniden Başlat',
    description: 'Load balancer arkasındaki tüm aktif web nodeları ve ana proxy sunucusunun konfigürasyonunu yeniden yükler.',
    icon: RefreshCw,
    color: 'text-indigo-600 bg-indigo-50 border-indigo-100',
    stages: [
      'Nginx konfigürasyon testi yapılıyor (nginx -t)...',
      'nginx: the configuration file /etc/nginx/nginx.conf syntax is ok',
      'nginx: configuration file /etc/nginx/nginx.conf test is successful',
      'Web-01 host Nginx servisi tetiklendi...',
      'Web-02 host Nginx servisi tetiklendi...',
      'Nginx proxy nodeları reload tamamlandı.'
    ]
  },
  {
    id: 'disk',
    name: 'Kök Bölüm Disk Alanını Genişlet (DEV)',
    description: 'Geliştirme sunucularında (DEV) dolan disk alanı için kök disk partisyonunu %15 oranında genişletme talebini uygular.',
    icon: HardDriveUpload,
    color: 'text-purple-600 bg-purple-50 border-purple-100',
    stages: [
      'srv-dev-01 disk blok yapısı taranıyor...',
      'Eski disk bölümü: /dev/sda1 (50GB)',
      'LVM volume grubu genişletiliyor (vg_root)...',
      'Dosya sistemi yeniden ölçeklendiriliyor (resize2fs)...',
      'Yeni disk bölümü başarıyla yapılandırıldı: /dev/sda1 (75GB / %50 Expansion).'
    ]
  },
  {
    id: 'redis',
    name: 'Redis Ön Belleğini Sıfırla (Flushall)',
    description: 'Geçici önbellek, oturum verileri ve eski kuyruk kayıtlarını bellek üzerinden tamamen temizler.',
    icon: Trash2,
    color: 'text-rose-600 bg-rose-50 border-rose-100',
    stages: [
      'Redis cluster durum denetimi yapılıyor...',
      'Aktif node bağlantısı kuruldu (192.168.1.15:6379)...',
      'Sıfırlama komutu (FLUSHALL) iletiliyor...',
      'Redis 5.0.14 Response: OK',
      'Önbellek temizlendi, 12,482 anahtar (~124MB) kaldırıldı.'
    ]
  },
  {
    id: 'ip',
    name: 'Geçici Genel (Public) IP Tanımla',
    description: 'Belirtilen ofis IP adresi ya da dış host için 4 saat süreyle port izinlerini otomatik olarak etkin kılar.',
    icon: Network,
    color: 'text-amber-600 bg-amber-50 border-amber-100',
    stages: [
      'Dış IP protokolü kontrol ediliyor...',
      'Gateway ACL firewall kuralları taranıyor...',
      'Yeni geçici kural oluşturuldu: ALLOW TCP:22,443 FROM CLIENT_IP...',
      'Kural iptal sayacı başlatıldı (Duration: 4 Hours)...',
      'Güvenlik yetkisi başarıyla firewall gatewaye enjekte edildi.'
    ]
  },
  {
    id: 'php',
    name: 'PHP-FPM Havuzunu Yeniden Başlat',
    description: 'Hız ya da kaynak tüketimi sonrası tıkanan PHP FastCGI Proses Yöneticisi canlandırma döngüsünü tetikler.',
    icon: ShieldCheck,
    color: 'text-emerald-600 bg-emerald-50 border-emerald-100',
    stages: [
      'php8.1-fpm proses tablosu alınıyor...',
      'Aktif threadler temizlenmeye zorlanıyor (SIGUSR2)...',
      'fpm pool web-pool başarıyla yeniden yapılandırıldı...',
      'Proses canlandırma başarılı. PHP-FPM aktif servis taze döngüye girdi.'
    ]
  }
];

interface SelfServiceViewProps {
  canWrite: boolean;
  onTriggerLog: (action: string, details: string, status: 'success' | 'warning' | 'error') => void;
  user: string;
}

const SelfServiceView: React.FC<SelfServiceViewProps> = ({
  canWrite,
  onTriggerLog,
  user
}) => {
  const [runningTaskId, setRunningTaskId] = useState<string | null>(null);
  const [taskLogs, setTaskLogs] = useState<string[]>([]);
  const [taskProgress, setTaskProgress] = useState(0);

  const runTask = (task: Task) => {
    if (!canWrite) return;
    setRunningTaskId(task.id);
    setTaskProgress(0);
    setTaskLogs([]);

    onTriggerLog('Self-Service İşlem', `"${task.name}" görevi manuel olarak başlatıldı.`, 'warning');

    // Simulate logs output
    let stageIndex = 0;
    const interval = setInterval(() => {
      if (stageIndex < task.stages.length) {
        setTaskLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] ${task.stages[stageIndex]}`]);
        setTaskProgress((prev) => Math.min(prev + Math.floor(100 / task.stages.length), 100));
        stageIndex++;
      } else {
        clearInterval(interval);
        setTaskProgress(100);
        setRunningTaskId(null);
        onTriggerLog('Self-Service Tamamlandı', `"${task.name}" başarıyla yürütüldü.`, 'success');
      }
    }, 1200);
  };

  return (
    <div className="space-y-6">
      {/* Read-Only Warning Banner */}
      {!canWrite && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-xl flex items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2.5">
            <Lock className="h-4 w-4 shrink-0 text-amber-600" />
            <span className="text-xs font-semibold">Salt Okunur Mod — Self service sunucu operasyonlarını çalıştırmak için düzenleme (Write) yetkiniz olmalıdır.</span>
          </div>
          <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded uppercase font-mono">Yetki Sınırı</span>
        </div>
      )}

      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-900">Self Service Operasyon Merkezi</h1>
        <p className="text-sm text-slate-500 mt-0.5">Yazılımcılar ve sistem operatörleri için ön onaylı hızlı altyapı otomasyonu.</p>
      </div>

      {/* Grid: Tasks and Terminal output */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Tasks lists */}
        <div className="space-y-4">
          {SELF_SERVICE_TASKS.map((task) => {
            const TaskIcon = task.icon;
            const isCurrentlyRunning = runningTaskId === task.id;
            const isAnyRunning = runningTaskId !== null;

            return (
              <div 
                key={task.id}
                className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex items-start gap-4 hover:border-slate-300 transition-all"
              >
                <div className={`p-3 rounded-lg border shrink-0 ${task.color}`}>
                  <TaskIcon className="h-6 w-6" />
                </div>
                
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-slate-850 text-sm leading-snug">{task.name}</h3>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">{task.description}</p>
                  
                  {/* Trigger Button */}
                  <div className="mt-3.5 flex items-center gap-3">
                    <button
                      id={`btn-trigger-${task.id}`}
                      disabled={!canWrite || isAnyRunning}
                      onClick={() => runTask(task)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer border shadow-xs transition-all
                        ${!canWrite 
                          ? 'bg-slate-50 border-slate-150 text-slate-400 cursor-not-allowed' 
                          : isCurrentlyRunning
                            ? 'bg-amber-50 border-amber-200 text-amber-700 font-bold'
                            : isAnyRunning
                              ? 'bg-slate-50 border-slate-100 text-slate-300 cursor-not-allowed'
                              : 'bg-indigo-600 hover:bg-indigo-700 border-indigo-650 text-white font-bold'}`}
                    >
                      {isCurrentlyRunning ? (
                        <>
                          <Loader2 className="h-3.5 w-3.5 animate-spin text-amber-600" />
                          Yürütülüyor...
                        </>
                      ) : (
                        <>
                          <Play className="h-3.5 w-3.5 shrink-0" />
                          Görevi Çalıştır
                        </>
                      )}
                    </button>
                    {!canWrite && (
                      <span className="text-[10px] text-slate-400 italic">Erişim izniniz kısıtlandı</span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right: stdout Terminal logs outputs */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-inner flex flex-col justify-between h-[450px]">
          <div>
            {/* Terminal Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Terminal className="h-4 w-4 text-emerald-500" />
                <span className="font-mono text-xs font-bold text-slate-300">OTOMASYON KONSOLU (STDOUT)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              </div>
            </div>

            {/* Logs Area */}
            <div className="space-y-2 font-mono text-xs overflow-y-auto max-h-[310px] text-slate-400 leading-relaxed">
              {taskLogs.length === 0 ? (
                <div className="text-slate-600 italic py-10 text-center font-normal">
                  ~ Sol menüden bir self service otomasyon komutu çalıştırarak logların akışını izleyebilirsiniz.
                </div>
              ) : (
                taskLogs.map((log, index) => (
                  <div key={index} className="break-words font-light">
                    {log.includes('Response: OK') || log.includes('Reload tamamlandı') || log.includes('başarıyla built') ? (
                      <span className="text-emerald-400 font-semibold">{log}</span>
                    ) : log.includes('hata') || log.includes('ERR') || log.includes('Warning') ? (
                      <span className="text-rose-400 font-semibold">{log}</span>
                    ) : (
                      <span>{log}</span>
                    )}
                  </div>
                ))
              )}

              {/* Progress dynamic cursor block */}
              {runningTaskId && (
                <div className="flex items-center gap-1.5 text-indigo-400 font-semibold mt-4">
                  <span className="h-2 w-2 rounded-full bg-indigo-500 animate-ping" />
                  <span>Sistem geri dönüt arkaplanda izleniyor... [%{taskProgress}]</span>
                </div>
              )}
            </div>
          </div>

          {/* Progress Bar Footer */}
          {runningTaskId && (
            <div className="pt-4 border-t border-slate-800">
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 mb-1.5">
                <span>Otomasyon İlerlemesi</span>
                <span>%{taskProgress}</span>
              </div>
              <div className="w-full bg-slate-850 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-indigo-500 rounded-full transition-all duration-300"
                  style={{ width: `${taskProgress}%` }}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SelfServiceView;
