'use client'

import { LucideIcon } from 'lucide-react'
import { cn } from '@/lib/utils'

interface StatCardProps {
  title: string
  value: string | number
  subtitle?: string
  icon: LucideIcon
  trend?: {
    value: number
    isPositive: boolean
  }
  variant?: 'default' | 'success' | 'warning' | 'error'
}

export function StatCard({ 
  title, 
  value, 
  subtitle, 
  icon: Icon,
  trend,
  variant = 'default'
}: StatCardProps) {
  return (
    <div className="bg-card border border-border rounded-lg p-5">
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <p className="text-sm text-muted-foreground">{title}</p>
          <div className="flex items-baseline gap-2">
            <span className={cn(
              "text-2xl font-semibold",
              variant === 'success' && "text-success",
              variant === 'warning' && "text-warning",
              variant === 'error' && "text-destructive",
              variant === 'default' && "text-foreground"
            )}>
              {value}
            </span>
            {trend && (
              <span className={cn(
                "text-xs font-medium",
                trend.isPositive ? "text-success" : "text-destructive"
              )}>
                {trend.isPositive ? '+' : ''}{trend.value}%
              </span>
            )}
          </div>
          {subtitle && (
            <p className="text-xs text-muted-foreground">{subtitle}</p>
          )}
        </div>
        <div className={cn(
          "h-10 w-10 rounded-lg flex items-center justify-center",
          variant === 'success' && "bg-success/10",
          variant === 'warning' && "bg-warning/10",
          variant === 'error' && "bg-destructive/10",
          variant === 'default' && "bg-primary/10"
        )}>
          <Icon className={cn(
            "h-5 w-5",
            variant === 'success' && "text-success",
            variant === 'warning' && "text-warning",
            variant === 'error' && "text-destructive",
            variant === 'default' && "text-primary"
          )} />
        </div>
      </div>
    </div>
  )
}
