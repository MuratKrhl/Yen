export interface PagePermission {
  read: boolean;
  write: boolean;
}

export type PermissionsMap = Record<string, PagePermission>;

export interface ManagedPage {
  id: string;
  label: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  avatarUrl?: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  type: 'Web Server' | 'Database Server' | 'Load Balancer' | 'Cache Cluster' | 'Storage Server';
  ip: string;
  status: 'Online' | 'Offline' | 'Maintenance';
  cpuUsage: number;
  memoryUsage: number;
  region: string;
}

export interface AnsiblePlaybook {
  id: string;
  name: string;
  description: string;
  status: 'idle' | 'running' | 'success' | 'failed';
  lastRun?: string;
}

export interface PlaybookTemplate {
  id: string;
  name: string;
  description: string;
  steps: string[];
}

export interface RosterEntry {
  id: string;
  date: string; // YYYY-MM-DD
  name: string;
  phone: string;
  team: 'Operations' | 'Database' | 'Security' | 'DevOps';
}

export interface QuickLink {
  id: string;
  title: string;
  url: string;
  category: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
  timestamp: string;
}

export interface AuditLog {
  id: string;
  user: string;
  action: string;
  details: string;
  timestamp: string;
  status: 'success' | 'warning' | 'error';
}
