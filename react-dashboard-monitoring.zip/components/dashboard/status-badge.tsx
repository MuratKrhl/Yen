import { cn } from "@/lib/utils"
import type { Status } from "@/lib/monitoring"
import { statusLabel } from "@/lib/format"

export function StatusBadge({ status, className }: { status: Status; className?: string }) {
  const styles =
    status === "up"
      ? "bg-success/15 text-success border-success/30"
      : status === "degraded"
        ? "bg-warning/15 text-warning border-warning/30"
        : "bg-destructive/15 text-destructive border-destructive/30"
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-xs font-medium",
        styles,
        className,
      )}
    >
      <span
        className={cn(
          "size-1.5 rounded-full",
          status === "up" ? "bg-success" : status === "degraded" ? "bg-warning" : "bg-destructive",
          status === "down" && "animate-pulse-dot",
        )}
      />
      {statusLabel(status)}
    </span>
  )
}
