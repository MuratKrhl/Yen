'use client'

import { useMemo } from 'react'
import { ShieldCheck, AlertTriangle, Clock, Shield, CheckCircle } from 'lucide-react'
import { 
  Table, 
  TableHeader, 
  TableBody, 
  TableHead, 
  TableRow, 
  TableCell 
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { SSLData } from '@/lib/mock-data'
import { cn } from '@/lib/utils'

interface SSLTableProps {
  ssl: SSLData[]
  searchQuery: string
}

const getExpiryStatus = (daysLeft: number) => {
  if (daysLeft <= 7) return { status: 'critical', label: 'Critical', color: 'text-destructive', bg: 'bg-destructive/10' }
  if (daysLeft <= 30) return { status: 'warning', label: 'Expiring Soon', color: 'text-warning', bg: 'bg-warning/10' }
  if (daysLeft <= 90) return { status: 'attention', label: 'Monitor', color: 'text-warning', bg: 'bg-warning/10' }
  return { status: 'valid', label: 'Valid', color: 'text-success', bg: 'bg-success/10' }
}

export function SSLTable({ ssl, searchQuery }: SSLTableProps) {
  const filteredSSL = ssl.filter(cert => 
    cert.cert_path.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cert.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cert.issuer.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const sortedSSL = [...filteredSSL].sort((a, b) => a.days_left - b.days_left)

  const stats = useMemo(() => {
    const critical = ssl.filter(c => c.days_left <= 7).length
    const warning = ssl.filter(c => c.days_left > 7 && c.days_left <= 30).length
    const valid = ssl.filter(c => c.days_left > 30).length
    return { critical, warning, valid, total: ssl.length }
  }, [ssl])

  return (
    <div className="space-y-4">
      {/* Status Summary */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-card border border-border rounded-lg p-4 flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
            <ShieldCheck className="h-5 w-5 text-muted-foreground" />
          </div>
          <div>
            <p className="text-2xl font-semibold">{stats.total}</p>
            <p className="text-xs text-muted-foreground">Total Certificates</p>
          </div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-success/10 flex items-center justify-center">
            <CheckCircle className="h-5 w-5 text-success" />
          </div>
          <div>
            <p className="text-2xl font-semibold text-success">{stats.valid}</p>
            <p className="text-xs text-muted-foreground">Valid ({'>'}30 days)</p>
          </div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-warning/10 flex items-center justify-center">
            <Clock className="h-5 w-5 text-warning" />
          </div>
          <div>
            <p className="text-2xl font-semibold text-warning">{stats.warning}</p>
            <p className="text-xs text-muted-foreground">Expiring ({'<'}30 days)</p>
          </div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-destructive/10 flex items-center justify-center">
            <AlertTriangle className="h-5 w-5 text-destructive" />
          </div>
          <div>
            <p className="text-2xl font-semibold text-destructive">{stats.critical}</p>
            <p className="text-xs text-muted-foreground">Critical ({'<'}7 days)</p>
          </div>
        </div>
      </div>

      {/* Expiring Soon Alert */}
      {stats.critical > 0 && (
        <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-4 flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-destructive mt-0.5" />
          <div>
            <p className="font-medium text-destructive">Certificate Expiry Alert</p>
            <p className="text-sm text-destructive/80">
              {stats.critical} certificate{stats.critical > 1 ? 's' : ''} will expire within 7 days. 
              Immediate renewal is required to prevent service disruption.
            </p>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-border flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-primary" />
          <h3 className="font-medium text-sm">SSL Certificates</h3>
          <Badge variant="secondary" className="ml-auto">{filteredSSL.length} certificates</Badge>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-[100px]">Status</TableHead>
                <TableHead className="w-[250px]">Certificate</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead>Issuer</TableHead>
                <TableHead>Expires</TableHead>
                <TableHead className="text-center">Days Left</TableHead>
                <TableHead>TLS</TableHead>
                <TableHead className="text-center">HSTS</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedSSL.map((cert) => {
                const expiryStatus = getExpiryStatus(cert.days_left)
                
                return (
                  <TableRow key={cert.id} className="group">
                    <TableCell>
                      <Badge 
                        variant="outline" 
                        className={cn(
                          "text-xs",
                          expiryStatus.status === 'critical' && "border-destructive/50 text-destructive bg-destructive/5",
                          expiryStatus.status === 'warning' && "border-warning/50 text-warning bg-warning/5",
                          expiryStatus.status === 'attention' && "border-warning/30 text-warning bg-warning/5",
                          expiryStatus.status === 'valid' && "border-success/50 text-success bg-success/5",
                        )}
                      >
                        {expiryStatus.label}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground truncate max-w-[250px]">
                      {cert.cert_path}
                    </TableCell>
                    <TableCell className="text-sm">
                      {cert.subject.replace('CN=', '')}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground truncate max-w-[200px]">
                      {cert.issuer.replace('CN=', '')}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {cert.expires}
                    </TableCell>
                    <TableCell className="text-center">
                      <span className={cn(
                        "font-mono font-semibold",
                        expiryStatus.color
                      )}>
                        {cert.days_left}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="font-mono text-xs">
                        {cert.tls_protocols}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      {cert.hsts_enabled ? (
                        <Shield className="h-4 w-4 text-success mx-auto" />
                      ) : (
                        <span className="text-xs text-muted-foreground">-</span>
                      )}
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  )
}
