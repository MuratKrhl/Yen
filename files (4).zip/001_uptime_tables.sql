-- SQL Server migration: Uptime izleme tabloları
-- backend-nestjs/data/ klasörüne ekleyin

CREATE TABLE monitored_urls (
  id             INT IDENTITY(1,1) PRIMARY KEY,
  label          NVARCHAR(200)    NOT NULL,
  url            NVARCHAR(2048)   NOT NULL,
  interval_secs  INT              NOT NULL DEFAULT 60,   -- kontrol aralığı (saniye)
  timeout_ms     INT              NOT NULL DEFAULT 5000, -- HTTP timeout
  is_active      BIT              NOT NULL DEFAULT 1,
  created_at     DATETIME2        NOT NULL DEFAULT GETDATE()
);

CREATE TABLE uptime_checks (
  id             INT IDENTITY(1,1) PRIMARY KEY,
  url_id         INT              NOT NULL REFERENCES monitored_urls(id),
  checked_at     DATETIME2        NOT NULL DEFAULT GETDATE(),
  status_code    SMALLINT         NULL,
  latency_ms     INT              NULL,
  is_up          BIT              NOT NULL DEFAULT 0,
  error_message  NVARCHAR(1000)   NULL,
  dns_resolved   BIT              NOT NULL DEFAULT 0
);

-- Sık sorgulanan alanlar için index
CREATE INDEX IX_uptime_checks_url_id_checked_at
  ON uptime_checks (url_id, checked_at DESC);

-- Son 30 günlük uptime hesabı için view
CREATE VIEW v_uptime_summary AS
SELECT
  u.id,
  u.label,
  u.url,
  u.interval_secs,
  COUNT(c.id)                                         AS total_checks,
  SUM(CAST(c.is_up AS INT))                           AS up_checks,
  CAST(
    100.0 * SUM(CAST(c.is_up AS INT)) / NULLIF(COUNT(c.id), 0)
  AS DECIMAL(5,2))                                    AS uptime_pct,
  AVG(CAST(c.latency_ms AS FLOAT))                    AS avg_latency_ms,
  MAX(c.checked_at)                                   AS last_checked_at
FROM monitored_urls u
LEFT JOIN uptime_checks c
  ON c.url_id = u.id
  AND c.checked_at >= DATEADD(DAY, -30, GETDATE())
WHERE u.is_active = 1
GROUP BY u.id, u.label, u.url, u.interval_secs;
