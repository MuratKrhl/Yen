export interface Instance {
  id: string;
  name: string;
  state: 'Running' | 'Stopped' | 'Pending' | 'Terminated';
  type: string;
  statusCheck: string;
  alarmState: string;
  az: string;
}

export interface NetworkInterface {
  id: string;
  name: string;
  subnetId: string;
  vpcId: string;
  az: string;
  securityGroups: string[];
  status: 'In-use' | 'Available';
  interfaceType: string;
  description: string;
}
