import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  Activity,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Clock,
  ShieldAlert,
  Globe2,
  RefreshCw,
  Play,
  Terminal,
  Search,
  Plus,
  Trash2,
  Cpu,
  Server,
  ChevronRight,
  Wifi,
  Lock,
  Unlock,
  Layers,
  Database,
  ArrowLeft,
  Settings,
  HelpCircle,
  Eye,
  FileCheck,
  Zap
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from "recharts";
import { Target, CheckResult, Incident, TargetStats, SSLStatus, DNSStatus, AnsibleSimulationLogs } from "./types";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  // State definitions
  const [targets, setTargets] = useState<Target[]>([]);
  const [selectedTargetId, setSelectedTargetId] = useState<string | null>(null);
  const [globalStats, setGlobalStats] = useState({
    total: 0,
    up: 0,
    down: 0,
    avgResponse: 0,
    sslExpiringCount: 0,
    avgPacketLoss: 0,
    aggregateSLA: 100,
    activeIncidentsCount: 0
  });
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [activeCheckHistory, setActiveCheckHistory] = useState<CheckResult[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"ALL" | "UP" | "DOWN" | "DISABLED">("ALL");

  // Form State for Adding Target
  const [isAddingTarget, setIsAddingTarget] = useState(false);
  const [newTarget, setNewTarget] = useState({
    name: "",
    url: "",
    type: "HTTPS" as Target["type"],
    interval: 15,
    keyword: "",
    port: ""
  });
  const [addError, setAddError] = useState("");

  // Ansible Simulation State
  const [ansiblePlaybooks, setAnsiblePlaybooks] = useState<AnsibleSimulationLogs[]>([]);
  const [selectedPlaybook, setSelectedPlaybook] = useState("deploy-sentinel-collector.yml");
  const [ansibleTargetId, setAnsibleTargetId] = useState("");
  const [isDeployingAnsible, setIsDeployingAnsible] = useState(false);
  const [currentAnsibleLogs, setCurrentAnsibleLogs] = useState<string[]>([]);
  const [ansibleLogsTerminal, setAnsibleLogsTerminal] = useState<string[]>([]);
  const terminalBottomRef = useRef<HTMLDivElement>(null);

  // Playground test tool State
  const [playgroundUrl, setPlaygroundUrl] = useState("https://dns.google");
  const [playgroundKeyword, setPlaygroundKeyword] = useState("");
  const [isTestingPlayground, setIsTestingPlayground] = useState(false);
  const [playgroundResult, setPlaygroundResult] = useState<CheckResult | null>(null);
  const [playgroundError, setPlaygroundError] = useState("");
  const [jsonFolded, setJsonFolded] = useState(false);

  // Poll intervals
  useEffect(() => {
    fetchInitialData();
    const interval = setInterval(() => {
      fetchDataSilent();
    }, 10000); // Silent refresh every 10 seconds
    return () => clearInterval(interval);
  }, []);

  // Fetch target history when selected target changes
  useEffect(() => {
    if (selectedTargetId) {
      fetchTargetHistory(selectedTargetId);
    }
  }, [selectedTargetId]);

  // Handle Ansible logs automatic scroll to bottom
  useEffect(() => {
    if (terminalBottomRef.current) {
      terminalBottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [ansibleLogsTerminal]);

  const fetchInitialData = async () => {
    setIsRefreshing(true);
    try {
      const [targetsRes, statsRes, incidentsRes, ansibleRes] = await Promise.all([
        fetch("/api/targets"),
        fetch("/api/dashboard/stats"),
        fetch("/api/incidents"),
        fetch("/api/tools/ansible/logs")
      ]);

      const targetsData = await targetsRes.json();
      const statsData = await statsRes.json();
      const incidentsData = await incidentsRes.json();
      const ansibleData = await ansibleRes.json();

      setTargets(targetsData);
      setGlobalStats(statsData);
      setIncidents(incidentsData);
      setAnsiblePlaybooks(ansibleData);
                      
      if (targetsData.length > 0 && !selectedTargetId) {
        // select first for detail list initialization
        setSelectedTargetId(targetsData[0].id);
      }
    } catch (e) {
      console.error("Error loading system metrics:", e);
    } finally {
      setIsRefreshing(false);
    }
  };

  const fetchDataSilent = async () => {
    try {
      const [targetsRes, statsRes, incidentsRes] = await Promise.all([
        fetch("/api/targets"),
        fetch("/api/dashboard/stats"),
        fetch("/api/incidents")
      ]);

      const targetsData = await targetsRes.json();
      const statsData = await statsRes.json();
      const incidentsData = await incidentsRes.json();

      setTargets(targetsData);
      setGlobalStats(statsData);
      setIncidents(incidentsData);

      // If active target is selected, reload history in place
      if (selectedTargetId) {
        const histRes = await fetch(`/api/targets/${selectedTargetId}/history`);
        const histData = await histRes.json();
        setActiveCheckHistory(histData);
      }
    } catch (e) {
      console.warn("Silent statistics collection aborted:", e);
    }
  };

  const fetchTargetHistory = async (id: string) => {
    try {
      const res = await fetch(`/api/targets/${id}/history`);
      const data = await res.json();
      setActiveCheckHistory(data);
    } catch (e) {
      console.error("Failed to recover target history:", e);
    }
  };

  const handleManualCheckTrigger = async (id: string) => {
    setIsRefreshing(true);
    try {
      const res = await fetch(`/api/targets/${id}/check`, { method: "POST" });
      const currentResult = await res.json();
      
      // Update local states immediately
      await fetchTargetHistory(id);
      
      // Flash reload statistics cards
      const statsRes = await fetch("/api/dashboard/stats");
      const statsData = await statsRes.json();
      setGlobalStats(statsData);
    } catch (e) {
      alert("Error sending manual check directive.");
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleCreateTarget = async (e: React.FormEvent) => {
    e.preventDefault();
    setAddError("");
    
    if (!newTarget.name || !newTarget.url) {
      setAddError("Lütfen hedef adı ve adres alanlarını doldurunuz.");
      return;
    }

    try {
      const response = await fetch("/api/targets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newTarget)
      });

      if (!response.ok) {
        throw new Error("Target could not be saved.");
      }

      const created = await response.json();
      setTargets(prev => [...prev, created]);
      setSelectedTargetId(created.id);
      
      // Reset form controls
      setNewTarget({
        name: "",
        url: "",
        type: "HTTPS",
        interval: 15,
        keyword: "",
        port: ""
      });
      setIsAddingTarget(false);
      
      // Refresh stats
      setTimeout(() => {
        fetchDataSilent();
      }, 1000);
    } catch (err: any) {
      setAddError(err.message || "Bilinmeyen bir iletişim hatası oluştu.");
    }
  };

  const handleDeleteTarget = async (id: string) => {
    if (!confirm("Bu izleme hedefini tamamen kaldırmak istediğinizden emin misiniz?")) return;
    
    try {
      const response = await fetch(`/api/targets/${id}`, { method: "DELETE" });
      if (response.ok) {
        setTargets(prev => prev.filter(t => t.id !== id));
        if (selectedTargetId === id) {
          const remaining = targets.filter(t => t.id !== id);
          setSelectedTargetId(remaining.length > 0 ? remaining[0].id : null);
        }
        fetchDataSilent();
      }
    } catch (e) {
      alert("İzleme hedefi silinirken sorun oluştu.");
    }
  };

  const handleToggleTargetEnabled = async (target: Target) => {
    const updatedStatus = !target.enabled;
    try {
      const response = await fetch(`/api/targets/${target.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled: updatedStatus })
      });
      if (response.ok) {
        setTargets(prev => prev.map(t => t.id === target.id ? { ...t, enabled: updatedStatus } : t));
        fetchDataSilent();
      }
    } catch (e) {
      alert("Hedep durumu güncellenemedi.");
    }
  };

  const handleRunAnsiblePlaybook = async () => {
    if (isDeployingAnsible) return;
    
    const target = targets.find(t => t.id === (ansibleTargetId || selectedTargetId));
    if (!target) {
      alert("Lütfen geçerli bir Ansible hedef istasyonu seçin.");
      return;
    }

    setIsDeployingAnsible(true);
    setAnsibleLogsTerminal([]);
    
    try {
      const response = await fetch("/api/tools/ansible", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetName: target.name,
          playbookType: selectedPlaybook
        })
      });
      
      const sessionResult = await response.json();
      const logsToPrint = sessionResult.logs || [];
      
      // Process printing line by line with a smooth hacker-terminal animation
      let index = 0;
      const interval = setInterval(() => {
        if (index < logsToPrint.length) {
          setAnsibleLogsTerminal(prev => [...prev, logsToPrint[index]]);
          index++;
        } else {
          clearInterval(interval);
          setIsDeployingAnsible(false);
          // Refetch log lists
          fetch("/api/tools/ansible/logs")
            .then(res => res.json())
            .then(data => setAnsiblePlaybooks(data));
        }
      }, 180);

    } catch (e) {
      setAnsibleLogsTerminal(prev => [...prev, "fatal: [System Orchestration Engine] => Connection refused. Ansible node pipeline crash."]);
      setIsDeployingAnsible(false);
    }
  };

  const handleTestPlaygroundUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!playgroundUrl) return;

    setIsTestingPlayground(true);
    setPlaygroundError("");
    setPlaygroundResult(null);

    try {
      const res = await fetch("/api/tools/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: playgroundUrl, keyword: playgroundKeyword })
      });

      if (!res.ok) {
        throw new Error("Sistem cURL bağlantısı başarısız oldu.");
      }

      const parsed = await res.json();
      setPlaygroundResult(parsed);
    } catch (err: any) {
      setPlaygroundError(err.message || "Bağlantı hatası");
    } finally {
      setIsTestingPlayground(false);
    }
  };

  // Compute calculated metrics for active historical selection
  const activeTargetFullDetails = useMemo(() => {
    const target = targets.find(t => t.id === selectedTargetId);
    if (!target) return null;

    const history = activeCheckHistory;
    const totalChecksCount = history.length;
    if (totalChecksCount === 0) {
      return {
        target,
        uptimePercentage: 100,
        avgResponse: 0,
        lastResult: null,
        dnsRecord: null,
        sslRecord: null,
        headers: null,
        p50: 0, p95: 0, p99: 0
      };
    }

    const upChecksCount = history.filter(c => c.status === "UP").length;
    const uptimePercentage = parseFloat(((upChecksCount / totalChecksCount) * 100).toFixed(2));
    
    const validTimings = history.filter(c => c.status === "UP" && c.total_ms > 0).map(c => c.total_ms);
    const avgResponse = validTimings.length > 0 
      ? Math.round(validTimings.reduce((sum, val) => sum + val, 0) / validTimings.length)
      : 0;

    // Calculate percentiles
    const sortedTimings = [...validTimings].sort((a, b) => a - b);
    const getPercentile = (p: number) => {
      if (sortedTimings.length === 0) return 0;
      const idx = Math.ceil((p / 100) * sortedTimings.length) - 1;
      return sortedTimings[Math.max(0, idx)];
    };

    const lastResult = history[history.length - 1];

    return {
      target,
      uptimePercentage,
      avgResponse,
      lastResult,
      dnsRecord: lastResult?.dns,
      sslRecord: lastResult?.ssl,
      headers: lastResult?.headers,
      p50: getPercentile(50),
      p95: getPercentile(95),
      p99: getPercentile(99)
    };
  }, [selectedTargetId, activeCheckHistory, targets]);

  // Quick lookup cache for fast list rendering
  const checkResultsCache = useMemo(() => {
    const cache: Record<string, CheckResult[]> = {};
    // Fallback: Use active history to populate cache so the user sees matching metrics instantly in sidebar
    if (selectedTargetId && activeCheckHistory.length > 0) {
      cache[selectedTargetId] = activeCheckHistory;
    }
    
    // Fallback initial values if not loaded
    targets.forEach(t => {
      if (!cache[t.id]) {
        // Mock fallback or local simulation
        cache[t.id] = t.id === "failing-service" 
          ? [{ status: "DOWN", total_ms: 0 } as any] 
          : [{ status: "UP", total_ms: 45 } as any];
      }
    });

    return cache;
  }, [targets, selectedTargetId, activeCheckHistory]);

  // Filtered target list computing
  const filteredTargets = useMemo(() => {
    return targets.filter(t => {
      const matchSearch = t.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          t.url.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          t.type.toLowerCase().includes(searchQuery.toLowerCase());
      
      const history = checkResultsCache[t.id] || [];
      const isUp = history.length > 0 && history[history.length - 1].status === "UP";
      const isDown = history.length > 0 && history[history.length - 1].status === "DOWN";
      
      if (statusFilter === "ALL") return matchSearch;
      if (statusFilter === "UP") return matchSearch && isUp && t.enabled;
      if (statusFilter === "DOWN") return matchSearch && isDown && t.enabled;
      if (statusFilter === "DISABLED") return matchSearch && !t.enabled;
      return matchSearch;
    });
  }, [targets, searchQuery, statusFilter, checkResultsCache]);

  return (
    <div className="min-h-screen bg-[#070b14] text-gray-100 flex flex-col font-sans selection:bg-[#3b82f6]/30 selection:text-blue-200">
      
      {/* HEADER BAR */}
      <header className="border-b border-[#141b2e] bg-[#090e1a]/90 backdrop-blur-md sticky top-0 z-40 px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 p-2.5 rounded-xl shadow-lg shadow-indigo-900/40 relative">
            <Activity className="h-6 w-6 text-white animate-pulse" />
            <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500"></span>
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-display font-black text-xl tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-300">
                SENTINEL
              </h1>
              <span className="text-[10px] bg-indigo-950 text-indigo-400 border border-indigo-900 font-mono px-2 py-0.5 rounded uppercase">
                v2.1 Observability
              </span>
            </div>
            <p className="text-xs text-gray-400 font-mono mt-0.5">Dinamik Uptime & Ağ Sağlığı Gözetim Platformu</p>
          </div>
        </div>

        <div className="flex items-center gap-3 self-end md:self-auto">
          <div className="hidden lg:flex items-center gap-2 text-xs bg-[#0f162a] border border-[#1d2745] px-3 & py-1.5 rounded-lg text-gray-300 font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
            <span>Uptime Kuma & Nagios Hibrit Katmanı</span>
          </div>
          
          <button
            onClick={fetchInitialData}
            disabled={isRefreshing}
            className={`cursor-pointer px-4 py-2 text-xs font-medium rounded-lg border bg-[#0d1326] border-[#1d2745] hover:border-blue-500 flex items-center gap-2 transition duration-200 text-gray-300 hover:text-white ${isRefreshing ? "opacity-50 cursor-not-allowed" : ""}`}
            id="btn-global-refresh"
          >
            <RefreshCw className={`h-3 w-3 ${isRefreshing ? "animate-spin" : ""}`} />
            <span>Milli Saniyede Yenile</span>
          </button>
        </div>
      </header>

      {/* GLOBAL STATS ROW */}
      <section className="bg-[#0b101f] border-b border-[#141b2e] px-6 py-6 grid grid-cols-2 lg:grid-cols-5 gap-4">
        
        {/* STAT 1: UPTIME BLOCK */}
        <div className="bg-[#0f162a]/60 border border-[#121a30] p-4 rounded-xl flex items-center justify-between shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-blue-500 to-indigo-600"></div>
          <div>
            <div className="flex items-center gap-1.5 text-xs font-medium text-gray-400 uppercase tracking-wider font-mono">
              <Globe2 className="w-3.5 h-3.5 text-blue-400" />
              <span>UYUM SLA (%)</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-2xl font-black font-display text-blue-400 tracking-tight">
                {globalStats.aggregateSLA}%
              </span>
            </div>
            <p className="text-[10px] text-gray-500 mt-1">Son 24 Saati Kapsayan Ortalama</p>
          </div>
          <div className="p-3 bg-blue-950/40 rounded-lg group-hover:scale-110 transition-transform duration-200">
            <CheckCircle2 className="h-6 w-6 text-blue-500" />
          </div>
        </div>

        {/* STAT 2: TOTAL RESP TIMES */}
        <div className="bg-[#0f162a]/60 border border-[#121a30] p-4 rounded-xl flex items-center justify-between shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-teal-500 to-emerald-600"></div>
          <div>
            <div className="flex items-center gap-1.5 text-xs font-medium text-gray-400 uppercase tracking-wider font-mono">
              <Clock className="w-3.5 h-3.5 text-teal-400" />
              <span>GEÇİŞ ORT.</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-2xl font-black font-display text-teal-400 tracking-tight">
                {globalStats.avgResponse} ms
              </span>
            </div>
            <p className="text-[10px] text-gray-500 mt-1">Servis Ağ Geçitleri Latency</p>
          </div>
          <div className="p-3 bg-teal-950/40 rounded-lg group-hover:scale-110 transition-transform duration-200">
            <Zap className="h-6 w-6 text-teal-500" />
          </div>
        </div>

        {/* STAT 3: ACTIVE ALERTS */}
        <div className="bg-[#0f162a]/60 border border-[#121a30] p-4 rounded-xl flex items-center justify-between shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1 h-full bg-[#ef4444]"></div>
          <div>
            <div className="flex items-center gap-1.5 text-xs font-medium text-gray-400 uppercase tracking-wider font-mono">
              <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
              <span>ALARM DURUMU</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className={`text-2xl font-black font-display tracking-tight ${globalStats.activeIncidentsCount > 0 ? "text-red-400 animate-pulse" : "text-gray-400"}`}>
                {globalStats.activeIncidentsCount} AKTİF
              </span>
            </div>
            <p className="text-[10px] text-gray-500 mt-1">Dış Servis Kesinti Bildirimleri</p>
          </div>
          <div className={`p-3 rounded-lg group-hover:scale-110 transition-transform duration-200 ${globalStats.activeIncidentsCount > 0 ? "bg-red-950/50" : "bg-gray-950/30"}`}>
            <AlertTriangle className={`h-6 w-6 ${globalStats.activeIncidentsCount > 0 ? "text-red-500" : "text-gray-500"}`} />
          </div>
        </div>

        {/* STAT 4: SSL EXPIRED WARN */}
        <div className="bg-[#0f162a]/60 border border-[#121a30] p-4 rounded-xl flex items-center justify-between shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1 h-full bg-amber-500"></div>
          <div>
            <div className="flex items-center gap-1.5 text-xs font-medium text-gray-400 uppercase tracking-wider font-mono">
              <Layers className="w-3.5 h-3.5 text-amber-400" />
              <span>SSL KRİTİK</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-2xl font-black font-display text-amber-400 tracking-tight">
                {globalStats.sslExpiringCount} SERTİFİKA
              </span>
            </div>
            <p className="text-[10px] text-gray-500 mt-1">Yenilenmesi Gereken (&lt;15 Gç)</p>
          </div>
          <div className="p-3 bg-amber-950/40 rounded-lg group-hover:scale-110 transition-transform duration-200">
            <Lock className="h-6 w-6 text-amber-500" />
          </div>
        </div>

        {/* STAT 5: PACKET LOSS */}
        <div className="col-span-2 lg:col-span-1 bg-[#0f162a]/60 border border-[#121a30] p-4 rounded-xl flex items-center justify-between shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1 h-full bg-purple-500"></div>
          <div>
            <div className="flex items-center gap-1.5 text-xs font-medium text-gray-400 uppercase tracking-wider font-mono">
              <Wifi className="w-3.5 h-3.5 text-purple-400" />
              <span>PAKET KAYBI</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-2xl font-black font-display text-purple-400 tracking-tight">
                %{globalStats.avgPacketLoss}
              </span>
            </div>
            <p className="text-[10px] text-gray-500 mt-1">ICMP Ping Yanıt Tutarlılığı</p>
          </div>
          <div className="p-3 bg-purple-950/40 rounded-lg group-hover:scale-110 transition-transform duration-200">
            <Database className="h-6 w-6 text-purple-500" />
          </div>
        </div>

      </section>

      {/* MAIN TWO-COLUMN DASHBOARD */}
      <main className="flex-1 grid grid-cols-1 xl:grid-cols-12 overflow-hidden">
        
        {/* LEFT SIDEBAR: TARGETS PANEL - 4 cols */}
        <aside className="xl:col-span-4 border-r border-[#141b2e] bg-[#080d19]/80 flex flex-col h-full min-h-[400px] xl:min-h-0">
          
          {/* SEARCH & FILTERS CONTROLS */}
          <div className="p-4 border-b border-[#141b2e] space-y-3 bg-[#0a0f20]/60">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-semibold uppercase font-mono tracking-wider text-gray-400 flex items-center gap-2">
                <Server className="w-3.5 h-3.5 text-blue-500" />
                <span>MONİTÖR EDİLEN SİSTEMLER ({filteredTargets.length})</span>
              </h2>
              
              <button
                onClick={() => setIsAddingTarget(true)}
                className="cursor-pointer text-xs bg-blue-600 hover:bg-blue-500 text-white font-medium px-2 py-1 rounded flex items-center gap-1 transition duration-150"
                id="btn-add-target-modal"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Ekle</span>
              </button>
            </div>

            {/* Keyword Search */}
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
              <input
                type="text"
                placeholder="Adres, isim veya protokol ara..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#0d1222] border border-[#1b253f] rounded-lg pl-9 pr-4 py-2 text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/20 transition-all font-mono"
              />
            </div>

            {/* Target Filter Badges */}
            <div className="flex gap-1.5 flex-wrap">
              {(["ALL", "UP", "DOWN", "DISABLED"] as const).map((filter) => {
                const colors = {
                  ALL: "bg-[#0f162c] text-gray-300 hover:bg-[#1a2444] border-gray-800",
                  UP: "bg-emerald-950/40 text-emerald-400 hover:bg-emerald-950/60 border-emerald-900/40",
                  DOWN: "bg-red-950/40 text-red-400 hover:bg-red-950/60 border-red-900/40",
                  DISABLED: "bg-gray-900 text-gray-400 hover:bg-gray-800 border-gray-800"
                };
                const labels = {
                  ALL: "Tümü",
                  UP: "Çevrimiçi",
                  DOWN: "Çevrimdışı",
                  DISABLED: "Devre dışı"
                };

                return (
                  <button
                    key={filter}
                    onClick={() => setStatusFilter(filter)}
                    className={`cursor-pointer text-[10px] uppercase font-semibold px-2 py-1 rounded border transition-all duration-150 ${statusFilter === filter ? "ring-2 ring-blue-500/40 bg-blue-900/30 text-blue-200 border-blue-500/60" : colors[filter]}`}
                  >
                    {labels[filter]}
                  </button>
                );
              })}
            </div>
          </div>

          {/* TARGETS SCROLL LIST */}
          <div className="flex-1 overflow-y-auto divide-y divide-[#131b2e] custom-scroll-panel">
            {filteredTargets.length === 0 ? (
              <div className="p-8 text-center text-gray-500 space-y-2">
                <HelpCircle className="w-8 h-8 mx-auto text-gray-600 animate-pulse" />
                <p className="text-xs font-mono">Aranan kriterlerde izleme hedefi bulunamadı.</p>
              </div>
            ) : (
              filteredTargets.map((target) => {
                const history = checkResultsCache[target.id] || [];
                const lastCheck = history[history.length - 1];
                const isSelected = target.id === selectedTargetId;
                const isDown = lastCheck?.status === "DOWN" || target.id === "failing-service";
                const isEnabled = target.enabled;
                
                return (
                  <div
                    key={target.id}
                    onClick={() => setSelectedTargetId(target.id)}
                    className={`cursor-pointer p-4 flex items-center justify-between gap-3 transition-all relative ${isSelected ? "bg-[#111931]/70 border-l-4 border-blue-500" : "hover:bg-[#0c1224] border-l-4 border-transparent"}`}
                    id={`target-card-${target.id}`}
                  >
                    
                    {/* LHS Indicator & Info */}
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      {/* Active colored node light */}
                      <div className="mt-1 flex-shrink-0">
                        {!isEnabled ? (
                          <div className="w-3 h-3 rounded-full bg-gray-600 border-2 border-[#070b14]" />
                        ) : isDown ? (
                          <div className="w-3 h-3 rounded-full bg-red-500 border-2 border-[#070b14] shadow-[0_0_10px_rgba(239,68,68,0.7)] animate-pulse" />
                        ) : (
                          <span className="relative flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                          </span>
                        )}
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-mono tracking-wider font-semibold text-gray-500 bg-[#0e162d] border border-[#1b253c] px-1.5 py-0.2 rounded">
                            {target.type}
                          </span>
                          <h3 className="text-xs font-semibold text-gray-200 truncate group-hover:text-white">
                            {target.name}
                          </h3>
                        </div>

                        <p className="text-[10px] text-gray-400 font-mono truncate mt-1">
                          {target.url}
                        </p>

                        <div className="flex items-center gap-2 mt-2">
                          <span className="text-[10px] text-gray-500 font-mono flex items-center gap-0.5">
                            <Clock className="w-3 h-3" />
                            {target.interval}sn Ara
                          </span>
                          
                          {lastCheck?.total_ms !== undefined && isEnabled && !isDown && (
                            <span className="text-[10px] text-emerald-400 bg-emerald-950/30 border border-emerald-900/30 px-1 rounded font-mono">
                              {lastCheck.total_ms}ms
                            </span>
                          )}

                          {!isEnabled && (
                            <span className="text-[10px] text-gray-500 bg-gray-950 border border-gray-800 px-1 rounded font-mono">
                              Pasif
                            </span>
                          )}

                          {isDown && isEnabled && (
                            <span className="text-[10px] text-red-400 bg-red-950/20 border border-red-900/40 px-1 rounded font-mono">
                              Çevrimdışı
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* RHS Status summary and selector icon */}
                    <div className="flex flex-col items-end gap-2 shrink-0">
                      <div className="flex gap-1">
                        <button
                          title={isEnabled ? "Devre Dışı Bırak" : "Aktif Et"}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleToggleTargetEnabled(target);
                          }}
                          className="cursor-pointer p-1 rounded hover:bg-slate-800 text-gray-400 hover:text-white"
                        >
                          {isEnabled ? <Unlock className="w-3 h-3 text-emerald-400" /> : <Lock className="w-3 h-3 text-gray-500" />}
                        </button>
                        <button
                          title="Sil"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteTarget(target.id);
                          }}
                          className="cursor-pointer p-1 rounded hover:bg-red-950/30 text-gray-500 hover:text-red-400"
                          id={`delete-btn-${target.id}`}
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                      
                      <ChevronRight className="w-4 h-4 text-gray-600" />
                    </div>

                  </div>
                );
              })
            )}
          </div>

          {/* ACTIVE DISASTER RECONSTRUCTION PANEL */}
          <div className="p-4 border-t border-[#141b2e] bg-[#090d18] mt-auto">
            <h3 className="text-xs font-semibold text-gray-400 mb-2 uppercase font-mono tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded bg-red-500 inline-block animate-pulse"></span>
              Aktif Hatalar & Alarmlar ({incidents.filter(i => i.status === "ACTIVE").length})
            </h3>
            <div className="max-h-[140px] overflow-y-auto space-y-2 text-[11px] custom-scroll-panel">
              {incidents.filter(i => i.status === "ACTIVE").length === 0 ? (
                <p className="text-gray-500 font-mono italic">Kayıtlı kritik arıza bulunmuyor. Sistem kararlı.</p>
              ) : (
                incidents.filter(i => i.status === "ACTIVE").map((inc, index) => (
                  <div key={`inc-${inc.id || index}`} className="bg-red-950/10 border border-red-900/30 p-2 rounded relative">
                    <span className="text-[9px] bg-red-950 text-red-400 px-1 rounded absolute top-2 right-2">CRITICAL</span>
                    <h4 className="font-bold text-red-300 truncate pr-16">{inc.targetName}</h4>
                    <p className="text-gray-400 text-[10px] mt-1 font-mono">{inc.message}</p>
                    <span className="text-[9px] text-gray-500 block mt-1 font-mono">Started: {new Date(inc.startedAt).toLocaleTimeString()}</span>
                  </div>
                ))
              )}
            </div>
          </div>

        </aside>

        {/* RIGHT ZONE: DETAILS AND ANALYTICS ENGINE - 8 cols */}
        <section className="xl:col-span-8 bg-[#070b13] flex flex-col overflow-y-auto p-6 space-y-6 custom-scroll-panel">
          
          <AnimatePresence mode="wait">
            
            {/* 1. STATE: ADD MONITORED DOMAIN FORM OVERLAY */}
            {isAddingTarget && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-[#0b1022] border border-blue-900/40 p-6 rounded-2xl shadow-xl shadow-black/80 space-y-4"
              >
                <div className="flex items-center justify-between border-b border-[#1c2742] pb-3">
                  <div className="flex items-center gap-2">
                    <Plus className="w-5 h-5 text-blue-400" />
                    <h2 className="font-semibold text-base text-gray-100">Yeni Gözetim Hedefi Kaydet</h2>
                  </div>
                  <button
                    onClick={() => setIsAddingTarget(false)}
                    className="cursor-pointer text-xs text-gray-400 hover:text-white px-2 py-1 rounded bg-[#101730] border border-[#1b253b]"
                  >
                    İptal Et
                  </button>
                </div>

                {addError && (
                  <div className="bg-red-950/30 border border-red-900/60 p-3 rounded-lg text-xs text-red-300 font-mono">
                    {addError}
                  </div>
                )}

                <form onSubmit={handleCreateTarget} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-mono text-gray-400 block font-semibold">Hedef Sunucu Adı</label>
                    <input
                      type="text"
                      placeholder="My Web Gateway, Cloud DNS, Database Server"
                      value={newTarget.name}
                      onChange={(e) => setNewTarget(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full bg-[#0d1222] border border-[#1c2847] rounded-lg px-3 py-2 text-xs text-gray-200 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-mono text-gray-400 block font-semibold">İzleme Protokolü / İstek Türü</label>
                    <select
                      value={newTarget.type}
                      onChange={(e) => setNewTarget(prev => ({ ...prev, type: e.target.value as Target["type"] }))}
                      className="w-full bg-[#0d1222] border border-[#1c2847] rounded-lg px-3 py-2 text-xs text-gray-200 focus:outline-none focus:border-blue-500"
                    >
                      <option value="HTTPS">HTTPS (Yüksek Seviye SSL/Header Analiz)</option>
                      <option value="HTTP">HTTP (Standart Port Monitor)</option>
                      <option value="PING">PING (ICMP Düşük Seviye Paket Gecikmesi)</option>
                      <option value="DNS">DNS (dig tabanlı Çözümleme Hızı)</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-mono text-gray-400 block font-semibold">Hedef Adres / IP Koordinatı</label>
                    <input
                      type="text"
                      placeholder="https://google.com veya 1.1.1.1"
                      value={newTarget.url}
                      onChange={(e) => setNewTarget(prev => ({ ...prev, url: e.target.value }))}
                      className="w-full bg-[#0d1222] border border-[#1c2847] rounded-lg px-3 py-2 text-xs text-gray-200 focus:outline-none focus:border-blue-500 font-mono"
                    />
                    <span className="text-[10px] text-gray-500 block">HTTP/HTTPS protokolleri için prefix (http/https://) gereklidir.</span>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <label className="text-xs font-mono text-gray-400 block font-semibold">Port (Opsiyonel)</label>
                      <input
                        type="number"
                        placeholder="443"
                        value={newTarget.port}
                        onChange={(e) => setNewTarget(prev => ({ ...prev, port: e.target.value }))}
                        className="w-full bg-[#0d1222] border border-[#1c2847] rounded-lg px-3 py-2 text-xs text-gray-200 focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-mono text-gray-400 block font-semibold">Aralık (Saniye)</label>
                      <input
                        type="number"
                        placeholder="15"
                        value={newTarget.interval}
                        onChange={(e) => setNewTarget(prev => ({ ...prev, interval: parseInt(e.target.value) || 15 }))}
                        className="w-full bg-[#0d1222] border border-[#1c2847] rounded-lg px-3 py-2 text-xs text-gray-200 focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div className="space-y-2 col-span-1 md:col-span-2">
                    <label className="text-xs font-mono text-gray-400 block font-semibold">İçerik Doğrulama Kelimesi (Opsiyonel)</label>
                    <input
                      type="text"
                      placeholder="Sayfa gövdesinde (body) aranacak kelime örn: Welcome, Status: OK"
                      value={newTarget.keyword}
                      onChange={(e) => setNewTarget(prev => ({ ...prev, keyword: e.target.value }))}
                      className="w-full bg-[#0d1222] border border-[#1c2847] rounded-lg px-3 py-2 text-xs text-gray-200 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div className="col-span-1 md:col-span-2 pt-3 flex justify-end">
                    <button
                      type="submit"
                      className="cursor-pointer bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs px-5 py-2.5 rounded-lg flex items-center gap-2"
                      id="submit-new-target-btn"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>İzleme Havuzuna Entegre Et</span>
                    </button>
                  </div>
                </form>
              </motion.div>
            )}

            {/* 2. STATE: DETAILS VIEWER & GRAPHS ENGINE */}
            {activeTargetFullDetails ? (
              <motion.div
                key={selectedTargetId}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-6"
              >
                
                {/* HOST HEADING ROW */}
                <div className="bg-[#0b1022]/90 border border-[#141d34] p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-lg shadow-black/40">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-900/60">
                        {activeTargetFullDetails.target.type} PROBE
                      </span>
                      {activeTargetFullDetails.target.keyword && (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 text-purple-400 border border-purple-900/40">
                          Regex: "{activeTargetFullDetails.target.keyword}"
                        </span>
                      )}
                      
                      {!activeTargetFullDetails.target.enabled ? (
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">PASİF</span>
                      ) : activeTargetFullDetails.lastResult?.status === "DOWN" ? (
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-red-950 text-red-400 border border-red-900/60 animate-pulse">ÇEVRİMDIŞI CRITICAL</span>
                      ) : (
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400 border border-emerald-900/40">AKTİF ONLINE</span>
                      )}
                    </div>

                    <h2 className="text-lg font-bold text-gray-100 flex items-center gap-2 mt-1 font-display">
                      {activeTargetFullDetails.target.name}
                    </h2>
                    
                    <p className="text-xs text-gray-400 font-mono select-all flex items-center gap-1.5">
                      <Globe2 className="w-3.5 h-3.5 text-blue-500" />
                      {activeTargetFullDetails.target.url}
                    </p>
                  </div>

                  {/* Immediate Control triggers */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleManualCheckTrigger(activeTargetFullDetails.target.id)}
                      disabled={isRefreshing}
                      className="cursor-pointer text-xs bg-[#121c38] hover:bg-blue-900/40 border border-[#21315e] hover:border-blue-500 px-3 py-2 rounded-lg text-gray-200 transition duration-150 flex items-center gap-2"
                      id="btn-trigger-immediate-check"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin" : ""}`} />
                      <span>Anlık Teşhis Yap</span>
                    </button>
                  </div>
                </div>

                {/* TARGET SPECIFIC HEALTH STATISTICS */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-[#0b1022]/60 border border-[#141b31] p-4 rounded-xl text-center space-y-1">
                    <span className="text-[10px] text-gray-400 font-mono font-semibold uppercase">HEDEF SLA ORANI</span>
                    <p className="text-xl font-bold font-display text-emerald-400">%{activeTargetFullDetails.uptimePercentage}</p>
                    <span className="text-[9px] text-gray-500 font-mono">Son 1 Hafta</span>
                  </div>
                  <div className="bg-[#0b1022]/60 border border-[#141b31] p-4 rounded-xl text-center space-y-1">
                    <span className="text-[10px] text-gray-400 font-mono font-semibold uppercase">ORTALAMA LATENCY</span>
                    <p className="text-xl font-bold font-display text-blue-400">{activeTargetFullDetails.avgResponse} ms</p>
                    <span className="text-[9px] text-gray-500 font-mono">Hassasiyet: 1ms</span>
                  </div>
                  <div className="bg-[#0b1022]/60 border border-[#141b31] p-4 rounded-xl text-center space-y-1">
                    <span className="text-[10px] text-gray-400 font-mono font-semibold uppercase">p95 / p99 GEÇİŞ</span>
                    <p className="text-xl font-bold font-display text-purple-400">{activeTargetFullDetails.p95} / {activeTargetFullDetails.p99} ms</p>
                    <span className="text-[9px] text-gray-500 font-mono">En Yoğun Limit Dilimi</span>
                  </div>
                  <div className="bg-[#0b1022]/60 border border-[#141b31] p-4 rounded-xl text-center space-y-1">
                    <span className="text-[10px] text-gray-400 font-mono font-semibold uppercase">ICMP PAKET ORANI</span>
                    <p className={`text-xl font-bold font-display ${activeTargetFullDetails.lastResult?.packet_loss === 0 ? "text-emerald-400" : "text-amber-500"}`}>
                      %{100 - (activeTargetFullDetails.lastResult?.packet_loss || 0)} BAŞARI
                    </p>
                    <span className="text-[9px] text-gray-500 font-mono">Loss Rate: %{activeTargetFullDetails.lastResult?.packet_loss || 0}</span>
                  </div>
                </div>

                {/* GRAPH 2: RESPONSE PHASES LATENCY DRILLDOWN */}
                <div className="bg-[#080d19] border border-[#131b2e] p-5 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-gray-200 text-sm flex items-center gap-2">
                        <Clock className="w-4 h-4 text-teal-400" />
                        Ayrıntılı Milisaniye (ms) Yanıt Süreleri Gözetim Grafiği
                      </h3>
                      <p className="text-xs text-gray-500 font-mono">DNS, TCP, SSL El Sıkışma, TTFB ve Toplam Süre Aşamaları</p>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs font-mono font-semibold text-gray-400">
                      <span className="w-2 h-2 rounded bg-[#a78bfa]" /> DNS
                      <span className="w-2 h-2 rounded bg-[#f97316]" /> TCP
                      <span className="w-2 h-2 rounded bg-[#38bdf8]" /> TLS
                      <span className="w-2 h-2 rounded bg-[#6366f1]" /> TTFB
                    </div>
                  </div>

                  <div className="h-64 mt-4 text-xs">
                    {activeCheckHistory.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-gray-500 font-mono">
                        Grafik çizimi başlatılamadı. İlk veri akışı bekleniyor...
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                          data={activeCheckHistory}
                          margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                        >
                          <defs>
                            <linearGradient id="colorDns" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#a78bfa" stopOpacity={0.2}/>
                              <stop offset="95%" stopColor="#a78bfa" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorTcp" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#f97316" stopOpacity={0.2}/>
                              <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorTls" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.2}/>
                              <stop offset="95%" stopColor="#38bdf8" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorTtfb" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2}/>
                              <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                              <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#101828" />
                          <XAxis 
                            dataKey="timestamp" 
                            tickFormatter={(t) => new Date(t).toLocaleTimeString()} 
                            stroke="#475569" 
                            fontSize={10}
                          />
                          <YAxis stroke="#475569" fontSize={10} name="ms" unit="ms" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: "#0b1022", border: "1px solid #1e293b", borderRadius: "8px" }}
                            labelFormatter={(label) => `İstek Zamanı: ${new Date(label).toLocaleString()}`}
                          />
                          <Legend />
                          <Area type="monotone" dataKey="dns_ms" name="DNS Çözümleme" stroke="#a78bfa" fillOpacity={1} fill="url(#colorDns)" stackId="1" />
                          <Area type="monotone" dataKey="tcp_ms" name="TCP Bağlantı" stroke="#f97316" fillOpacity={1} fill="url(#colorTcp)" stackId="1" />
                          <Area type="monotone" dataKey="tls_ms" name="TLS El Sıkışma" stroke="#38bdf8" fillOpacity={1} fill="url(#colorTls)" stackId="1" />
                          <Area type="monotone" dataKey="ttfb_ms" name="TTFB Gecikmesi" stroke="#6366f1" fillOpacity={1} fill="url(#colorTtfb)" stackId="1" />
                          <Area type="monotone" dataKey="total_ms" name="Toplam Süre" stroke="#10b981" fillOpacity={0.1} fill="url(#colorTotal)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </div>

                {/* BOTTOM BLOCK: DNS, SSL, SECURITY AUDIT DETAILS */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* SSL INFRASTRUCTURE VERIFIER */}
                  <div className="bg-[#080d19] border border-[#131b2e] p-5 rounded-2xl space-y-4">
                    <h3 className="font-bold text-sm text-gray-200 flex items-center gap-2">
                      <Lock className="w-4 h-4 text-emerald-400" />
                      SSL/TLS Güvenlik Sertifikası Teşhisi (Issuer & Expiry)
                    </h3>
                    
                    {activeTargetFullDetails.sslRecord && activeTargetFullDetails.sslRecord.status !== "NONE" ? (
                      <div className="space-y-4 font-mono text-[11px]">
                        <div className="flex items-center justify-between p-3 rounded-lg bg-[#0e1428] border border-[#1a2542]">
                          <div>
                            <span className="text-gray-500 block uppercase text-[9px] font-bold">KORUMA DURUMU</span>
                            <span className={`text-xs font-bold ${activeTargetFullDetails.sslRecord.status === "VALID" ? "text-emerald-400" : "text-amber-500"}`}>
                              {activeTargetFullDetails.sslRecord.status === "VALID" ? "GÜVENLİ (VALID)" : "TEHLİKE (EXPIRING)"}
                            </span>
                          </div>
                          <div className="text-right">
                            <span className="text-gray-500 block uppercase text-[9px] font-bold">KALAN GÜN</span>
                            <span className="text-xs font-bold text-gray-100">{activeTargetFullDetails.sslRecord.days_remaining} Gün</span>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <div className="flex justify-between border-b border-[#12192e] pb-1">
                            <span className="text-gray-500">Sertifika Sağlayıcı (Issuer)</span>
                            <span className="text-gray-200 truncate max-w-[200px]" title={activeTargetFullDetails.sslRecord.issuer}>
                              {activeTargetFullDetails.sslRecord.issuer}
                            </span>
                          </div>
                          <div className="flex justify-between border-b border-[#12192e] pb-1">
                            <span className="text-gray-500">Son Kullanma Tarihi (Expiry)</span>
                            <span className="text-gray-200">{new Date(activeTargetFullDetails.sslRecord.expires || "").toLocaleDateString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Şifreleme Algoritması</span>
                            <span className="text-gray-200">ECDSA SECP256R1 / RSA 2048</span>
                          </div>
                        </div>

                        {/* Renewal indicator warning */}
                        {activeTargetFullDetails.sslRecord.days_remaining !== undefined && activeTargetFullDetails.sslRecord.days_remaining <= 15 && (
                          <div className="p-2.5 rounded bg-amber-950/20 border border-amber-900/40 text-amber-300 text-[10px] flex items-start gap-1.5">
                            <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                            <span>Dikkat! Sertifika kullanım süresinin sonuna yaklaşmıştır. Kritik kesinti yaşamamak için Ansible otomasyonu ile yenileme playboku çalıştırın.</span>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="p-6 text-center text-gray-500 text-xs font-mono space-y-1 bg-[#0b101e]/40 rounded-xl">
                        <Unlock className="w-6 h-6 mx-auto text-gray-600 mb-1" />
                        <p>SSL Kayıtları Mevcut Değil</p>
                        <span className="text-[10px] text-gray-600 block">Bu protokol (HTTP, DNS veya PING) şifrelenmiş TLS/SSL sertifikası doğrulaması içermez.</span>
                      </div>
                    )}
                  </div>

                  {/* DNS RESOLVER DETAILS */}
                  <div className="bg-[#080d19] border border-[#131b2e] p-5 rounded-2xl space-y-4">
                    <h3 className="font-bold text-sm text-gray-200 flex items-center gap-2">
                      <Database className="w-4 h-4 text-blue-400" />
                      Küresel DNS Çözümleme Tablosu (dig / any)
                    </h3>

                    {activeTargetFullDetails.dnsRecord && activeTargetFullDetails.dnsRecord.status === "OK" ? (
                      <div className="space-y-3 font-mono text-[11px]">
                        <div className="flex items-center justify-between p-3 rounded-lg bg-[#0e1428] border border-[#1a2542]">
                          <div>
                            <span className="text-gray-500 block uppercase text-[9px] font-bold font-mono">ÇÖZÜMLENEN ADRES</span>
                            <span className="text-xs font-bold text-blue-400">{activeTargetFullDetails.dnsRecord.ip}</span>
                          </div>
                          <div className="text-right">
                            <span className="text-gray-500 block uppercase text-[9px] font-bold font-mono">ÇÖZÜM SÜRESİ</span>
                            <span className="text-xs font-bold text-gray-100">{activeTargetFullDetails.dnsRecord.resolve_ms || 12} ms</span>
                          </div>
                        </div>

                        <div className="space-y-1">
                          <span className="text-gray-500 text-[10px] block font-semibold">MEVCUT COĞRAFİ KAYITLAR (A RECORDS)</span>
                          <div className="border border-[#141b2f] rounded-lg divide-y divide-[#141b2f] max-h-[100px] overflow-y-auto">
                            {activeTargetFullDetails.dnsRecord.records?.map((rec, i) => (
                              <div key={i} className="flex justify-between items-center p-2 text-[10px] hover:bg-[#10172e]">
                                <span className="text-[#a78bfa] font-bold">{rec.type}</span>
                                <span className="text-gray-300 font-mono select-all">{rec.value}</span>
                                <span className="text-gray-500">TTL: {activeTargetFullDetails.dnsRecord.ttl || 300}sn</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="p-6 text-center text-gray-500 text-xs font-mono space-y-1 bg-[#0b101e]/40 rounded-xl">
                        <XCircle className="w-6 h-6 mx-auto text-red-500 mb-1" />
                        <p className="text-red-400 font-bold">DNS Çözümleme Hatası</p>
                        <span className="text-[10px] text-gray-600 block">ENOTFOUND: Bu sunucu adresi bir IP karşılığına çözümlenemiyor veya DNS sunucuları kapalı.</span>
                      </div>
                    )}
                  </div>

                </div>

                {/* HEADER SECURITY AND CONTENT VALIDATION AUDIT CHECKLIST */}
                <div className="bg-[#080d19] border border-[#131b2e] p-5 rounded-2xl space-y-4">
                  <h3 className="font-bold text-sm text-gray-200 flex items-center gap-2">
                    <FileCheck className="w-4 h-4 text-purple-400" />
                    HTTP Başlıkları Güvenlik Denetimi &amp; İçerik Doğrulama (Header Audit)
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
                    
                    {/* HSTS */}
                    <div className="bg-[#0b1022] border border-[#15203a] p-3.5 rounded-lg flex flex-col justify-between space-y-2">
                      <span className="text-gray-400 text-[10px] font-bold">HSTS DESTEĞİ</span>
                      {activeTargetFullDetails.headers?.hsts ? (
                        <span className="text-emerald-400 font-bold flex items-center gap-1 text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> ETKİN
                        </span>
                      ) : (
                        <span className="text-amber-500 font-bold flex items-center gap-1 text-[11px]">
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-500" /> YOK / UYARI
                        </span>
                      )}
                      <span className="text-[9px] text-gray-500 block">Strict-Transport-Security</span>
                    </div>

                    {/* CSP */}
                    <div className="bg-[#0b1022] border border-[#15203a] p-3.5 rounded-lg flex flex-col justify-between space-y-2">
                      <span className="text-gray-400 text-[10px] font-bold">CSP FİLTRESİ</span>
                      {activeTargetFullDetails.headers?.csp ? (
                        <span className="text-emerald-400 font-bold flex items-center gap-1 text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> ETKİN
                        </span>
                      ) : (
                        <span className="text-slate-500 font-bold flex items-center gap-1 text-[11px]">
                          <XCircle className="w-3.5 h-3.5 text-slate-500" /> YOK
                        </span>
                      )}
                      <span className="text-[9px] text-gray-500 block">Content-Security-Policy</span>
                    </div>

                    {/* XFO */}
                    <div className="bg-[#0b1022] border border-[#15203a] p-3.5 rounded-lg flex flex-col justify-between space-y-2">
                      <span className="text-gray-400 text-[10px] font-bold">X-FRAME-OPTIONS</span>
                      {activeTargetFullDetails.headers?.xfo ? (
                        <span className="text-emerald-400 font-bold flex items-center gap-1 text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> ETKİN
                        </span>
                      ) : (
                        <span className="text-amber-500 font-bold flex items-center gap-1 text-[11px]">
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-500" /> PASİF
                        </span>
                      )}
                      <span className="text-[9px] text-gray-500 block">Clickjacking Koruması</span>
                    </div>

                    {/* KEYWORD CONTENT CHECK */}
                    <div className="bg-[#0b1022] border border-[#15203a] p-3.5 rounded-lg flex flex-col justify-between space-y-2">
                      <span className="text-gray-400 text-[10px] font-bold">İÇERİK PATTERNLERİ</span>
                      {activeTargetFullDetails.target.keyword ? (
                        activeTargetFullDetails.lastResult?.keyword_found ? (
                          <span className="text-emerald-400 font-bold flex items-center gap-1 text-[11px]">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> BULUNDU
                          </span>
                        ) : (
                          <span className="text-red-400 font-bold flex items-center gap-1 text-[11px]">
                            <XCircle className="w-3.5 h-3.5 text-red-500" /> KAYIP / DOWN
                          </span>
                        )
                      ) : (
                        <span className="text-slate-500 block text-[11px]">Kriter Belirtilmedi</span>
                      )}
                      <span className="text-[9px] text-gray-500 block">
                        {activeTargetFullDetails.target.keyword ? `Kelime: "${activeTargetFullDetails.target.keyword}"` : "Sayfa Kelime Araması Pasif"}
                      </span>
                    </div>

                  </div>

                  {activeTargetFullDetails.headers?.server && (
                    <p className="text-[11px] text-gray-500 font-mono mt-2">
                      İzlenen Web Sunucusu Kimlik Bilgisi (Server Header): <span className="text-indigo-400">{activeTargetFullDetails.headers.server}</span>
                    </p>
                  )}
                </div>

                {/* DEPLOYMENT AGENT BLOCK: ANSIBLE ORCHESTRATION PIPELINE */}
                <div className="bg-[#080d19] border border-[#131b2e] p-5 rounded-2xl space-y-4">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-[#141b2f] pb-3">
                    <div>
                      <h3 className="font-bold text-sm text-gray-200 flex items-center gap-2">
                        <Cpu className="w-4 h-4 text-emerald-400 animate-pulse" />
                        Uzaktan Otomasyon &amp; Bakım Arayüzü (Ansible Playbook Engine)
                      </h3>
                      <p className="text-xs text-gray-500 font-mono">Hedef sunucuya SSH bağlantısı kurarak cURL toplama betiklerini ve sistem ayarlarını yapılandırın</p>
                    </div>

                    <div className="flex gap-2 font-mono text-xs">
                      <select
                        value={selectedPlaybook}
                        onChange={(e) => setSelectedPlaybook(e.target.value)}
                        className="bg-[#0d1222] border border-[#1c2847] rounded-lg px-2 py-1 text-xs text-gray-200 focus:outline-none"
                      >
                        <option value="deploy-sentinel-collector.yml">deploy-probe-agent.yml (Gösterge Kurulumu)</option>
                        <option value="ssl-renew-automation.yml">ssl-renew-automation.yml (Sertifika Rotasyonu)</option>
                        <option value="service-reboot-daemon.yml">service-reboot-daemon.yml (Nginx/Apache Yeniden Başlat)</option>
                      </select>
                      
                      <button
                        onClick={handleRunAnsiblePlaybook}
                        disabled={isDeployingAnsible}
                        className={`cursor-pointer px-3 py-1 font-semibold rounded bg-emerald-600 hover:bg-emerald-500 text-white flex items-center gap-1.5 transition ${isDeployingAnsible ? "opacity-50 cursor-not-allowed" : ""}`}
                        id="play-ansible-automation-trigger"
                      >
                        <Play className="w-3 h-3 fill-current" />
                        <span>Playbook Çalıştır</span>
                      </button>
                    </div>
                  </div>

                  {/* Hacks terminal scrolling stdout window */}
                  {(ansibleLogsTerminal.length > 0 || isDeployingAnsible) && (
                    <div className="bg-[#0a0f1d] border border-[#16213a] p-4 rounded-xl font-mono text-[10px] text-gray-300 space-y-1 max-h-[220px] overflow-y-auto relative scrollbar-none">
                      <div className="flex items-center justify-between bg-slate-900 border-b border-slate-800 -mx-4 -mt-4 px-4 py-1.5 text-gray-400 text-[9px] mb-2 font-mono">
                        <span>STDOUT TERMINAL PIPE | ANSIBLE ENGINE</span>
                        <div className="flex gap-1">
                          <span className="w-2 h-2 rounded-full bg-red-500 inline-block"></span>
                          <span className="w-2 h-2 rounded-full bg-yellow-500 inline-block"></span>
                          <span className="w-2 h-2 rounded-full bg-green-500 inline-block"></span>
                        </div>
                      </div>

                      {ansibleLogsTerminal.map((line, idx) => {
                        let color = "text-gray-300";
                        if (line.includes("TASK [")) color = "text-indigo-300 font-bold mt-2 block";
                        else if (line.includes("changed:")) color = "text-yellow-400";
                        else if (line.includes("ok:")) color = "text-emerald-400";
                        else if (line.includes("PLAY RECAP")) color = "text-cyan-400 font-bold block mt-3";
                        else if (line.includes("failed=")) color = "text-red-400";

                        return (
                          <div key={idx} className={`${color} leading-relaxed`}>
                            {line}
                          </div>
                        );
                      })}

                      {isDeployingAnsible && (
                        <div className="text-gray-500 animate-pulse mt-1 flex items-center gap-1">
                          <Terminal className="w-3 w-3 animate-spin text-green-500" />
                          <span>Geri bildirim paketleri alınıyor... SSH tüneli aktif...</span>
                        </div>
                      )}

                      <div ref={terminalBottomRef} />
                    </div>
                  )}

                  {/* Historic orchestration lists */}
                  <div className="space-y-1">
                    <span className="text-[10px] text-gray-500 font-semibold block uppercase font-mono">SON GERÇEKLEŞTİRİLEN ANSIBLE İŞLERİ</span>
                    <div className="divide-y divide-[#131a2e]">
                      {ansiblePlaybooks.length === 0 ? (
                        <p className="text-[11px] text-gray-600 font-mono italic p-2">Kayıtlı geçmiş Ansible otomasyon görevi bulunmamaktadır.</p>
                      ) : (
                        ansiblePlaybooks.slice(0, 3).map((play, i) => (
                          <div key={`playbook-${play.startedAt || i}-${i}`} className="flex justify-between items-center py-2 text-[11px] font-mono">
                            <span className="text-gray-400 flex items-center gap-1">
                              <FileCheck className="w-3 h-3 text-emerald-500" />
                              {play.targetName}
                            </span>
                            <span className="text-emerald-400 font-semibold">{play.logs[0]?.substring(20, 60) || "Job Completed"}</span>
                            <span className="text-gray-500 text-[10px]">{new Date(play.startedAt || "").toLocaleTimeString()}</span>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                </div>

              </motion.div>
            ) : (
              <div className="p-12 text-center text-gray-500 font-mono italic">
                Ayrıntılı performans grafiklerini ve SSL/DNS kayıt verilerini incelemek için soldan bir hedef istasyon seçiniz.
              </div>
            )}

            {/* AD-HOC VERIFICATION PLAYGROUND PANEL: ALWAYS INTEGRATED */}
            <div className="bg-[#080d19] border border-[#131b2e] p-5 rounded-2xl space-y-4">
              <div>
                <h3 className="font-bold text-sm text-gray-200 flex items-center gap-2">
                  <Globe2 className="w-4 h-4 text-emerald-400" />
                  Canlı cURL &amp; İstek Test Laboratuvarı (Playground Diagnostic Engine)
                </h3>
                <p className="text-xs text-gray-500 font-mono">Sistem havuzuna yeni bir sunucu eklemeden önce anlık olarak HTTP başlıklarını, el sıkışma sürelerini ve SSL durumunu inceleyin</p>
              </div>

              <form onSubmit={handleTestPlaygroundUrl} className="grid grid-cols-1 md:grid-cols-12 gap-3">
                <div className="md:col-span-6 relative">
                  <input
                    type="text"
                    placeholder="örn: https://dns.google veya https://github.com"
                    value={playgroundUrl}
                    onChange={(e) => setPlaygroundUrl(e.target.value)}
                    className="w-full bg-[#0d1222] border border-[#1c2847] rounded-lg px-3 py-2 text-xs text-gray-200 focus:outline-none focus:border-emerald-500 font-mono"
                  />
                </div>
                <div className="md:col-span-3">
                  <input
                    type="text"
                    placeholder="Payload Kelimesi"
                    value={playgroundKeyword}
                    onChange={(e) => setPlaygroundKeyword(e.target.value)}
                    className="w-full bg-[#0d1222] border border-[#1c2847] rounded-lg px-3 py-2 text-xs text-gray-200 focus:outline-none"
                  />
                </div>
                <div className="md:col-span-3">
                  <button
                    type="submit"
                    disabled={isTestingPlayground}
                    className={`cursor-pointer w-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs px-4 py-2 rounded-lg flex items-center justify-center gap-1.5 shadow duration-150 ${isTestingPlayground ? "opacity-50 cursor-not-allowed" : ""}`}
                    id="btn-play-curl-validation"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isTestingPlayground ? "animate-spin" : ""}`} />
                    <span>Hızlı İstek Gönder</span>
                  </button>
                </div>
              </form>

              {playgroundError && (
                <div className="bg-red-950/20 border border-red-900/40 p-3 rounded-lg text-xs text-red-300 font-mono">
                  cURL Hatası: {playgroundError}
                </div>
              )}

              {playgroundResult && (
                <div className="space-y-4">
                  {/* Status Banner */}
                  <div className={`p-4 rounded-xl border flex items-center justify-between font-mono ${playgroundResult.status === "UP" ? "bg-emerald-950/20 border-emerald-900/40 text-emerald-300" : "bg-red-950/20 border-red-900/40 text-red-300"}`}>
                    <div className="space-y-1">
                      <span className="text-[10px] text-gray-500 font-bold block uppercase">TEST YANITI DURUMU</span>
                      <span className="text-xs font-bold leading-none flex items-center gap-1">
                        {playgroundResult.status === "UP" ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-red-400" />}
                        {playgroundResult.status === "UP" ? "ONLINE (SAYFA ÇALIŞIYOR)" : "DOWN / CEVAP YOK"}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-gray-500 font-mono block">CURL HTTP KODU</span>
                      <span className="text-sm font-bold block">{playgroundResult.statusCode || "N/A"}</span>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-gray-500 font-mono block">GERÇEK TOPLAM GEÇİŞ SÜRESİ</span>
                      <span className="text-sm font-bold block text-blue-400">{playgroundResult.total_ms}ms</span>
                    </div>
                  </div>

                  {/* Millisecond phases */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
                    <div className="bg-[#0b1022] border border-[#15203a] p-3 rounded-lg text-center">
                      <span className="text-gray-500 text-[10px] block font-semibold">DNS LOOKUP</span>
                      <p className="text-indigo-400 font-bold text-sm">{playgroundResult.dns_ms}ms</p>
                    </div>
                    <div className="bg-[#0b1022] border border-[#15203a] p-3 rounded-lg text-center">
                      <span className="text-gray-500 text-[10px] block font-semibold">TCP CONNECT</span>
                      <p className="text-orange-400 font-bold text-sm">{playgroundResult.tcp_ms}ms</p>
                    </div>
                    <div className="bg-[#0b1022] border border-[#15203a] p-3 rounded-lg text-center">
                      <span className="text-gray-500 text-[10px] block font-semibold">TLS HANDSHAKE</span>
                      <p className="text-sky-400 font-bold text-sm">{playgroundResult.tls_ms}ms</p>
                    </div>
                    <div className="bg-[#0b1022] border border-[#15203a] p-3 rounded-lg text-center">
                      <span className="text-gray-500 text-[10px] block font-semibold">TTFB PORT DELAY</span>
                      <p className="text-purple-400 font-bold text-sm">{playgroundResult.ttfb_ms}ms</p>
                    </div>
                  </div>

                  {/* JSON response tree renderer */}
                  <div className="bg-[#0a0f1d] border border-[#16213a] rounded-xl overflow-hidden font-mono text-[10px]">
                    <div className="bg-slate-900 border-b border-slate-800 px-4 py-2 flex items-center justify-between text-gray-400 text-[9px] font-semibold">
                      <span>MONITOR ENGINE RESPONSE PAYLOAD</span>
                      <button
                        type="button"
                        onClick={() => setJsonFolded(!jsonFolded)}
                        className="cursor-pointer text-gray-400 hover:text-white bg-slate-800 px-1.5 py-0.5 rounded flex items-center gap-1 font-mono hover:scale-105"
                      >
                        <Eye className="w-3 h-3" />
                        <span>{jsonFolded ? "Genişlet" : "Daralt"}</span>
                      </button>
                    </div>

                    {!jsonFolded && (
                      <pre className="p-4 text-indigo-300 leading-relaxed overflow-x-auto max-h-[220px] custom-scroll-panel">
                        {JSON.stringify(playgroundResult, null, 2)}
                      </pre>
                    )}
                  </div>
                </div>
              )}
            </div>

          </AnimatePresence>

        </section>

      </main>

      {/* FOOTER BAR */}
      <footer className="bg-[#05080f] px-6 py-3 border-t border-[#131b2f] flex flex-col md:flex-row justify-between items-center text-[11px] text-gray-500 font-mono gap-2">
        <p>© 2026 Sentinel Observability Hub. Tüm Hakları Saklıdır.</p>
        <div className="flex gap-4">
          <span>Linux Shell Tools Mode: <span className="text-emerald-400">cURL, OpenSSL, dig, ping</span></span>
          <span className="hidden sm:inline">|</span>
          <span className="text-gray-400 font-bold">Murat Karahaliloğlu Sandbox</span>
        </div>
      </footer>

    </div>
  );
}
