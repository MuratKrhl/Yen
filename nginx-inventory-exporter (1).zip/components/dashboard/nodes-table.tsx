'use client'

import { Server, Cpu, HardDrive, Clock, Network, Cog } from 'lucide-react'
import { 
  Table, 
  TableHeader, 
  TableBody, 
  TableHead, 
  TableRow, 
  TableCell 
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { NodeData } from '@/lib/mock-data'

interface NodesTableProps {
  nodes: NodeData[]
  searchQuery: string
}

export function NodesTable({ nodes, searchQuery }: NodesTableProps) {
  const filteredNodes = nodes.filter(node => 
    node.hostname.toLowerCase().includes(searchQuery.toLowerCase()) ||
    node.ip_address.includes(searchQuery) ||
    node.os.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden">
      <div className="px-4 py-3 border-b border-border flex items-center gap-2">
        <Server className="h-4 w-4 text-primary" />
        <h3 className="font-medium text-sm">Server Nodes</h3>
        <Badge variant="secondary" className="ml-auto">{filteredNodes.length} nodes</Badge>
      </div>
      
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="w-[180px]">Hostname</TableHead>
              <TableHead>IP Address</TableHead>
              <TableHead>OS</TableHead>
              <TableHead>Nginx</TableHead>
              <TableHead className="text-center">CPU</TableHead>
              <TableHead className="text-center">Memory</TableHead>
              <TableHead className="text-center">Uptime</TableHead>
              <TableHead className="text-center">Connections</TableHead>
              <TableHead className="text-center">Workers</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredNodes.map((node) => (
              <TableRow key={node.hostname} className="group">
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-success" />
                    <span className="font-mono text-sm">{node.hostname}</span>
                  </div>
                </TableCell>
                <TableCell className="font-mono text-muted-foreground">{node.ip_address}</TableCell>
                <TableCell className="text-muted-foreground">{node.os}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="font-mono">v{node.nginx_version}</Badge>
                </TableCell>
                <TableCell className="text-center">
                  <div className="flex items-center justify-center gap-1">
                    <Cpu className="h-3.5 w-3.5 text-muted-foreground" />
                    <span>{node.cpu_cores}</span>
                  </div>
                </TableCell>
                <TableCell className="text-center">
                  <div className="flex items-center justify-center gap-1">
                    <HardDrive className="h-3.5 w-3.5 text-muted-foreground" />
                    <span>{node.memory_gb}GB</span>
                  </div>
                </TableCell>
                <TableCell className="text-center">
                  <div className="flex items-center justify-center gap-1">
                    <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                    <span>{node.uptime_days}d</span>
                  </div>
                </TableCell>
                <TableCell className="text-center">
                  <div className="flex items-center justify-center gap-1">
                    <Network className="h-3.5 w-3.5 text-muted-foreground" />
                    <span className="text-primary font-medium">{node.active_connections.toLocaleString()}</span>
                  </div>
                </TableCell>
                <TableCell className="text-center">
                  <div className="flex items-center justify-center gap-1">
                    <Cog className="h-3.5 w-3.5 text-muted-foreground" />
                    <span>{node.worker_processes}</span>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
