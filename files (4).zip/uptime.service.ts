// src/modules/uptime/uptime.service.ts
import { Injectable } from '@nestjs/common';
import { UptimeCheckerService } from './uptime-checker.service';

@Injectable()
export class UptimeService {
  constructor(private readonly checker: UptimeCheckerService) {}

  async getAllUrls() {
    // return this.urlRepo.find({ where: { isActive: true }, order: { createdAt: 'DESC' } });
    return getMockUrls();
  }

  async addUrl(dto: { label: string; url: string; intervalSeconds: number; timeoutMs: number }) {
    // const saved = await this.urlRepo.save({ ...dto, isActive: true });
    const saved = { id: Date.now(), ...dto, isActive: true, createdAt: new Date() };
    this.checker.startMonitor(saved);
    return saved;
  }

  async removeUrl(id: number) {
    // await this.urlRepo.update(id, { isActive: false });
    this.checker.stopMonitor(id);
  }

  async getChecks(urlId: number, limit: number) {
    // return this.checkRepo.find({
    //   where: { urlId },
    //   order: { checkedAt: 'DESC' },
    //   take: limit,
    // });
    return generateMockChecks(urlId, limit);
  }

  async getSummary() {
    // Gerçek implementasyonda DB aggregate sorgusu yapılır
    return {
      globalUptime: 99.98,
      avgLatencyMs: 156,
      dnsHealth: 'Robust',
      totalUrls: 5,
      urlsDown: 1,
      urlsWarn: 1,
    };
  }
}

function getMockUrls() {
  return [
    { id: 1, label: 'Intranet Portal', url: 'https://intranet.corp.local', intervalSeconds: 60, timeoutMs: 5000, isActive: true },
    { id: 2, label: 'DNS Sunucu 1', url: 'https://dns1.corp.local', intervalSeconds: 30, timeoutMs: 3000, isActive: true },
  ];
}

function generateMockChecks(urlId: number, limit: number) {
  const now = Date.now();
  return Array.from({ length: limit }, (_, i) => ({
    id: i,
    urlId,
    checkedAt: new Date(now - i * 60000),
    statusCode: 200,
    latencyMs: 130 + Math.floor(Math.random() * 60),
    isUp: true,
    errorMessage: null,
    dnsResolved: true,
  }));
}

// ──────────────────────────────────────────────
// src/modules/uptime/uptime.module.ts
// ──────────────────────────────────────────────
// import { Module } from '@nestjs/common';
// import { HttpModule } from '@nestjs/axios';
// import { TypeOrmModule } from '@nestjs/typeorm';
// import { UptimeController } from './uptime.controller';
// import { UptimeService } from './uptime.service';
// import { UptimeCheckerService } from './uptime-checker.service';
// import { MonitoredUrlEntity } from './monitored-url.entity';
// import { UptimeCheckEntity } from './uptime-check.entity';
//
// @Module({
//   imports: [
//     HttpModule,
//     TypeOrmModule.forFeature([MonitoredUrlEntity, UptimeCheckEntity]),
//   ],
//   controllers: [UptimeController],
//   providers: [UptimeService, UptimeCheckerService],
//   exports: [UptimeService],
// })
// export class UptimeModule {}
