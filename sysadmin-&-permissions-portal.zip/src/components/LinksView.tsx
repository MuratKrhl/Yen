import React, { useState } from 'react';
import { 
  ExternalLink, 
  Plus, 
  Trash2, 
  Tag, 
  FolderLock, 
  BookmarkCheck,
  Lock,
  Edit
} from 'lucide-react';
import { QuickLink } from '../types';

interface LinksViewProps {
  links: QuickLink[];
  canWrite: boolean;
  onUpdateLinks: (link: QuickLink, mode: 'add' | 'edit' | 'delete') => void;
}

const CATEGORIES = ['Monitoring', 'Logs', 'Cloud', 'Documentation', 'Source Code', 'Management', 'Other'];

const LinksView: React.FC<LinksViewProps> = ({
  links,
  canWrite,
  onUpdateLinks
}) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [url, setUrl] = useState('https://');
  const [category, setCategory] = useState('Monitoring');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !url || !category) return;

    const payload: any = {
      title,
      url,
      category
    };

    onUpdateLinks(payload as QuickLink, 'add');
    setIsFormOpen(false);

    // reset fields
    setTitle('');
    setUrl('https://');
  };

  const handleDelete = (link: QuickLink) => {
    if (confirm(`"${link.title}" hızlı bağlantısını silmek istediğinize emin misiniz?`)) {
      onUpdateLinks(link, 'delete');
    }
  };

  return (
    <div className="space-y-6">
      {/* Read-Only Warning Banner */}
      {!canWrite && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-xl flex items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2.5">
            <Lock className="h-4 w-4 shrink-0 text-amber-600" />
            <span className="text-xs font-semibold">Salt Okunur Mod — Yeni hızlı erişim linki tanımlama veya mevcut bağlantıları kaldırma yetkiniz bulunmamaktadır.</span>
          </div>
          <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded uppercase font-mono">Yetki Sınırı</span>
        </div>
      )}

      {/* Header and Add Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Önemli Referans Linkleri</h1>
          <p className="text-sm text-slate-500 mt-0.5">Sık kullanılan altyapı monitör panelleri, doküman sayfaları ve harici yönetim konsolları.</p>
        </div>
        
        {canWrite && (
          <button
            id="btn-add-link"
            onClick={() => setIsFormOpen(true)}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm rounded-lg flex items-center gap-2 cursor-pointer transition-all shadow-xs"
          >
            <Plus className="h-4 w-4" />
            Hızlı Link Ekle
          </button>
        )}
      </div>

      {/* Grid view of Links */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {links.map((link) => (
          <div 
            key={link.id} 
            className="bg-white border border-slate-200 hover:border-indigo-200 hover:shadow-sm rounded-xl p-5 flex flex-col justify-between transition-all group"
          >
            <div>
              {/* Category tag */}
              <span className={`inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded font-mono mb-3.5
                ${link.category === 'Monitoring' ? 'bg-indigo-50 text-indigo-700 border border-indigo-100' :
                  link.category === 'Logs' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' :
                  link.category === 'Cloud' ? 'bg-purple-50 text-purple-700 border border-purple-100' :
                  link.category === 'Documentation' ? 'bg-slate-100 text-slate-650' :
                  link.category === 'Source Code' ? 'bg-rose-50 text-rose-700 border border-rose-100' :
                  'bg-amber-50 text-amber-700 border border-amber-100'}`}>
                <Tag className="h-2.5 w-2.5" />
                {link.category}
              </span>

              {/* Title & external URL */}
              <h3 className="font-bold text-slate-800 text-sm leading-snug group-hover:text-indigo-600 transition-colors">
                {link.title}
              </h3>
              
              <p className="text-xs text-slate-400 truncate font-mono mt-1 w-full break-all">
                {link.url}
              </p>
            </div>

            <div className="flex items-center justify-between border-t border-slate-100 pt-3.5 mt-4">
              <a 
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 inline-flex items-center gap-1 cursor-pointer"
              >
                Bağlantıyı Aç
                <ExternalLink className="h-3.5 w-3.5" />
              </a>

              {canWrite && (
                <button
                  id={`btn-delete-link-${link.id}`}
                  onClick={() => handleDelete(link)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-slate-105 rounded-lg transition-all cursor-pointer"
                  title="Link Sil"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        ))}

        {links.length === 0 && (
          <div className="col-span-full bg-slate-50 border-2 border-dashed border-slate-205 py-12 px-4 text-center rounded-xl">
            <FolderLock className="h-10 w-10 text-slate-350 mx-auto mb-3" />
            <h4 className="text-sm font-semibold text-slate-600">Herhangi Bir Link Kaydedilmedi</h4>
            <p className="text-xs text-slate-400 mt-1">Sisteminizde listelenen bir hızlı erişim referansı bulunmuyor.</p>
          </div>
        )}
      </div>

      {/* Editor Modal Add Link */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-sm shadow-2xl p-6">
            <h2 className="text-base font-bold text-slate-900 mb-4 border-b border-slate-100 pb-3 flex items-center gap-2">
              <BookmarkCheck className="h-5 w-5 text-indigo-650" />
              Yeni Hızlı Link Tanımla
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Bağlantı Başlığı *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Kibana Log Monitor"
                  className="w-full px-3 py-2 border border-slate-205 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-normal"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Hedef Adres (URL) *</label>
                <input
                  type="url"
                  required
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://kibana.example.com"
                  className="w-full px-3 py-2 border border-slate-205 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-medium font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Kategori / Sınıf</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-205 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-normal"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-650 text-sm font-semibold rounded-lg cursor-pointer"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-lg cursor-pointer"
                >
                  Kaydet
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default LinksView;
