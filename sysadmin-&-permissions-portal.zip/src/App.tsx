import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Server, 
  ToggleLeft, 
  Terminal, 
  Activity, 
  Bot, 
  CalendarRange, 
  Link as LinkIcon, 
  ShieldCheck, 
  User, 
  Settings2, 
  RotateCcw, 
  Loader2, 
  AlertCircle,
  Clock,
  Menu,
  X,
  PhoneCall
} from 'lucide-react';

// Imports of Modular components
import DashboardView from './components/DashboardView';
import InventoryView from './components/InventoryView';
import SelfServiceView from './components/SelfServiceView';
import AnsibleView from './components/AnsibleView';
import PerformanceView from './components/PerformanceView';
import AskGTView from './components/AskGTView';
import RosterView from './components/RosterView';
import LinksView from './components/LinksView';
import AdminPermissionsPage from './components/AdminPermissionsPage';

import { 
  PermissionsMap, 
  InventoryItem, 
  RosterEntry, 
  QuickLink, 
  AuditLog, 
  UserProfile 
} from './types';

// MOCK USERS AVAILABLE FOR TESTING
const TEST_PROFILES: UserProfile[] = [
  { id: 'admin', name: 'Murat Karahaliloğlu', email: 'murat.karahaliloglu5@gmail.com', role: 'admin' },
  { id: 'user', name: 'Mehmet Demir', email: 'mehmet.demir@internal.com', role: 'user' }
];

export default function App() {
  // Global States
  const [currentUser, setCurrentUser] = useState<UserProfile>(TEST_PROFILES[0]);
  const [activePage, setActivePage] = useState<string>('Dashboard');
  const [permissions, setPermissions] = useState<PermissionsMap>({});
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [roster, setRoster] = useState<RosterEntry[]>([]);
  const [links, setLinks] = useState<QuickLink[]>([]);
  const [logs, setLogs] = useState<AuditLog[]>([]);

  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [connError, setConnError] = useState<boolean>(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Fetch complete state from backend API on mount
  const fetchState = async (showLoading = true) => {
    if (showLoading) setLoading(true);
    try {
      const res = await fetch('/api/state');
      if (!res.ok) throw new Error('API Sync failed');
      const data = await res.json();
      
      setPermissions(data.permissions);
      setInventory(data.inventory);
      setRoster(data.roster);
      setLinks(data.links);
      setLogs(data.logs);
      setConnError(false);
    } catch (err) {
      console.error("Error synchronizing state with server:", err);
      setConnError(true);
    } finally {
      if (showLoading) setLoading(false);
    }
  };

  useEffect(() => {
    fetchState(true);
    // Periodically sync logs and performance stats
    const interval = setInterval(() => {
      fetchState(false);
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  // Update permissions API call
  const handleSavePermissions = async (updatedPerms: PermissionsMap) => {
    setSyncing(true);
    try {
      const res = await fetch('/api/permissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          permissions: updatedPerms,
          user: currentUser.name
        })
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      setPermissions(data.permissions);
      await fetchState(false);
    } catch (err) {
      alert("Hata: Yetkilendirmeler kaydedilemedi.");
    } finally {
      setSyncing(false);
    }
  };

  // Update System Inventory API call
  const handleUpdateInventory = async (item: InventoryItem, mode: 'add' | 'edit' | 'delete') => {
    setSyncing(true);
    try {
      const res = await fetch('/api/inventory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          item,
          mode,
          user: currentUser.name
        })
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      setInventory(data.inventory);
      await fetchState(false);
    } catch (err) {
      alert("Hata: Envanter işlemi gerçekleştirilemedi.");
    } finally {
      setSyncing(false);
    }
  };

  // Update Roster Calendar API call
  const handleUpdateRoster = async (entry: RosterEntry, mode: 'add' | 'edit' | 'delete') => {
    setSyncing(true);
    try {
      const res = await fetch('/api/roster', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          entry,
          mode,
          user: currentUser.name
        })
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      setRoster(data.roster);
      await fetchState(false);
    } catch (err) {
      alert("Hata: Nöbetçi kaydı güncellenemedi.");
    } finally {
      setSyncing(false);
    }
  };

  // Update Quick Links bookmark list
  const handleUpdateLinks = async (link: QuickLink, mode: 'add' | 'edit' | 'delete') => {
    setSyncing(true);
    try {
      const res = await fetch('/api/links', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          link,
          mode,
          user: currentUser.name
        })
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      setLinks(data.links);
      await fetchState(false);
    } catch (err) {
      alert("Hata: Link güncellenemedi.");
    } finally {
      setSyncing(false);
    }
  };

  // Dispatch custom manual audit log events
  const handleTriggerLog = async (action: string, details: string, status: 'success' | 'warning' | 'error') => {
    try {
      const res = await fetch('/api/log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user: currentUser.name,
          action,
          details,
          status
        })
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      setLogs(data.logs);
    } catch (err) {
      console.error("Failed to push custom log:", err);
    }
  };

  // Quick Action triggered inside Dashboard log
  const handleQuickNginxRestart = () => {
    handleTriggerLog('Hızlı Aksiyon', 'Tüm Nginx sunucuları ve LB nodeları yenilenecek (Reload triggered).', 'warning');
    setTimeout(() => {
      handleTriggerLog('Nginx Yenileniyor', 'Tüm cluster nodeları konfigurasyon doğrulamasından geçerek başarıyla başlatıldı.', 'success');
    }, 1500);
  };

  const handleResetState = async () => {
    if (confirm("Tüm yetkilendirmeleri ve portal ayarlarına varsayılana döndürmek ister misiniz?")) {
      setSyncing(true);
      try {
        const res = await fetch('/api/state/reset', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ user: currentUser.name })
        });
        const data = await res.json();
        setPermissions(data.permissions);
        await fetchState(false);
      } catch (err) {
        alert("Hata: Durum sıfırlanamadı.");
      } finally {
        setSyncing(false);
      }
    }
  };

  // Handle Switch Profile Context and auto redirect page if restricted
  const handleUserChange = (user: UserProfile) => {
    setCurrentUser(user);
    // If we switch to standard user, we should direct them away from admin-only pages
    if (user.role === 'user') {
      if (activePage === 'Yetki Yönetimi') {
        setActivePage('Dashboard');
      } else {
        // checks if page read is allowed
        const pagePerm = permissions[activePage];
        if (pagePerm && !pagePerm.read) {
          setActivePage('Dashboard');
        }
      }
    }
  };

  // Compute active user permissions for selected page view
  // Admins always have read-write
  const pagePerm = currentUser.role === 'admin' 
    ? { read: true, write: true } 
    : (permissions[activePage] || { read: false, write: false });

  // Sidebar link details
  interface SidebarItem {
    id: string;
    label: string;
    icon: React.ComponentType<any>;
  }

  const sidebarMenuItems: SidebarItem[] = [
    { id: 'Dashboard',      label: 'Dashboard Overview',  icon: LayoutDashboard },
    { id: 'Envanter',       label: 'Host Envanteri',      icon: Server },
    { id: 'Self Service',   label: 'Self Service',       icon: ToggleLeft },
    { id: 'Ansible',        label: 'Ansible Otomasyon',   icon: Terminal },
    { id: 'Performance',    label: 'Performans',          icon: Activity },
    { id: 'AskGT',          label: 'AskGT Asistanı',      icon: Bot },
    { id: 'Nöbet Listesi',  label: 'Nöbet Listesi',       icon: CalendarRange },
    { id: 'Önemli Linkler', label: 'Önemli Linkler',      icon: LinkIcon }
  ];

  // Filter sidebar items for user (hide pages without read permissions)
  const visibleMenuItems = currentUser.role === 'admin'
    ? sidebarMenuItems
    : sidebarMenuItems.filter(item => permissions[item.id]?.read);

  // loading screen
  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <div className="bg-white border border-slate-205 p-8 rounded-2xl shadow-xl flex flex-col items-center gap-4 text-center max-w-sm">
          <Loader2 className="h-8 w-8 text-indigo-650 animate-spin" />
          <div>
            <h2 className="font-bold text-slate-800 text-base">Güvenli Başlantı Kuruluyor</h2>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">SysAdmin Portal verileri ve yapay zeka agent motor koordinatları senkronize ediliyor.</p>
          </div>
        </div>
      </div>
    );
  }

  // Get current active on-call for ticker
  const activeDutyNow = roster.find(r => r.date === '2026-06-01') || roster[0];

  return (
    <div className="min-h-screen bg-slate-100 flex flex-row font-sans">
      
      {/* 1. SIDEBAR NAVIGATION */}
      <aside className={`fixed inset-y-0 left-0 z-40 w-64 bg-slate-900 text-slate-350 border-r border-slate-950 flex flex-col justify-between transition-transform duration-300 transform lg:translate-x-0 lg:static lg:h-screen
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div>
          {/* Logo Brand Header */}
          <div className="h-16 border-b border-slate-950 px-5 flex items-center justify-between bg-slate-950 text-white">
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="h-6 w-6 text-indigo-500" />
              <div className="overflow-hidden">
                <span className="font-black text-sm block tracking-wider uppercase font-mono">SYS-ADMIN</span>
                <span className="text-[10px] text-indigo-400 font-bold block -mt-0.5 tracking-widest font-mono">PORTAL V1.2.0</span>
              </div>
            </div>
            {/* Mobile close menu trigger */}
            <button 
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Profile Switcher Context */}
          <div className="p-4 border-b border-slate-850 bg-slate-900/60 font-medium">
            <label className="block text-[10px] font-bold text-indigo-400 uppercase tracking-widest mb-2 font-mono">
              Aktif Profil Seçimi
            </label>
            <div className="space-y-1.5">
              {TEST_PROFILES.map((profile) => {
                const isActive = currentUser.id === profile.id;
                return (
                  <button
                    key={profile.id}
                    id={`profile-selector-${profile.id}`}
                    onClick={() => handleUserChange(profile)}
                    className={`w-full text-left p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-between cursor-pointer transition-all
                      ${isActive
                        ? 'bg-indigo-600/15 border-indigo-500/30 text-white shadow-xs'
                        : 'bg-slate-950/20 border-slate-850 hover:border-slate-750 text-slate-400 hover:text-slate-200'}`}
                  >
                    <div className="flex items-center gap-2 overflow-hidden">
                      <div className={`h-6 w-6 rounded-md flex items-center justify-center font-bold font-mono text-[10px] shrink-0
                        ${profile.role === 'admin' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'}`}
                      >
                        {profile.role === 'admin' ? 'A' : 'U'}
                      </div>
                      <div className="truncate text-left">
                        <span className="block truncate leading-tight">{profile.name}</span>
                        <span className="block text-[9px] text-slate-500 capitalize">{profile.role}</span>
                      </div>
                    </div>
                    {isActive && (
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sidebar Menu Pages list */}
          <nav className="p-4 space-y-1">
            <span className="block text-[10px] uppercase font-bold tracking-widest text-slate-550 mb-2 px-2 font-mono">
              YOL HARİTASI
            </span>
            
            {visibleMenuItems.map((item) => {
              const Icon = item.icon;
              const isSelected = activePage === item.id;
              
              return (
                <button
                  key={item.id}
                  id={`nav-item-${item.id}`}
                  onClick={() => { setActivePage(item.id); setSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-bold rounded-lg cursor-pointer transition-colors
                    ${isSelected
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-400 hover:bg-slate-850 hover:text-slate-200'}`}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  <span className="flex-1 text-left truncate">{item.label}</span>
                </button>
              );
            })}

            {/* Admin Permissions Option ONLY FOR MANAGER/ADMIN */}
            {currentUser.role === 'admin' && (
              <>
                <div className="border-t border-slate-850 my-3.5 pt-3" />
                <span className="block text-[10px] uppercase font-bold tracking-widest text-slate-550 mb-2 px-2 font-mono">
                  GÜVENLİK AYARLARI
                </span>
                <button
                  id="nav-item-permissions"
                  onClick={() => { setActivePage('Yetki Yönetimi'); setSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-bold rounded-lg cursor-pointer transition-colors
                    ${activePage === 'Yetki Yönetimi'
                      ? 'bg-rose-600 text-white'
                      : 'text-rose-400 hover:bg-slate-850 hover:text-rose-300'}`}
                >
                  <ShieldCheck className="h-4 w-4 shrink-0" />
                  <span className="flex-1 text-left truncate">Normal Kullanıcı Yetkileri</span>
                </button>
              </>
            )}
          </nav>
        </div>

        {/* Syncing or error status label bottom of sidebar */}
        <div className="p-4 border-t border-slate-850 text-[10px] font-mono text-slate-500 font-normal">
          {syncing ? (
            <span className="flex items-center gap-2 text-indigo-400">
              <Loader2 className="h-3 w-3 animate-spin" />
              Veri senkronize ediliyor...
            </span>
          ) : connError ? (
            <span className="flex items-center gap-1.5 text-rose-450 leading-tight">
              <AlertCircle className="h-3.5 w-3.5 shrink-0" />
              API Bağlantı koptu
            </span>
          ) : (
            <span className="flex items-center gap-1 text-emerald-500">
              ● API Servisi Bağlı
            </span>
          )}
        </div>
      </aside>

      {/* Main panel - 2 Columns (Right page layout) */}
      <div className="flex-1 min-w-0 flex flex-col h-screen overflow-hidden">
        
        {/* TOP NAVBAR HEADER */}
        <header className="h-16 border-b border-slate-200 bg-white px-6 flex items-center justify-between shrink-0">
          
          <div className="flex items-center gap-3.5">
            {/* Mobile menu trigger */}
            <button 
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 text-slate-500 hover:text-slate-800 rounded bg-slate-50 border border-slate-200 cursor-pointer"
            >
              <Menu className="h-5 w-5" />
            </button>
            
            {/* App Breadcrumb */}
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-800">
              <span className="text-slate-400 font-normal text-xs uppercase font-mono tracking-widest hidden sm:inline">ALTSYSTEM</span>
              <span className="text-slate-300 hidden sm:inline">/</span>
              <span className="text-indigo-650 font-bold uppercase tracking-wider text-xs bg-indigo-50 px-2 py-1 rounded border border-indigo-100">
                {activePage}
              </span>
            </div>
          </div>

          {/* Metrics ticker or Active duty on call info */}
          <div className="flex items-center gap-4">
            
            {/* Active Duty Ticker label (Hidden on narrow mobiles) */}
            {activeDutyNow && (
              <div className="hidden md:flex items-center gap-2 bg-slate-50 border border-slate-200/85 text-slate-600 px-3 py-1.5 rounded-lg text-xs font-semibold">
                <PhoneCall className="h-3.5 w-3.5 text-indigo-600 animate-bounce" />
                <span className="text-slate-400 font-normal">Nöbetçi:</span>
                <span className="text-slate-700 font-extrabold">{activeDutyNow.name}</span>
                <span className="font-mono text-[11px] text-indigo-600 bg-white px-2 py-0.5 rounded border border-slate-100">{activeDutyNow.phone}</span>
              </div>
            )}

            {/* Reset Config button */}
            {currentUser.role === 'admin' && (
              <button
                id="btn-reset-sysadmin-configs"
                title="Sistem Ayarlarını ve İzinleri Resetle"
                onClick={handleResetState}
                className="p-2 border border-slate-200 text-slate-500 hover:text-slate-800 bg-slate-50 border border-slate-200 rounded-lg hover:bg-slate-105 transition-all text-sm font-semibold cursor-pointer flex items-center gap-2"
              >
                <RotateCcw className="h-4 w-4" />
                <span className="hidden sm:inline">Sıfırla</span>
              </button>
            )}
            
          </div>
        </header>

        {/* 3. SCROLLABLE ACTIVE VIEW CONTENT VIEWPORTS */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8 bg-slate-100/40">
          
          {/* Active view component renders here */}
          {activePage === 'Dashboard' && (
            <DashboardView
              inventory={inventory}
              roster={roster}
              logs={logs}
              onNavigate={(p) => setActivePage(p)}
              canWrite={pagePerm.write}
              onQuickRestart={handleQuickNginxRestart}
            />
          )}

          {activePage === 'Envanter' && (
            <InventoryView
              inventory={inventory}
              canWrite={pagePerm.write}
              onUpdateInventory={handleUpdateInventory}
            />
          )}

          {activePage === 'Self Service' && (
            <SelfServiceView
              canWrite={pagePerm.write}
              onTriggerLog={handleTriggerLog}
              user={currentUser.name}
            />
          )}

          {activePage === 'Ansible' && (
            <AnsibleView
              canWrite={pagePerm.write}
              onTriggerLog={handleTriggerLog}
              user={currentUser.name}
            />
          )}

          {activePage === 'Performance' && (
            <PerformanceView />
          )}

          {activePage === 'AskGT' && (
            <AskGTView 
              user={currentUser.name}
            />
          )}

          {activePage === 'Nöbet Listesi' && (
            <RosterView
              roster={roster}
              canWrite={pagePerm.write}
              onUpdateRoster={handleUpdateRoster}
            />
          )}

          {activePage === 'Önemli Linkler' && (
            <LinksView
              links={links}
              canWrite={pagePerm.write}
              onUpdateLinks={handleUpdateLinks}
            />
          )}

          {activePage === 'Yetki Yönetimi' && currentUser.role === 'admin' && (
            <AdminPermissionsPage
              permissions={permissions}
              onChange={handleSavePermissions}
            />
          )}

        </main>
      </div>

    </div>
  );
}
