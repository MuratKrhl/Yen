"use client"

import { Globe, Lock, ShieldCheck, ShieldAlert } from "lucide-react"
import type { Snapshot } from "@/lib/monitoring"
import { cn } from "@/lib/utils"
import { fmtDate } from "@/lib/format"

function sslTone(days: number) {
  if (days <= 0) return { ring: "border-destructive/40", bar: "bg-destructive", text: "text-destructive", label: "Expired" }
  if (days <= 7) return { ring: "border-destructive/40", bar: "bg-destructive", text: "text-destructive", label: "Critical" }
  if (days <= 14) return { ring: "border-warning/40", bar: "bg-warning", text: "text-warning", label: "Expiring soon" }
  if (days <= 30) return { ring: "border-warning/30", bar: "bg-warning", text: "text-warning", label: "Renew soon" }
  return { ring: "border-success/30", bar: "bg-success", text: "text-success", label: "Valid" }
}

export function SslDnsSection({ snapshot }: { snapshot: Snapshot }) {
  const sslSorted = [...snapshot.targets].sort((a, b) => a.ssl.daysRemaining - b.ssl.daysRemaining)

  return (
    <div className="space-y-6">
      <section>
        <div className="mb-3 flex items-center gap-2">
          <Lock className="size-4 text-muted-foreground" />
          <h2 className="text-sm font-semibold">SSL Certificate Expiry</h2>
          <span className="text-xs text-muted-foreground">{snapshot.summary.sslExpiringSoon} expiring within 14 days</span>
        </div>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
          {sslSorted.map((t) => {
            const tone = sslTone(t.ssl.daysRemaining)
            const pct = Math.max(4, Math.min(100, (t.ssl.daysRemaining / 90) * 100))
            return (
              <div key={t.id} className={cn("rounded-lg border bg-card p-4", tone.ring)}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{t.name}</p>
                    <p className="truncate font-mono text-xs text-muted-foreground">{t.host}</p>
                  </div>
                  {t.ssl.daysRemaining <= 14 ? (
                    <ShieldAlert className={cn("size-4 shrink-0", tone.text)} />
                  ) : (
                    <ShieldCheck className={cn("size-4 shrink-0", tone.text)} />
                  )}
                </div>
                <div className="mt-3 flex items-baseline gap-1">
                  <span className={cn("font-mono text-2xl font-semibold tabular-nums", tone.text)}>{t.ssl.daysRemaining}</span>
                  <span className="text-sm text-muted-foreground">days left</span>
                  <span className={cn("ml-auto text-xs font-medium", tone.text)}>{tone.label}</span>
                </div>
                <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted">
                  <div className={cn("h-full rounded-full", tone.bar)} style={{ width: `${pct}%` }} />
                </div>
                <dl className="mt-3 grid grid-cols-2 gap-y-1 text-xs">
                  <dt className="text-muted-foreground">Issuer</dt>
                  <dd className="text-right font-mono">{t.ssl.issuer}</dd>
                  <dt className="text-muted-foreground">Expires</dt>
                  <dd className="text-right font-mono">{fmtDate(t.ssl.expiresAt)}</dd>
                  <dt className="text-muted-foreground">Algorithm</dt>
                  <dd className="text-right font-mono">{t.ssl.algorithm}</dd>
                </dl>
              </div>
            )
          })}
        </div>
      </section>

      <section className="rounded-lg border border-border bg-card">
        <div className="flex items-center gap-2 border-b border-border px-4 py-3">
          <Globe className="size-4 text-muted-foreground" />
          <h2 className="text-sm font-semibold">DNS Health</h2>
        </div>
        <div className="hidden grid-cols-12 gap-3 border-b border-border px-4 py-2 text-xs uppercase tracking-wide text-muted-foreground md:grid">
          <div className="col-span-3">Host</div>
          <div className="col-span-2">Resolved IP</div>
          <div className="col-span-1">Type</div>
          <div className="col-span-1 text-right">TTL</div>
          <div className="col-span-2 text-right">Resolve</div>
          <div className="col-span-3">Nameserver</div>
        </div>
        <ul className="divide-y divide-border">
          {snapshot.targets.map((t) => (
            <li key={t.id} className="grid grid-cols-2 items-center gap-3 px-4 py-2.5 text-sm md:grid-cols-12">
              <div className="col-span-2 min-w-0 md:col-span-3">
                <p className="truncate font-mono text-xs text-foreground">{t.host}</p>
              </div>
              <div className="font-mono text-xs text-muted-foreground md:col-span-2">{t.dns.ip}</div>
              <div className="hidden md:col-span-1 md:block">
                <span className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">{t.dns.recordType}</span>
              </div>
              <div className="hidden text-right font-mono text-xs text-muted-foreground md:col-span-1 md:block">{t.dns.ttl}s</div>
              <div className="hidden text-right font-mono text-xs md:col-span-2 md:block">
                <span className={t.dns.resolveMs > 50 ? "text-warning" : "text-success"}>{t.dns.resolveMs}ms</span>
              </div>
              <div className="hidden truncate font-mono text-xs text-muted-foreground md:col-span-3 md:block">{t.dns.nameserver}</div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  )
}
