import React, { useState } from 'react';
import { 
  CalendarRange, 
  Trash2, 
  Plus, 
  Phone, 
  Tag, 
  UserPlus, 
  UserCheck,
  Lock,
  CalendarDays
} from 'lucide-react';
import { RosterEntry } from '../types';

interface RosterViewProps {
  roster: RosterEntry[];
  canWrite: boolean;
  onUpdateRoster: (entry: RosterEntry, mode: 'add' | 'edit' | 'delete') => void;
}

const teamsList = ['Operations', 'Database', 'Security', 'DevOps'] as const;

const RosterView: React.FC<RosterViewProps> = ({
  roster,
  canWrite,
  onUpdateRoster
}) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('+90 ');
  const [team, setTeam] = useState<RosterEntry['team']>('Operations');
  const [date, setDate] = useState('');

  const currentDayStr = new Date().toISOString().split('T')[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !date) return;

    const rosterPayload: any = {
      name,
      phone,
      team,
      date
    };

    onUpdateRoster(rosterPayload as RosterEntry, 'add');
    setIsFormOpen(false);
    
    // reset fields
    setName('');
    setPhone('+90 ');
    setDate('');
  };

  const handleDelete = (entry: RosterEntry) => {
    if (confirm(`${entry.date} güncelliğindeki ${entry.name} nöbet görev kaydını silmek istediğinize emin misiniz?`)) {
      onUpdateRoster(entry, 'delete');
    }
  };

  // Find active/today's or closest on-call duty person
  const sortedRoster = [...roster].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  const todayEntry = sortedRoster.find(r => r.date === currentDayStr) || sortedRoster[0];

  return (
    <div className="space-y-6">
      {/* Read-Only Banner */}
      {!canWrite && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-xl flex items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2.5">
            <Lock className="h-4 w-4 shrink-0 text-amber-600" />
            <span className="text-xs font-semibold">Salt Okunur Mod — Nöbet planlamasına yeni personel atama veya silme yetkiniz bulunmamaktadır.</span>
          </div>
          <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded uppercase font-mono">Yetki Sınırı</span>
        </div>
      )}

      {/* Header and Add Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Sistem Nöbet Listesi (Duty On-Call)</h1>
          <p className="text-sm text-slate-500 mt-0.5">7/24 operasyon sürekliliği kapsamında aktif nöbetçi ekibi takip rütbesi.</p>
        </div>
        
        {canWrite && (
          <button
            id="btn-add-roster"
            onClick={() => setIsFormOpen(true)}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm rounded-lg flex items-center gap-2 cursor-pointer transition-all shadow-xs"
          >
            <Plus className="h-4 w-4" />
            Nöbetçi Ekle d
          </button>
        )}
      </div>

      {/* Layout Split: Active Roster Card vs list */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Active Today Card */}
        <div className="bg-gradient-to-br from-indigo-950 to-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-sm flex flex-col justify-between h-fit lg:col-span-1">
          <div>
            <div className="flex items-center justify-between border-b border-indigo-900/60 pb-3 mb-4">
              <span className="text-xs font-mono text-indigo-300 font-bold uppercase tracking-wider">Aktif Nöbetçi</span>
              <span className="bg-rose-500/10 text-rose-400 text-[10px] font-bold border border-rose-500/20 px-2 py-0.5 rounded uppercase animate-pulse">
                CALL NOW
              </span>
            </div>

            {todayEntry ? (
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 bg-indigo-900/40 rounded-xl flex items-center justify-center text-indigo-300 border border-indigo-800 shrink-0">
                    <UserCheck className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-100">{todayEntry.name}</h3>
                    <p className="text-xs text-indigo-300 font-semibold mt-0.5 flex items-center gap-1">
                      <Tag className="h-3 w-3 shrink-0" /> {todayEntry.team} Masası
                    </p>
                  </div>
                </div>

                <div className="p-3 bg-slate-900/50 border border-slate-800/80 rounded-xl space-y-2 text-xs font-mono mt-4">
                  <div className="flex items-center gap-2 text-slate-300">
                    <Phone className="h-3.5 w-3.5 text-indigo-400" />
                    <span>{todayEntry.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <CalendarDays className="h-3.5 w-3.5 text-indigo-400" />
                    <span>Nöbet Tarihi: {todayEntry.date}</span>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-sm text-slate-400 italic">Şu an aktif olarak atanmış bir nöbetçi personel planı görünmüyor.</p>
            )}
          </div>

          <div className="pt-6 border-t border-indigo-900/50 mt-6 text-xs text-indigo-300 leading-relaxed font-normal">
            ⚙️ Herhangi bir acil / major incident (P1) durumunda ilk olarak yukarıda adı geçen nöbetçi sistem yöneticisi ile temasa geçilmelidir.
          </div>
        </div>

        {/* Nöbet Listesi (List - 2 Columns) */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden lg:col-span-2 flex flex-col justify-between">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                  <th className="px-5 py-3">Tarih</th>
                  <th className="px-5 py-3">Nöbetçi Personel</th>
                  <th className="px-5 py-3">Grup Masası</th>
                  <th className="px-5 py-3">İletişim</th>
                  {canWrite && <th className="px-5 py-3 text-right">Aksiyonlar</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {sortedRoster.map((entry) => {
                  const isToday = entry.date === currentDayStr;
                  return (
                    <tr 
                      key={entry.id} 
                      className={`hover:bg-slate-50/50 transition-colors
                        ${isToday ? 'bg-indigo-50/20 font-semibold' : ''}`}
                    >
                      <td className="px-5 py-4 whitespace-nowrap font-mono text-xs">
                        {entry.date}
                        {isToday && (
                          <span className="ml-2 bg-indigo-100 text-indigo-800 text-[9px] font-bold px-1.5 py-0.5 rounded-full uppercase">Bugün</span>
                        )}
                      </td>
                      <td className="px-5 py-4 whitespace-nowrap text-slate-800 font-bold">{entry.name}</td>
                      <td className="px-5 py-4 whitespace-nowrap text-xs">
                        <span className={`px-2 py-0.5 rounded font-semibold
                          ${entry.team === 'DevOps' ? 'bg-purple-50 text-purple-700 border border-purple-100' :
                            entry.team === 'Operations' ? 'bg-indigo-50 text-indigo-700 border border-indigo-100' :
                            entry.team === 'Security' ? 'bg-rose-50 text-rose-700 border border-rose-100' :
                            'bg-amber-50 text-amber-700 border border-amber-100'}`}>
                          {entry.team}
                        </span>
                      </td>
                      <td className="px-5 py-4 whitespace-nowrap text-slate-500 font-mono text-xs">{entry.phone}</td>
                      
                      {canWrite && (
                        <td className="px-5 py-4 whitespace-nowrap text-right">
                          <button
                            id={`btn-delete-roster-${entry.id}`}
                            onClick={() => handleDelete(entry)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-105 transition-all cursor-pointer inline-flex"
                            title="Nöbet Sil"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      )}
                    </tr>
                  );
                })}

                {sortedRoster.length === 0 && (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-slate-400 italic">
                      Henüz atanmış bir sistem nöbet kaydı bulunmamaktadır.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>

      {/* Editor Modal Add Roster */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-sm shadow-2xl p-6">
            <h2 className="text-base font-bold text-slate-900 mb-4 border-b border-slate-100 pb-3 flex items-center gap-2">
              <UserPlus className="h-5 w-5 text-indigo-650" />
              Nöbetçi Personel Ata
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Personel Tam Adı *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ahmet Yılmaz"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-normal"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Telefon Numarası *</label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+90 555 123 4567"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-medium font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Grup Masası</label>
                  <select
                    value={team}
                    onChange={(e) => setTeam(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-normal"
                  >
                    {teamsList.map((tm) => (
                      <option key={tm} value={tm}>{tm}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Nöbet Günü *</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-normal"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-650 text-sm font-semibold rounded-lg cursor-pointer"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-lg cursor-pointer animate-fade-in"
                >
                  Planla
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default RosterView;
