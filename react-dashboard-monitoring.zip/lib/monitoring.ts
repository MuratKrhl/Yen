// Simulated monitoring engine.
// Produces realistic, time-varying snapshots for an uptime / health platform.
// Identity (which targets exist, their reliability profile) is stable per target id,
// while metrics jitter over time so polling feels "live".

export type Status = "up" | "degraded" | "down"

export interface TimingBreakdown {
  dns: number
  tcp: number
  tls: number
  ttfb: number
  transfer: number
  total: number
}

export interface SslInfo {
  issuer: string
  expiresAt: string
  daysRemaining: number
  algorithm: string
  valid: boolean
}

export interface DnsInfo {
  ip: string
  recordType: string
  ttl: number
  resolveMs: number
  nameserver: string
}

export interface NetworkInfo {
  latencyAvg: number
  latencyMax: number
  packetLoss: number
  jitter: number
}

export interface HistoryPoint {
  t: number
  label: string
  responseMs: number
  up: boolean
}

export interface UptimeBucket {
  status: Status
  uptime: number
  label: string
}

export interface Target {
  id: string
  name: string
  url: string
  host: string
  group: string
  region: string
  status: Status
  statusCode: number
  uptime24h: number
  uptime7d: number
  uptime30d: number
  timing: TimingBreakdown
  p50: number
  p95: number
  p99: number
  ssl: SslInfo
  dns: DnsInfo
  network: NetworkInfo
  lastCheckSeconds: number
  lastSuccess: string
  lastFailure: string | null
  consecutiveFailures: number
  checkInterval: number
  slaTarget: number
  slaActual: number
  keywordOk: boolean
  securityHeaders: { hsts: boolean; csp: boolean; xfo: boolean }
  history: HistoryPoint[]
  uptimeBars: UptimeBucket[]
}

export interface Incident {
  id: string
  targetId: string
  targetName: string
  severity: "critical" | "warning" | "info"
  type: string
  message: string
  startedAt: string
  resolvedAt: string | null
  durationMin: number
  active: boolean
}

export interface Snapshot {
  generatedAt: string
  targets: Target[]
  incidents: Incident[]
  summary: {
    total: number
    up: number
    degraded: number
    down: number
    avgResponse: number
    avgUptime30d: number
    sslExpiringSoon: number
    avgPacketLoss: number
    activeIncidents: number
    overallSla: number
  }
}

interface Seed {
  id: string
  name: string
  url: string
  group: string
  region: string
  // 0..1 reliability — higher means healthier
  reliability: number
  baseLatency: number
  sslDays: number
  issuer: string
}

const SEEDS: Seed[] = [
  { id: "api-gateway", name: "API Gateway", url: "https://api.northwind.io/v2", group: "Core API", region: "us-east-1", reliability: 0.995, baseLatency: 120, sslDays: 64, issuer: "Let's Encrypt" },
  { id: "web-app", name: "Web App", url: "https://app.northwind.io", group: "Frontend", region: "us-east-1", reliability: 0.998, baseLatency: 210, sslDays: 142, issuer: "DigiCert" },
  { id: "checkout", name: "Checkout Service", url: "https://checkout.northwind.io", group: "Commerce", region: "eu-central-1", reliability: 0.92, baseLatency: 340, sslDays: 11, issuer: "Let's Encrypt" },
  { id: "auth", name: "Auth Service", url: "https://auth.northwind.io", group: "Core API", region: "us-west-2", reliability: 0.999, baseLatency: 95, sslDays: 88, issuer: "Google Trust" },
  { id: "cdn-edge", name: "CDN Edge", url: "https://cdn.northwind.io", group: "Edge Network", region: "global", reliability: 0.9995, baseLatency: 42, sslDays: 210, issuer: "Cloudflare" },
  { id: "payments", name: "Payments API", url: "https://payments.northwind.io", group: "Commerce", region: "eu-central-1", reliability: 0.78, baseLatency: 480, sslDays: 4, issuer: "DigiCert" },
  { id: "search", name: "Search Cluster", url: "https://search.northwind.io", group: "Data", region: "us-east-1", reliability: 0.985, baseLatency: 165, sslDays: 33, issuer: "Let's Encrypt" },
  { id: "ws-stream", name: "Realtime Stream", url: "wss://ws.northwind.io", group: "Edge Network", region: "ap-southeast-1", reliability: 0.97, baseLatency: 88, sslDays: 56, issuer: "Let's Encrypt" },
  { id: "blog-cms", name: "Marketing CMS", url: "https://www.northwind.io", group: "Frontend", region: "us-east-1", reliability: 0.999, baseLatency: 260, sslDays: 19, issuer: "Sectigo" },
  { id: "db-proxy", name: "DB Proxy", url: "https://db-proxy.internal.northwind.io", group: "Data", region: "us-west-2", reliability: 0.55, baseLatency: 30, sslDays: 120, issuer: "Internal CA" },
  { id: "mail-relay", name: "Mail Relay", url: "https://mail.northwind.io", group: "Infra", region: "eu-west-1", reliability: 0.96, baseLatency: 140, sslDays: 71, issuer: "Let's Encrypt" },
  { id: "status-page", name: "Status Page", url: "https://status.northwind.io", group: "Infra", region: "global", reliability: 0.9999, baseLatency: 70, sslDays: 95, issuer: "Cloudflare" },
]

function hashSeed(str: string): number {
  let h = 1779033703 ^ str.length
  for (let i = 0; i < str.length; i++) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353)
    h = (h << 13) | (h >>> 19)
  }
  return h >>> 0
}

function mulberry32(a: number) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function round(n: number, d = 0): number {
  const f = Math.pow(10, d)
  return Math.round(n * f) / f
}

function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n))
}

function fmtIso(ms: number): string {
  return new Date(ms).toISOString()
}

const RECORD_TYPES = ["A", "A", "A", "AAAA", "CNAME"]
const NAMESERVERS = ["ns1.northwind.io", "ns-cloud-a1.googledomains.com", "dns1.p04.nsone.net"]

function randomIp(rng: () => number): string {
  return `${10 + Math.floor(rng() * 240)}.${Math.floor(rng() * 255)}.${Math.floor(rng() * 255)}.${1 + Math.floor(rng() * 254)}`
}

function buildTarget(seed: Seed, now: number): Target {
  const rng = mulberry32(hashSeed(seed.id))
  // Slow time wave (per ~3 min) + medium wave create the live jitter.
  const slow = Math.sin(now / 180000 + hashSeed(seed.id) % 100)
  const med = Math.sin(now / 47000 + (hashSeed(seed.id) % 50))

  // Determine status from reliability and a noise sample that drifts over time.
  const noise = (Math.sin(now / 90000 + hashSeed(seed.id)) + 1) / 2
  let status: Status = "up"
  if (noise > seed.reliability) {
    status = noise > seed.reliability + (1 - seed.reliability) * 0.55 ? "down" : "degraded"
  }

  const degradeFactor = status === "down" ? 1 : status === "degraded" ? 2.4 : 1
  const jitter = 1 + med * 0.18 + slow * 0.1
  const total =
    status === "down"
      ? 0
      : Math.max(8, round(seed.baseLatency * jitter * degradeFactor))

  // Timing breakdown that sums to total.
  const dns = status === "down" ? 0 : round(clamp(8 + rng() * 22 + med * 4, 3, 90))
  const tcp = status === "down" ? 0 : round(clamp(seed.baseLatency * 0.18 * jitter, 5, 200))
  const tls = status === "down" ? 0 : round(clamp(seed.baseLatency * 0.22 * jitter, 6, 240))
  const ttfb = status === "down" ? 0 : round(clamp(total - dns - tcp - tls, total > dns + tcp + tls ? 4 : 0, total))
  const transfer = status === "down" ? 0 : round(clamp(total - dns - tcp - tls - ttfb, 0, total))

  const p50 = status === "down" ? 0 : round(total * 0.92)
  const p95 = status === "down" ? 0 : round(total * 1.45 + rng() * 30)
  const p99 = status === "down" ? 0 : round(total * 1.95 + rng() * 60)

  const baseUptime = seed.reliability * 100
  const uptime24h = round(clamp(baseUptime - (status === "down" ? 2.8 : status === "degraded" ? 0.6 : 0) - rng() * 0.4, 80, 100), 3)
  const uptime7d = round(clamp(baseUptime - rng() * 0.6, 85, 100), 3)
  const uptime30d = round(clamp(baseUptime - rng() * 0.9 + 0.1, 88, 100), 3)

  // 60 history points (last 12h, 12-min steps)
  const history: HistoryPoint[] = []
  for (let i = 59; i >= 0; i--) {
    const t = now - i * 12 * 60000
    const hw = Math.sin(t / 50000 + hashSeed(seed.id))
    const hrng = mulberry32(hashSeed(seed.id + i))()
    const down = hrng > seed.reliability + 0.004 && i % 17 === 3 && seed.reliability < 0.99
    const ms = down ? 0 : round(clamp(seed.baseLatency * (1 + hw * 0.22 + hrng * 0.2), 8, 1400))
    history.push({
      t,
      label: new Date(t).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      responseMs: ms,
      up: !down,
    })
  }
  // ensure latest reflects current status
  history[history.length - 1] = {
    ...history[history.length - 1],
    responseMs: total,
    up: status !== "down",
  }

  // 60 uptime buckets (last 60 periods)
  const uptimeBars: UptimeBucket[] = []
  for (let i = 59; i >= 0; i--) {
    const brng = mulberry32(hashSeed(seed.id + "b" + i))()
    let bs: Status = "up"
    let up = 100
    if (brng > seed.reliability) {
      if (brng > seed.reliability + (1 - seed.reliability) * 0.6) {
        bs = "down"
        up = round(60 + brng * 30, 1)
      } else {
        bs = "degraded"
        up = round(96 + brng * 3, 1)
      }
    }
    const t = now - i * 24 * 60000
    uptimeBars.push({
      status: bs,
      uptime: up,
      label: new Date(t).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    })
  }
  uptimeBars[uptimeBars.length - 1] = {
    ...uptimeBars[uptimeBars.length - 1],
    status,
    uptime: status === "down" ? 0 : status === "degraded" ? 97 : 100,
  }

  const consecutiveFailures = status === "down" ? 1 + Math.floor(rng() * 6) : 0
  const lastFailureMs = status === "down" ? now - consecutiveFailures * 60000 : now - (3600000 + rng() * 86400000 * 6)

  return {
    id: seed.id,
    name: seed.name,
    url: seed.url,
    host: seed.url.replace(/^[a-z]+:\/\//, "").split("/")[0],
    group: seed.group,
    region: seed.region,
    status,
    statusCode: status === "down" ? (rng() > 0.5 ? 503 : 502) : status === "degraded" ? 200 : 200,
    uptime24h,
    uptime7d,
    uptime30d,
    timing: { dns, tcp, tls, ttfb, transfer, total },
    p50,
    p95,
    p99,
    ssl: {
      issuer: seed.issuer,
      expiresAt: fmtIso(now + seed.sslDays * 86400000),
      daysRemaining: seed.sslDays,
      algorithm: "SHA-256 / ECDSA",
      valid: seed.sslDays > 0,
    },
    dns: {
      ip: randomIp(rng),
      recordType: RECORD_TYPES[Math.floor(rng() * RECORD_TYPES.length)],
      ttl: [60, 120, 300, 300, 600, 3600][Math.floor(rng() * 6)],
      resolveMs: dns || round(8 + rng() * 20),
      nameserver: NAMESERVERS[Math.floor(rng() * NAMESERVERS.length)],
    },
    network: {
      latencyAvg: status === "down" ? 0 : round(clamp(seed.baseLatency * 0.3 * jitter, 4, 220)),
      latencyMax: status === "down" ? 0 : round(clamp(seed.baseLatency * 0.55 * jitter + 20, 8, 400)),
      packetLoss: status === "down" ? round(40 + rng() * 55, 1) : status === "degraded" ? round(rng() * 6, 1) : round(rng() * 0.6, 1),
      jitter: status === "down" ? 0 : round(clamp(2 + rng() * 14, 0.5, 40), 1),
    },
    lastCheckSeconds: Math.floor((now % 60000) / 1000),
    lastSuccess: fmtIso(status === "down" ? lastFailureMs - 60000 : now - rng() * 30000),
    lastFailure: status === "down" || rng() > 0.5 ? fmtIso(lastFailureMs) : null,
    consecutiveFailures,
    checkInterval: [30, 60, 60, 120][Math.floor(rng() * 4)],
    slaTarget: 99.9,
    slaActual: uptime30d,
    keywordOk: status !== "down",
    securityHeaders: { hsts: rng() > 0.2, csp: rng() > 0.45, xfo: rng() > 0.25 },
    history,
    uptimeBars,
  }
}

const INCIDENT_TYPES = [
  "HTTP 5xx errors",
  "Connection timeout",
  "High response time",
  "SSL certificate expiring",
  "Elevated packet loss",
  "DNS resolution failure",
  "Keyword check failed",
]

function buildIncidents(targets: Target[], now: number): Incident[] {
  const incidents: Incident[] = []

  // Active incidents from current down/degraded targets
  for (const t of targets) {
    if (t.status === "down") {
      incidents.push({
        id: `inc-${t.id}-active`,
        targetId: t.id,
        targetName: t.name,
        severity: "critical",
        type: "Connection timeout",
        message: `${t.name} is not responding — ${t.consecutiveFailures} consecutive failed checks (status ${t.statusCode}).`,
        startedAt: t.lastFailure ?? fmtIso(now - 300000),
        resolvedAt: null,
        durationMin: Math.max(1, Math.round((now - new Date(t.lastFailure ?? now).getTime()) / 60000)),
        active: true,
      })
    } else if (t.status === "degraded") {
      incidents.push({
        id: `inc-${t.id}-deg`,
        targetId: t.id,
        targetName: t.name,
        severity: "warning",
        type: "High response time",
        message: `${t.name} latency elevated to ${t.timing.total}ms (p95 ${t.p95}ms).`,
        startedAt: fmtIso(now - (5 + Math.floor(Math.random() * 20)) * 60000),
        resolvedAt: null,
        durationMin: 5 + Math.floor(Math.random() * 20),
        active: true,
      })
    }
    if (t.ssl.daysRemaining <= 14 && t.ssl.daysRemaining > 0) {
      incidents.push({
        id: `inc-${t.id}-ssl`,
        targetId: t.id,
        targetName: t.name,
        severity: t.ssl.daysRemaining <= 7 ? "critical" : "warning",
        type: "SSL certificate expiring",
        message: `Certificate for ${t.host} expires in ${t.ssl.daysRemaining} days (${t.ssl.issuer}).`,
        startedAt: fmtIso(now - 3600000),
        resolvedAt: null,
        durationMin: 60,
        active: true,
      })
    }
  }

  // Resolved historical incidents (deterministic-ish)
  const rng = mulberry32(Math.floor(now / 3600000))
  for (let i = 0; i < 8; i++) {
    const t = targets[Math.floor(rng() * targets.length)]
    const startedMs = now - (i + 1) * 3600000 * (1 + rng() * 6)
    const dur = 2 + Math.floor(rng() * 90)
    incidents.push({
      id: `inc-hist-${i}`,
      targetId: t.id,
      targetName: t.name,
      severity: rng() > 0.6 ? "critical" : rng() > 0.3 ? "warning" : "info",
      type: INCIDENT_TYPES[Math.floor(rng() * INCIDENT_TYPES.length)],
      message: `Auto-resolved after ${dur}m — service recovered to healthy state.`,
      startedAt: fmtIso(startedMs),
      resolvedAt: fmtIso(startedMs + dur * 60000),
      durationMin: dur,
      active: false,
    })
  }

  return incidents.sort((a, b) => {
    if (a.active !== b.active) return a.active ? -1 : 1
    return new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime()
  })
}

export function getSnapshot(): Snapshot {
  const now = Date.now()
  const targets = SEEDS.map((s) => buildTarget(s, now))
  const incidents = buildIncidents(targets, now)

  const up = targets.filter((t) => t.status === "up").length
  const degraded = targets.filter((t) => t.status === "degraded").length
  const down = targets.filter((t) => t.status === "down").length
  const liveTargets = targets.filter((t) => t.status !== "down")
  const avgResponse = liveTargets.length
    ? round(liveTargets.reduce((a, t) => a + t.timing.total, 0) / liveTargets.length)
    : 0
  const avgUptime30d = round(targets.reduce((a, t) => a + t.uptime30d, 0) / targets.length, 3)
  const avgPacketLoss = round(targets.reduce((a, t) => a + t.network.packetLoss, 0) / targets.length, 2)
  const sslExpiringSoon = targets.filter((t) => t.ssl.daysRemaining <= 14 && t.ssl.daysRemaining > 0).length
  const activeIncidents = incidents.filter((i) => i.active).length
  const overallSla = round(targets.reduce((a, t) => a + t.slaActual, 0) / targets.length, 3)

  return {
    generatedAt: fmtIso(now),
    targets,
    incidents,
    summary: {
      total: targets.length,
      up,
      degraded,
      down,
      avgResponse,
      avgUptime30d,
      sslExpiringSoon,
      avgPacketLoss,
      activeIncidents,
      overallSla,
    },
  }
}
