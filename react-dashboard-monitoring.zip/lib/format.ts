import type { Status } from "./monitoring"

export function statusLabel(s: Status): string {
  return s === "up" ? "Operational" : s === "degraded" ? "Degraded" : "Down"
}

export function statusColorClass(s: Status): string {
  return s === "up" ? "text-success" : s === "degraded" ? "text-warning" : "text-destructive"
}

export function statusDotClass(s: Status): string {
  return s === "up" ? "bg-success" : s === "degraded" ? "bg-warning" : "bg-destructive"
}

export function timeAgo(iso: string | null): string {
  if (!iso) return "—"
  const diff = Date.now() - new Date(iso).getTime()
  const s = Math.floor(diff / 1000)
  if (s < 60) return `${s}s ago`
  const m = Math.floor(s / 60)
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  const d = Math.floor(h / 24)
  return `${d}d ago`
}

export function fmtDuration(min: number): string {
  if (min < 60) return `${min}m`
  const h = Math.floor(min / 60)
  const m = min % 60
  return m ? `${h}h ${m}m` : `${h}h`
}

export function fmtDate(iso: string): string {
  return new Date(iso).toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" })
}

export function fmtTime(iso: string): string {
  return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
}

export function slaClass(actual: number, target: number): string {
  if (actual >= target) return "text-success"
  if (actual >= target - 0.3) return "text-warning"
  return "text-destructive"
}
