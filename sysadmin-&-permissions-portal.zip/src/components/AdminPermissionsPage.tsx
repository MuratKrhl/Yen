import React, { useState } from 'react';
import { ShieldCheck } from 'lucide-react';
import { PermissionsMap } from '../types';

const MANAGED_PAGES = [
  { id: 'Dashboard',      label: 'Dashboard' },
  { id: 'Envanter',       label: 'Envanter (Envanter)' },
  { id: 'Self Service',   label: 'Self Service' },
  { id: 'Ansible',        label: 'Ansible Otomasyon' },
  { id: 'Performance',    label: 'Sistem Performansı' },
  { id: 'AskGT',          label: 'AskGT Asistanı' },
  { id: 'Nöbet Listesi',  label: 'Nöbet Listesi' },
  { id: 'Önemli Linkler', label: 'Önemli Linkler' },
];

interface ToggleProps {
  checked: boolean;
  onChange: () => void;
  disabled?: boolean;
}

const Toggle: React.FC<ToggleProps> = ({ checked, onChange, disabled }) => (
  <button
    id={`toggle-${checked ? 'on' : 'off'}-${Math.random().toString(36).substr(2, 4)}`}
    type="button"
    disabled={disabled}
    onClick={onChange}
    className={`relative inline-flex h-5 w-9 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none
      ${checked ? 'bg-indigo-600' : 'bg-slate-200'}
      ${disabled ? 'opacity-40 cursor-not-allowed' : ''}`}
  >
    <span
      className={`inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out
        ${checked ? 'translate-x-4' : 'translate-x-0'}`}
    />
  </button>
);

interface Props {
  permissions: PermissionsMap;
  onChange: (updated: PermissionsMap) => void;
}

const AdminPermissionsPage: React.FC<Props> = ({ permissions, onChange }) => {
  const [saved, setSaved] = useState(false);
  const [local, setLocal] = useState<PermissionsMap>(permissions);

  const toggle = (pageId: string, type: 'read' | 'write') => {
    setLocal((prev) => {
      const current = prev[pageId] || { read: false, write: false };
      // Okuma kapatılırsa yazma da kapanır
      if (type === 'read' && current.read) {
        return { ...prev, [pageId]: { read: false, write: false } };
      }
      // Okuma açılıp, yazma zaten kapalıysa normal toggle
      if (type === 'write' && !current.read) {
        // Okuma açık değilse yazma açılamaz
        return prev;
      }
      return { ...prev, [pageId]: { ...current, [type]: !current[type] } };
    });
    setSaved(false);
  };

  const handleSave = () => {
    onChange(local);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="max-w-3xl mx-auto py-4">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2.5 bg-indigo-50 rounded-lg border border-indigo-100">
          <ShieldCheck className="h-6 w-6 text-indigo-600" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-slate-900">Kullanıcı Yetki Yönetimi</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Normal kullanıcıların hangi sayfalara erişebileceğini ayarlayın.
          </p>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
        {/* Table header */}
        <div className="grid grid-cols-[1fr_120px_120px] px-5 py-3 bg-slate-50 border-b border-slate-200">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Sayfa</span>
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider text-center">Görüntüle</span>
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider text-center">Düzenle</span>
        </div>

        {MANAGED_PAGES.map((page, i) => {
          const perm = local[page.id] ?? { read: false, write: false };
          return (
            <div
              key={page.id}
              className={`grid grid-cols-[1fr_120px_120px] px-5 py-4 items-center
                ${i < MANAGED_PAGES.length - 1 ? 'border-b border-slate-100' : ''}
                hover:bg-slate-50 transition-colors duration-100`}
            >
              <div className="flex items-center gap-3">
                <span className="text-sm font-medium text-slate-800">{page.label}</span>
                {!perm.read && (
                  <span className="text-xs bg-slate-100 text-slate-400 px-2 py-0.5 rounded-full font-medium">Erişim Yok</span>
                )}
                {perm.read && !perm.write && (
                  <span className="text-xs bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full font-medium">Salt Okunur</span>
                )}
                {perm.read && perm.write && (
                  <span className="text-xs bg-amber-50 text-amber-600 px-2 py-0.5 rounded-full font-medium">Tam Yetki</span>
                )}
              </div>

              <div className="flex justify-center">
                <Toggle
                  checked={perm.read}
                  onChange={() => toggle(page.id, 'read')}
                />
              </div>

              <div className="flex justify-center">
                <Toggle
                  checked={perm.write}
                  onChange={() => toggle(page.id, 'write')}
                  disabled={!perm.read}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-6">
        <p className="text-xs text-slate-400 max-w-lg">
          💡 Düzenleme yetkisi için önce görüntüleme aktif olmalıdır. Admin kullanıcılar her zaman her sayfada tam yetkiye sahiptir.
        </p>
        <button
          id="btn-save-permissions"
          onClick={handleSave}
          className={`px-5 py-2.5 rounded-lg text-sm font-semibold text-white shadow-xs transition-all duration-200 cursor-pointer self-end sm:self-auto
            ${saved ? 'bg-emerald-500 hover:bg-emerald-600' : 'bg-indigo-600 hover:bg-indigo-700'}`}
        >
          {saved ? '✓ Kaydedildi' : 'Ayarları Kaydet'}
        </button>
      </div>
    </div>
  );
};

export default AdminPermissionsPage;
