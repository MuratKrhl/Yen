import React, { useState } from 'react';
import { 
  Search, 
  RotateCw, 
  ChevronRight, 
  ChevronLeft, 
  Settings2, 
  Terminal,
  ExternalLink,
  ChevronDown,
  Info
} from 'lucide-react';
import { DUMMY_INSTANCES } from '../constants';
import { Instance } from '../types';

export default function InstancesTable() {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const toggleAll = () => {
    setSelectedIds(prev => 
      prev.length === DUMMY_INSTANCES.length ? [] : DUMMY_INSTANCES.map(i => i.id)
    );
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between p-4 bg-white border-b">
        <h1 className="text-xl font-bold flex items-center gap-2">
          Instances ({DUMMY_INSTANCES.length})
          <Info size={16} className="text-blue-500 cursor-pointer" />
        </h1>
        <div className="flex items-center gap-2 text-sm">
          <span className="text-gray-500">Last updated less than a minute ago</span>
          <button className="p-2 hover:bg-gray-100 rounded-sm border"><RotateCw size={16} /></button>
          <button className="px-4 py-1.5 border hover:bg-gray-50 font-medium">Connect</button>
          <div className="relative inline-block text-left">
            <button className="px-4 py-1.5 border hover:bg-gray-50 font-medium flex items-center gap-2">
              Instance state <ChevronDown size={14} />
            </button>
          </div>
          <div className="relative inline-block text-left">
            <button className="px-4 py-1.5 border hover:bg-gray-50 font-medium flex items-center gap-2">
              Actions <ChevronDown size={14} />
            </button>
          </div>
          <button className="px-4 py-1.5 bg-aws-orange hover:bg-aws-orange-hover text-white font-bold rounded-sm shadow-sm transition-colors flex items-center">
            Launch instances
            <div className="border-l border-white/20 ml-3 pl-3 h-4 flex items-center">
              <ChevronDown size={14} />
            </div>
          </button>
        </div>
      </div>

      <div className="p-4 bg-white">
        <div className="flex items-center gap-2 border px-3 py-2 bg-gray-50 rounded-sm">
          <Search size={18} className="text-gray-400" />
          <input 
            type="text" 
            placeholder="Find instance by attribute or tag (case-sensitive)" 
            className="flex-1 bg-transparent text-sm outline-none"
          />
          <div className="h-6 w-[1px] bg-gray-300 mx-2" />
          <select className="bg-transparent text-sm outline-none font-medium cursor-pointer">
            <option>All states</option>
          </select>
          <div className="flex items-center gap-4 ml-4">
            <div className="flex items-center gap-1">
              <ChevronLeft size={18} className="text-gray-300 pointer-events-none" />
              <span className="text-xs font-bold text-gray-800">1</span>
              <span className="text-xs text-gray-500">2 3 4</span>
              <ChevronRight size={18} className="text-gray-600 cursor-pointer" />
            </div>
            <Settings2 size={18} className="text-gray-600 cursor-pointer" />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <table className="w-full text-sm border-collapse bg-white">
          <thead className="bg-[#f8f9fa] border-b text-gray-500 sticky top-0 uppercase text-[11px] font-bold tracking-wider">
            <tr>
              <th className="w-10 p-2 text-center border-r">
                <input 
                  type="checkbox" 
                  checked={selectedIds.length === DUMMY_INSTANCES.length} 
                  onChange={toggleAll}
                />
              </th>
              <th className="p-2 text-left border-r min-w-[200px]">Name <ChevronDown size={12} className="inline ml-1" /></th>
              <th className="p-2 text-left border-r min-w-[200px]">Instance ID</th>
              <th className="p-2 text-left border-r min-w-[150px]">Instance state <ChevronDown size={12} className="inline ml-1" /></th>
              <th className="p-2 text-left border-r min-w-[150px]">Instance type <ChevronDown size={12} className="inline ml-1" /></th>
              <th className="p-2 text-left border-r min-w-[150px]">Status check</th>
              <th className="p-2 text-left min-w-[150px]">Alarm state</th>
            </tr>
          </thead>
          <tbody>
            {DUMMY_INSTANCES.map((instance) => (
              <tr 
                key={instance.id} 
                className={`border-b hover:bg-gray-50 transition-colors ${selectedIds.includes(instance.id) ? 'bg-orange-50' : ''}`}
              >
                <td className="p-2 text-center">
                  <input 
                    type="checkbox" 
                    checked={selectedIds.includes(instance.id)}
                    onChange={() => toggleSelect(instance.id)}
                  />
                </td>
                <td className="p-2 text-blue-600 hover:underline cursor-pointer font-medium flex items-center justify-between group">
                  {instance.name}
                  <Settings2 size={14} className="text-gray-400 opacity-0 group-hover:opacity-100" />
                </td>
                <td className="p-2 text-blue-600 hover:underline cursor-pointer">{instance.id}</td>
                <td className="p-2">
                  <div className="flex items-center gap-1.5">
                    <span className={`w-3 h-3 rounded-full border ${
                      instance.state === 'Running' ? 'bg-green-100 border-green-600 p-[2px]' : 'bg-gray-100 border-gray-600'
                    }`}>
                      {instance.state === 'Running' && (
                        <div className="w-full h-full bg-green-600 rounded-full" />
                      )}
                      {instance.state === 'Stopped' && (
                        <div className="w-full h-full bg-gray-600 rounded-full flex items-center justify-center">
                          <div className="w-1.5 h-[1px] bg-white" />
                        </div>
                      )}
                    </span>
                    <span>{instance.state}</span>
                    <Search size={14} className="text-gray-400 ml-1 cursor-pointer" />
                    <RotateCw size={14} className="text-gray-400 cursor-pointer" />
                  </div>
                </td>
                <td className="p-2 font-mono text-xs">{instance.type}</td>
                <td className="p-2">
                  <div className="flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded-full border border-green-600 flex items-center justify-center text-[10px] text-green-600 font-bold">
                      ✓
                    </span>
                    <span className="text-green-700 font-medium">{instance.statusCheck}</span>
                  </div>
                </td>
                <td className="p-2 flex items-center justify-between group">
                  <span className="text-blue-600 hover:underline cursor-pointer flex items-center gap-1">
                    View alarm
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
